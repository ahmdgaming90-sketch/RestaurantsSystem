/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    // يُضاف هنا نطاق Supabase Storage الفعلي بعد إنشاء المشروع، مثال:
    // remotePatterns: [{ protocol: 'https', hostname: '<project-ref>.supabase.co' }]
    remotePatterns: [],
  },
};

export default nextConfig;
