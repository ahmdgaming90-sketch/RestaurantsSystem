# DineForge — الحالة النهائية الحالية

منصة SaaS لإنشاء وإدارة مواقع مطاعم متعددة (Next.js 14 App Router + TypeScript + Tailwind + Supabase).
هذا الملف يوثّق **كل ما هو مبني وموجود فعليًا** في هذه اللحظة، وما لم يُبنَ بعد.

---

## ما هو مبني فعليًا

### 1. الأساس (Auth, RLS, Middleware, Storage)
- Supabase Auth + جدول `profiles` بدور افتراضي آمن `manager` عند التسجيل (لا مسار يمنح `owner` تلقائيًا).
- RLS كاملة على كل الجداول عبر دالتي `is_owner()` و`is_manager_of()`، مع طبقة تحقق ثانية في
  `lib/permissions.ts` (Defense in depth) داخل كل Server Action حساس.
- `middleware.ts` يحمي `/owner/*` و`/manager/*`، ويحترم قائمة الأسماء المحجوزة
  (`lib/reserved-slugs.ts`) حتى لا تتعارض مع روابط `/[slug]`.
- Supabase Storage: bucket عام `restaurant-assets` بسياسات كتابة محصورة بـ Owner/Manager المطعم.

### 2. لوحة Owner (إدارية كاملة، بتصميم مستقل عن هوية أي مطعم)
- Sidebar احترافي (`components/dashboard/OwnerSidebar.tsx`) بأربعة أقسام: نظرة عامة، المطاعم،
  سجل النشاط، صحة النظام — كلها موصولة فعليًا ببيانات حقيقية من القاعدة، وليست صفحات وهمية.
- **`/owner`**: إحصائيات نظام حقيقية (إجمالي/نشط من المطاعم، إجمالي المنتجات، طلبات اليوم/آخر
  7 أيام/الإجمالي)، أحدث 5 مطاعم، وأحدث 6 طلبات عبر كل المطاعم.
- **`/owner/restaurants`**: قائمة كاملة + **`/new`** للإنشاء + **`/[id]`** للتعديل (فورم مشترك
  `RestaurantForm`، رفع شعار/غلاف عبر Supabase Storage، اختيار من الثيمات الـ15 الفعّالة).
- **`/owner/restaurants/[id]`** يعرض أيضًا `RestaurantStats`: عدد الطلبات، إجمالي الإيرادات
  المسجّلة، وأكثر 3 منتجات طلبًا — محسوبة فعليًا من جدول `orders` الحقيقي لهذا المطعم تحديدًا.
- **`/owner/activity`**: سجل تدقيق (Audit Log) حقيقي من جدول `audit_log` — كل إنشاء/تعديل مطعم
  أو تحديث صورة يُسجَّل تلقائيًا بمن قام به ومتى.
- **`/owner/system-health`**: أخطاء الخادم المسجّلة فعليًا من جدول `error_logs` (كل Server Action
  حساس يسجّل أخطاءه هناك تلقائيًا)، بالإضافة لفحص سلامة بيانات حي (مطاعم بلا إعدادات افتراضية).
- توليد وتحقق فوري (debounced) من الـ slug، مع رفض الأسماء المحجوزة والمكرَّرة على مستويين
  (العميل + الخادم كخط دفاع أخير).

### 3. الموقع العام لكل مطعم (`/[slug]`)
- **15 ثيمًا مبنية فعليًا بهوية بصرية وبنيوية مستقلة تمامًا** — لا يوجد أي Placeholder ولا أي
  ثيم يعيد استخدام مكوّنات ثيم آخر. كل ثيم له مجلد `themes/<key>/` بستة مكونات خاصة به
  (Hero, About, MenuGrid, Gallery, Contact, Footer) + `theme.config.ts`:

  | # | المفتاح | الاسم | العنصر المميز |
  |---|---|---|---|
  | 1 | `minimal` | Minimal White | قائمة Editorial بخط نقطي بين الاسم والسعر |
  | 2 | `midnight-luxury` | Midnight Luxury | Dark luxury سينمائي، صور مؤطرة بإطار ذهبي |
  | 3 | `mediterranean` | Mediterranean | بطاقات مستديرة دافئة، صور طبيعية |
  | 4 | `urban-grill` | Urban Grill | شرائح أفقية ضخمة، طباعة جريئة |
  | 5 | `specialty-coffee` | Specialty Coffee | طابع Coffee Journal، صور دائرية |
  | 6 | `modern-japanese` | Modern Japanese | شبكة غير متماثلة، مساحات فارغة واسعة |
  | 7 | `arabic-heritage` | Arabic Heritage | تراثي رسمي، فواصل زخرفية بسيطة |
  | 8 | `fresh-green` | Fresh & Green | بطاقات مستديرة صحية، CTA أخضر هادئ |
  | 9 | `bakery-atelier` | Bakery Atelier | صور المنتج هي البطل، طابع مجلة |
  | 10 | `coastal` | Coastal | ألوان بحرية هادئة، شرائح عريضة |
  | 11 | `contemporary-black` | Contemporary Black | Hero سينمائي كامل الشاشة، طباعة ضخمة |
  | 12 | `retro-diner` | Retro Diner | Badge "الأكثر طلبًا"، طباعة ريترو قوية |
  | 13 | `street-food` | Street Food | ديناميكي، دخول متتالٍ (stagger) |
  | 14 | `garden-bistro` | Garden Bistro | أشكال عضوية مستديرة، هدوء بصري |
  | 15 | `editorial-fine-dining` | Editorial Fine Dining | Split-screen + Masonry — الأكثر اختلافًا في التخطيط |

- **نظام ألوان موسّع بـ11 توكن** (primary/secondary/accent/background/surface/text/border/
  button/buttonText/heading/muted)، مصدر الحقيقة له هو عمود `themes.default_palette` في القاعدة
  (قابل للتعديل مستقبلاً من لوحة تحكم بدون نشر كود)، ويُدمَج تخصيص المطعم فوقه في
  `app/(public)/[slug]/layout.tsx` عبر CSS variables — كل مكوّنات الثيمات تستهلكها بفئات Tailwind
  (`bg-surface`, `text-heading`, ...) بدل أي لون ثابت.
- `themes/registry.ts` يسجّل الـ15 مباشرة (لا fallback فعلي لأي مطعم حقيقي؛ الرجوع لـ Minimal
  موجود فقط كشبكة أمان دفاعية لمفتاح غير معروف).
- `themes/_template/` + `themes/_template/README.md`: قالب وخطوات لإضافة ثيم 16+ مستقبلاً.
- JSON-LD (Schema.org Restaurant) لكل صفحة مطعم + `loading="lazy"` على صور القوائم/المعارض.

### 4. السلة والطلب عبر واتساب
- `CartProvider` معزول لكل مطعم (`localStorage` بمفتاح `df-cart-{restaurant_id}`).
- `CheckoutForm` يطلب الاسم (إجباري) والجوال (حسب إعداد كل مطعم) والملاحظات.
- **الطلب يُحفَظ فعليًا في جدول `orders`** عبر `lib/actions/orders.ts` — لم يعد الأمر مجرد فتح
  رابط واتساب فقط. **تحقق أمني حقيقي**: الخادم يعيد جلب سعر كل منتج من القاعدة ويتجاهل أي سعر
  يرسله المتصفح، فلا يمكن التلاعب بالإجمالي من أدوات المطوّر.
- رسالة واتساب ديناميكية بدون Emojis مطابقة للقالب المتفق عليه حرفيًا.

### 5. حالات Loading/Error/Not-Found
- `app/error.tsx` (ضمن RootLayout) + `app/global-error.tsx` (يملك `<html>/<body>` خاصة به لتغطية
  انهيار RootLayout نفسه — الفرق بينهما مهم في Next.js ولوحظ وأُصلح أثناء المراجعة النهائية).
- `app/not-found.tsx` عام، و`app/(public)/[slug]/not-found.tsx` مخصص لمطعم غير موجود/غير نشط.
- `app/(owner)/owner/loading.tsx` + `error.tsx`، و`app/(public)/[slug]/loading.tsx` (skeleton).

---

## ما لم يُبنَ بعد (خارج نطاق ما طُلب حتى الآن)
- لوحة Manager (منتجات/أقسام/رفع صور/سجل طلبات) — الصفحة حاليًا "هيكل" (shell) فقط.
- المحرر الهجين + Live Preview الفعلي لتعديل الألوان الـ11 من الواجهة (البنية التحتية جاهزة
  بالكامل لاستقباله: `themes.default_palette` + `restaurants.color_palette` + CSS variables).
- Design Versions (نسخ التصميم والاسترجاع)، إعدادات PWA الفعلية، إدارة مدراء كل مطعم.
- صفحة `/login` الفعلية (نموذج دخول Supabase Auth حقيقي) — حاليًا شكل مبدئي فقط.

---

## خطوات التشغيل

### 1. تثبيت الحزم
هذه البيئة بلا اتصال إنترنت، فلم يُشغَّل `npm install` هنا فعليًا (فحصت الاستيرادات والبنية
استاتيكيًا يدويًا بدلاً من ذلك). عند تحميل المشروع على جهازك:
```bash
npm install
```

### 2. إنشاء مشروع Supabase
- أنشئ مشروعًا جديدًا على [supabase.com](https://supabase.com).
- من Project Settings → API، انسخ `Project URL` و`anon public key` و`service_role key`.
- انسخ `.env.example` إلى `.env.local` واملأ القيم الثلاث.

### 3. تطبيق الـ Migrations (بالترتيب، عبر Supabase CLI)
```bash
supabase login
supabase link --project-ref <project-ref>
supabase db push
```
الترتيب الفعلي والغرض من كل ملف:
1. `0001_initial_schema.sql` — كل الجداول + الفهارس + الـ triggers.
2. `0002_rls_policies.sql` — RLS كاملة + دوال `is_owner()`/`is_manager_of()`.
3. `0003_auth_profile_trigger.sql` — ربط تسجيل مستخدم جديد بـ `profiles` (دور `manager` افتراضيًا).
4. `0004_default_restaurant_settings_trigger.sql` — إعدادات افتراضية تلقائية لكل مطعم جديد.
5. `0005_storage_setup.sql` — bucket `restaurant-assets` + سياسات الكتابة.
6. `0006_theme_catalog_expansion.sql` — توسعة مرحلية للكتالوج (تاريخية، تجاوزها 0007).
7. `0007_theme_catalog_final_15.sql` — **الكتالوج النهائي**: الـ15 ثيمًا بأسمائهم وألوانهم
   الافتراضية الصحيحة، وكلها `is_active = true` لأنها مبنية فعليًا.
8. `0008_audit_and_error_logs.sql` — جدولا `audit_log` و`error_logs`.

### 4. توليد أنواع TypeScript من القاعدة
```bash
SUPABASE_PROJECT_ID=<project-ref> npm run supabase:gen-types
```

### 5. إنشاء أول حساب Owner
- شغّل المشروع محليًا: `npm run dev`.
- سجّل حسابًا عبر Supabase Auth (سيُنشأ له صف `profiles` بدور `manager` تلقائيًا).
- من SQL Editor في لوحة Supabase:
  ```sql
  update public.profiles set role = 'owner' where id = '<USER_UUID>';
  ```

---

## ملاحظة حول المراجعة النهائية
بيئة التطوير هنا بلا اتصال إنترنت، فتعذّر تشغيل `npm install`/`tsc` فعليًا ضد الحزم الحقيقية.
بدلاً من ذلك أُجريت مراجعة استاتيكية شاملة يدويًا: تطابق كل استيراد `@/...` مع ملف فعلي موجود،
تطابق كل مكوّن يستورده كل `theme.config.ts` مع ما يصدّره فعليًا، اكتمال حقول `ThemeDefinition`
و`ColorTokens` في الـ15 ثيمًا بلا نقص أو زيادة، توازن الأقواس في كل ملفات `.tsx`، ووجود
`export default` في كل صفحة. تم بالفعل اكتشاف وإصلاح خطأ حقيقي أثناء هذه المراجعة: `app/error.tsx`
كان يحتوي وسوم `<html>/<body>` مكررة بشكل غير صالح (تم فصله إلى `error.tsx` + `global-error.tsx`
حسب اتفاقية Next.js الصحيحة). يُنصح بتشغيل `npm run build` فعليًا بعد `npm install` على جهازك
كخطوة تحقق أخيرة قبل النشر.
