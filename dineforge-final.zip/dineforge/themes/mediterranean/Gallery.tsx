import type { GalleryProps } from "@/themes/types";
export function MediterraneanGallery({ imageUrls }: GalleryProps) {
  if (imageUrls.length < 3) return null;
  return (
    <section className="max-w-5xl mx-auto px-6 py-16">
      <h2 className="font-df-display text-2xl text-heading text-center mb-8">لمحة من المطعم</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {imageUrls.slice(0, 9).map((url, i) => (
          // eslint-disable-next-line @next/next/no-img-element
          <img key={i} src={url} alt="" className="aspect-square w-full object-cover rounded-2xl" / loading="lazy" decoding="async" />
        ))}
      </div>
    </section>
  );
}
