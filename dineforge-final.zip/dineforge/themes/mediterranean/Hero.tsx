import type { HeroProps } from "@/themes/types";

export function MediterraneanHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  return (
    <section className="px-4 pt-6 sm:px-8">
      <div className="relative h-[46vh] min-h-[300px] w-full overflow-hidden rounded-[2rem]">
        {coverUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={coverUrl} alt={name} className="h-full w-full object-cover" />
        ) : (
          <div className="h-full w-full bg-surface" />
        )}
      </div>
      <div className="max-w-2xl mx-auto text-center -mt-10 relative">
        <div className="bg-surface rounded-3xl shadow-sm px-6 py-6 mx-4">
          {logoUrl && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={logoUrl} alt="" className="h-14 w-14 rounded-full object-cover mx-auto -mt-14 mb-3 border-4 border-surface" />
          )}
          <h1 className="font-df-display text-3xl text-heading">{name}</h1>
          {location && <p className="text-sm text-muted mt-1">{location}</p>}
          {description && <p className="text-sm text-muted mt-3 leading-relaxed">{description}</p>}
        </div>
      </div>
    </section>
  );
}
