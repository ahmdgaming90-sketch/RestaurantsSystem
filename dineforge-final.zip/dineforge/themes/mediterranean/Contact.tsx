import type { ContactProps } from "@/themes/types";
export function MediterraneanContact({ whatsappNumber, location }: ContactProps) {
  return (
    <section className="max-w-md mx-auto px-6 py-16 text-center">
      <div className="bg-surface rounded-3xl p-8">
        <h2 className="font-df-display text-xl text-heading mb-4">تواصل معنا</h2>
        <a href={`https://wa.me/${whatsappNumber.replace(/[^0-9]/g, "")}`} className="text-primary" dir="ltr">{whatsappNumber}</a>
        {location && <p className="text-muted text-sm mt-3">{location}</p>}
      </div>
    </section>
  );
}
