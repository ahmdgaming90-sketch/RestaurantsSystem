import type { AboutProps } from "@/themes/types";
const WEEKDAYS = [{ key: "sun", label: "الأحد" }, { key: "mon", label: "الإثنين" }, { key: "tue", label: "الثلاثاء" }, { key: "wed", label: "الأربعاء" }, { key: "thu", label: "الخميس" }, { key: "fri", label: "الجمعة" }, { key: "sat", label: "السبت" }];

export function MediterraneanAbout({ workingHours }: AboutProps) {
  const hours = workingHours ?? {};
  if (!Object.values(hours).some((v) => v?.trim())) return null;
  return (
    <section className="max-w-2xl mx-auto px-6 py-16">
      <h2 className="font-df-display text-2xl text-heading text-center mb-8">أوقات العمل</h2>
      <div className="bg-surface rounded-3xl p-6 grid grid-cols-2 gap-4 text-sm">
        {WEEKDAYS.map((d) => (
          <div key={d.key} className="flex justify-between">
            <span className="text-heading">{d.label}</span>
            <span className="text-muted" dir="ltr">{hours[d.key]?.trim() || "مغلق"}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
