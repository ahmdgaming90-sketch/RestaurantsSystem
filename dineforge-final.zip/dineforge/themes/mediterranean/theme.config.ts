import type { ColorTokens, ThemeDefinition } from "@/themes/types";
import { MediterraneanHero } from "./Hero";
import { MediterraneanAbout } from "./About";
import { MediterraneanMenu } from "./MenuGrid";
import { MediterraneanGallery } from "./Gallery";
import { MediterraneanContact } from "./Contact";
import { MediterraneanFooter } from "./Footer";

export const mediterraneanPalette: ColorTokens = {
  primary: "#355C4A", secondary: "#756A57", accent: "#C8794B",
  background: "#F5F0E5", surface: "#FFFDF7", text: "#2B2A25",
  border: "#DED4C2", button: "#355C4A", buttonText: "#FFFDF7",
  heading: "#2B2A25", muted: "#756A57",
};

export const mediterraneanDefinition: ThemeDefinition = {
  key: "mediterranean",
  isBuilt: true,
  Hero: MediterraneanHero, About: MediterraneanAbout, Menu: MediterraneanMenu,
  Gallery: MediterraneanGallery, Contact: MediterraneanContact, Footer: MediterraneanFooter,
  typography: { displayFont: "Georgia, serif", bodyFont: "ui-sans-serif, system-ui, sans-serif", personality: "دافئ طبيعي" },
  cardStyle: "boxed-card",
  imageDisplayStyle: "grid",
  layoutVariant: "centered-column",
  animationDefaults: { hero: "slide", sections: "slide" },
  defaultPalette: mediterraneanPalette,
};
