"use client";
import { useState } from "react";
import { AddToCartButton } from "@/components/cart/AddToCartButton";
import type { MenuProps } from "@/themes/types";

// cardStyle: boxed-card — بطاقة مستديرة دافئة بصورة أعلاها
export function MediterraneanMenu({ categories, products }: MenuProps) {
  const [active, setActive] = useState<string | "all">("all");
  if (products.length === 0) return null;
  const cats = categories.filter((c) => products.some((p) => p.category_id === c.id));
  const items = active === "all" ? products : products.filter((p) => p.category_id === active);

  return (
    <section id="menu" className="max-w-5xl mx-auto px-6 py-16">
      <h2 className="font-df-display text-2xl text-heading text-center mb-8">قائمتنا</h2>
      {cats.length > 1 && (
        <div className="flex justify-center gap-2 flex-wrap mb-8">
          <button onClick={() => setActive("all")} className={`px-4 py-1.5 rounded-full text-sm ${active === "all" ? "bg-button text-button-ink" : "bg-surface text-muted"}`}>الكل</button>
          {cats.map((c) => (
            <button key={c.id} onClick={() => setActive(c.id)} className={`px-4 py-1.5 rounded-full text-sm ${active === c.id ? "bg-button text-button-ink" : "bg-surface text-muted"}`}>{c.name}</button>
          ))}
        </div>
      )}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {items.map((p) => (
          <div key={p.id} className="bg-surface rounded-3xl overflow-hidden border border-border">
            {p.image_url ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={p.image_url} alt={p.name} className="h-40 w-full object-cover" / loading="lazy" decoding="async" />
            ) : (
              <div className="h-40 w-full bg-background" />
            )}
            <div className="p-4">
              <div className="flex items-baseline justify-between gap-2">
                <span className="font-df-display text-heading">{p.name}</span>
                <span className="text-accent shrink-0" dir="ltr">{p.price.toFixed(2)}</span>
              </div>
              {p.description && <p className="text-xs text-muted mt-1">{p.description}</p>}
              <div className="mt-3"><AddToCartButton productId={p.id} name={p.name} price={p.price} /></div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
