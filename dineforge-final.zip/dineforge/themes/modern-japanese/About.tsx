import type { AboutProps } from "@/themes/types";
const WEEKDAYS = [{ key: "sun", label: "الأحد" }, { key: "mon", label: "الإثنين" }, { key: "tue", label: "الثلاثاء" }, { key: "wed", label: "الأربعاء" }, { key: "thu", label: "الخميس" }, { key: "fri", label: "الجمعة" }, { key: "sat", label: "السبت" }];
export function ModernJapaneseAbout({ workingHours }: AboutProps) {
  const hours = workingHours ?? {};
  if (!Object.values(hours).some((v) => v?.trim())) return null;
  return (
    <section className="px-8 py-14 max-w-md">
      <p className="text-xs tracking-[0.3em] text-accent mb-6">أوقات العمل</p>
      <div className="space-y-1 text-sm">
        {WEEKDAYS.map((d) => (
          <div key={d.key} className="flex justify-between text-muted">
            <span>{d.label}</span><span dir="ltr">{hours[d.key]?.trim() || "مغلق"}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
