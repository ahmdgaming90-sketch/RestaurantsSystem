import type { ColorTokens, ThemeDefinition } from "@/themes/types";
import { ModernJapaneseHero } from "./Hero";
import { ModernJapaneseAbout } from "./About";
import { ModernJapaneseMenu } from "./MenuGrid";
import { ModernJapaneseGallery } from "./Gallery";
import { ModernJapaneseContact } from "./Contact";
import { ModernJapaneseFooter } from "./Footer";

export const modernJapanesePalette: ColorTokens = {
  primary: "#171717", secondary: "#68645D", accent: "#A33D32",
  background: "#F4F2ED", surface: "#FFFFFF", text: "#171717",
  border: "#DEDCD6", button: "#171717", buttonText: "#FFFFFF",
  heading: "#171717", muted: "#68645D",
};

export const modernJapaneseDefinition: ThemeDefinition = {
  key: "modern-japanese",
  isBuilt: true,
  Hero: ModernJapaneseHero, About: ModernJapaneseAbout, Menu: ModernJapaneseMenu,
  Gallery: ModernJapaneseGallery, Contact: ModernJapaneseContact, Footer: ModernJapaneseFooter,
  typography: { displayFont: "ui-sans-serif, system-ui, sans-serif", bodyFont: "ui-sans-serif, system-ui, sans-serif", personality: "هادئ متوازن دقيق" },
  cardStyle: "editorial-split",
  imageDisplayStyle: "grid",
  layoutVariant: "asymmetric-grid",
  animationDefaults: { hero: "slide", sections: "fade" },
  defaultPalette: modernJapanesePalette,
};
