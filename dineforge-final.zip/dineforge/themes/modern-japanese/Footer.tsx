import { getFooterCopy } from "@/components/site-sections/footerContent";
import type { FooterProps } from "@/themes/types";
export function ModernJapaneseFooter({ restaurantName, settings }: FooterProps) {
  const copy = getFooterCopy(restaurantName, settings);
  return (
    <footer className="border-t border-border px-8 py-8 text-xs text-muted flex flex-wrap justify-between gap-2">
      <p>{copy.copyrightLine}</p>
      {copy.showCredit && <p>{copy.creditText} <a href={copy.creditLink} target="_blank" rel="noopener noreferrer" className="text-accent">←</a></p>}
    </footer>
  );
}
