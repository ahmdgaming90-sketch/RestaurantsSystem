"use client";
import { useState } from "react";
import { AddToCartButton } from "@/components/cart/AddToCartButton";
import type { MenuProps } from "@/themes/types";

// cardStyle: editorial-split — عمودان: نص من جهة، صورة مربعة من جهة، شبكة غير تقليدية
export function ModernJapaneseMenu({ categories, products }: MenuProps) {
  const [active, setActive] = useState<string | "all">("all");
  if (products.length === 0) return null;
  const cats = categories.filter((c) => products.some((p) => p.category_id === c.id));
  const items = active === "all" ? products : products.filter((p) => p.category_id === active);

  return (
    <section id="menu" className="px-8 py-14">
      <p className="text-xs tracking-[0.3em] text-accent mb-8">القائمة</p>
      {cats.length > 1 && (
        <div className="flex gap-6 mb-10 text-sm">
          <button onClick={() => setActive("all")} className={active === "all" ? "text-heading" : "text-muted"}>الكل</button>
          {cats.map((c) => (
            <button key={c.id} onClick={() => setActive(c.id)} className={active === c.id ? "text-heading" : "text-muted"}>{c.name}</button>
          ))}
        </div>
      )}
      <div className="grid sm:grid-cols-2 gap-x-10 gap-y-8">
        {items.map((p) => (
          <div key={p.id} className="flex gap-4 items-start border-b border-border pb-6">
            <div className="flex-1 min-w-0">
              <div className="flex justify-between gap-2">
                <span className="text-heading">{p.name}</span>
                <span className="text-muted" dir="ltr">{p.price.toFixed(2)}</span>
              </div>
              {p.description && <p className="text-xs text-muted mt-2 leading-loose">{p.description}</p>}
              <div className="mt-3"><AddToCartButton productId={p.id} name={p.name} price={p.price} /></div>
            </div>
            {p.image_url && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={p.image_url} alt={p.name} className="h-16 w-16 object-cover shrink-0" / loading="lazy" decoding="async" />
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
