import type { HeroProps } from "@/themes/types";
export function ModernJapaneseHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  return (
    <section className="grid sm:grid-cols-5 gap-0">
      <div className="sm:col-span-3 relative h-[42vh] sm:h-[70vh] overflow-hidden">
        {coverUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={coverUrl} alt={name} className="h-full w-full object-cover" />
        ) : <div className="h-full w-full bg-surface" />}
      </div>
      <div className="sm:col-span-2 flex flex-col justify-center px-8 py-12">
        {logoUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={logoUrl} alt="" className="h-10 w-10 object-cover mb-6" />
        )}
        <h1 className="font-df-display text-3xl text-heading leading-tight">{name}</h1>
        {location && <p className="text-xs text-muted mt-2 tracking-wide">{location}</p>}
        {description && <p className="text-sm text-muted mt-5 leading-loose">{description}</p>}
      </div>
    </section>
  );
}
