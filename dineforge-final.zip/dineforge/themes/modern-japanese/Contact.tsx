import type { ContactProps } from "@/themes/types";
export function ModernJapaneseContact({ whatsappNumber, location }: ContactProps) {
  return (
    <section className="px-8 py-14 max-w-md">
      <p className="text-xs tracking-[0.3em] text-accent mb-6">تواصل</p>
      <a href={`https://wa.me/${whatsappNumber.replace(/[^0-9]/g, "")}`} className="text-heading" dir="ltr">{whatsappNumber}</a>
      {location && <p className="text-muted text-sm mt-2">{location}</p>}
    </section>
  );
}
