import type { HeroProps } from "@/themes/types";
export function BakeryAtelierHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  return (
    <section className="relative h-[55vh] min-h-[340px] w-full overflow-hidden">
      {coverUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={coverUrl} alt={name} className="h-full w-full object-cover" />
      ) : <div className="h-full w-full bg-surface" />}
      <div className="absolute inset-x-0 bottom-0 bg-surface/95 px-6 py-6 text-center">
        {logoUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={logoUrl} alt="" className="h-12 w-12 rounded-full object-cover mx-auto mb-2 -mt-14 border-4 border-surface" />
        )}
        <h1 className="font-df-display text-2xl text-heading">{name}</h1>
        {location && <p className="text-xs text-muted mt-1">{location}</p>}
        {description && <p className="text-sm text-muted mt-2">{description}</p>}
      </div>
    </section>
  );
}
