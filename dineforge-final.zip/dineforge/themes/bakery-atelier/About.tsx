import type { AboutProps } from "@/themes/types";
const WEEKDAYS = [{ key: "sun", label: "الأحد" }, { key: "mon", label: "الإثنين" }, { key: "tue", label: "الثلاثاء" }, { key: "wed", label: "الأربعاء" }, { key: "thu", label: "الخميس" }, { key: "fri", label: "الجمعة" }, { key: "sat", label: "السبت" }];
export function BakeryAtelierAbout({ workingHours }: AboutProps) {
  const hours = workingHours ?? {};
  if (!Object.values(hours).some((v) => v?.trim())) return null;
  return (
    <section className="max-w-3xl mx-auto px-6 py-14 text-center">
      <p className="font-df-display text-xl text-heading mb-6">ساعات العمل</p>
      <div className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm text-muted">
        {WEEKDAYS.map((d) => (
          <span key={d.key}>{d.label}: <span dir="ltr" className="text-heading">{hours[d.key]?.trim() || "مغلق"}</span></span>
        ))}
      </div>
    </section>
  );
}
