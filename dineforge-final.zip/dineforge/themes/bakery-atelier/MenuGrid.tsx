"use client";
import { useState } from "react";
import { AddToCartButton } from "@/components/cart/AddToCartButton";
import type { MenuProps } from "@/themes/types";

// cardStyle: framed-photo — صورة المنتج كبيرة بإطار ناعم، طابع "أفضل المبيعات"
export function BakeryAtelierMenu({ categories, products }: MenuProps) {
  const [active, setActive] = useState<string | "all">("all");
  if (products.length === 0) return null;
  const cats = categories.filter((c) => products.some((p) => p.category_id === c.id));
  const items = active === "all" ? products : products.filter((p) => p.category_id === active);

  return (
    <section id="menu" className="max-w-5xl mx-auto px-6 py-14">
      <h2 className="font-df-display text-2xl text-heading text-center mb-8">من أفران الشيف</h2>
      {cats.length > 1 && (
        <div className="flex justify-center gap-2 flex-wrap mb-8">
          <button onClick={() => setActive("all")} className={`px-4 py-1.5 rounded-full text-sm border ${active === "all" ? "bg-button text-button-ink border-button" : "border-border text-muted"}`}>الكل</button>
          {cats.map((c) => (
            <button key={c.id} onClick={() => setActive(c.id)} className={`px-4 py-1.5 rounded-full text-sm border ${active === c.id ? "bg-button text-button-ink border-button" : "border-border text-muted"}`}>{c.name}</button>
          ))}
        </div>
      )}
      <div className="grid sm:grid-cols-3 gap-6">
        {items.map((p) => (
          <div key={p.id} className="text-center">
            <div className="rounded-2xl overflow-hidden border-4 border-surface shadow-sm mb-3">
              {p.image_url ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={p.image_url} alt={p.name} className="h-40 w-full object-cover" / loading="lazy" decoding="async" />
              ) : <div className="h-40 w-full bg-surface" />}
            </div>
            <p className="font-df-display text-heading">{p.name}</p>
            <p className="text-accent text-sm" dir="ltr">{p.price.toFixed(2)}</p>
            <div className="mt-2 flex justify-center"><AddToCartButton productId={p.id} name={p.name} price={p.price} /></div>
          </div>
        ))}
      </div>
    </section>
  );
}
