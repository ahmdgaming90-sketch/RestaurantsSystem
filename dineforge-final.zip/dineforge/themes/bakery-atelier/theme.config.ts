import type { ColorTokens, ThemeDefinition } from "@/themes/types";
import { BakeryAtelierHero } from "./Hero";
import { BakeryAtelierAbout } from "./About";
import { BakeryAtelierMenu } from "./MenuGrid";
import { BakeryAtelierGallery } from "./Gallery";
import { BakeryAtelierContact } from "./Contact";
import { BakeryAtelierFooter } from "./Footer";

export const bakeryAtelierPalette: ColorTokens = {
  primary: "#49352C", secondary: "#806C60", accent: "#B77A62",
  background: "#F6EEE7", surface: "#FFF9F4", text: "#3A2B23",
  border: "#E5D6CC", button: "#49352C", buttonText: "#FFF9F4",
  heading: "#3A2B23", muted: "#806C60",
};

export const bakeryAtelierDefinition: ThemeDefinition = {
  key: "bakery-atelier",
  isBuilt: true,
  Hero: BakeryAtelierHero, About: BakeryAtelierAbout, Menu: BakeryAtelierMenu,
  Gallery: BakeryAtelierGallery, Contact: BakeryAtelierContact, Footer: BakeryAtelierFooter,
  typography: { displayFont: "Georgia, serif", bodyFont: "ui-sans-serif, system-ui, sans-serif", personality: "دافئ منزلي أنيق" },
  cardStyle: "framed-photo",
  imageDisplayStyle: "grid",
  layoutVariant: "centered-column",
  animationDefaults: { hero: "fade", sections: "slide" },
  defaultPalette: bakeryAtelierPalette,
};
