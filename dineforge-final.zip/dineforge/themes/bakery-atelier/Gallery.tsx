import type { GalleryProps } from "@/themes/types";
export function BakeryAtelierGallery({ imageUrls }: GalleryProps) {
  if (imageUrls.length < 3) return null;
  return (
    <section className="max-w-5xl mx-auto px-6 py-14 grid grid-cols-2 sm:grid-cols-4 gap-3">
      {imageUrls.slice(0, 8).map((url, i) => (
        // eslint-disable-next-line @next/next/no-img-element
        <img key={i} src={url} alt="" className="aspect-[4/5] w-full object-cover rounded-xl" / loading="lazy" decoding="async" />
      ))}
    </section>
  );
}
