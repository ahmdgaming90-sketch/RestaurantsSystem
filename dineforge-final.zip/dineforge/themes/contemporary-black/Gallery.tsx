import type { GalleryProps } from "@/themes/types";
export function ContemporaryBlackGallery({ imageUrls }: GalleryProps) {
  if (imageUrls.length < 3) return null;
  return (
    <section className="grid grid-cols-1 sm:grid-cols-2">
      {imageUrls.slice(0, 4).map((url, i) => (
        // eslint-disable-next-line @next/next/no-img-element
        <img key={i} src={url} alt="" className="w-full h-96 object-cover" / loading="lazy" decoding="async" />
      ))}
    </section>
  );
}
