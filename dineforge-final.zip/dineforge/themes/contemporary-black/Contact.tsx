import type { ContactProps } from "@/themes/types";
export function ContemporaryBlackContact({ whatsappNumber, location }: ContactProps) {
  return (
    <section className="text-center py-24 px-6">
      <a href={`https://wa.me/${whatsappNumber.replace(/[^0-9]/g, "")}`} className="font-df-display text-3xl text-heading" dir="ltr">{whatsappNumber}</a>
      {location && <p className="text-muted text-sm mt-4">{location}</p>}
    </section>
  );
}
