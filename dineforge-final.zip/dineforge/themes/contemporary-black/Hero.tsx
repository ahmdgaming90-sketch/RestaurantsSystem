import type { HeroProps } from "@/themes/types";
export function ContemporaryBlackHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  return (
    <section className="relative h-screen min-h-[600px] w-full overflow-hidden bg-background">
      {coverUrl && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={coverUrl} alt={name} className="absolute inset-0 h-full w-full object-cover opacity-50" />
      )}
      <div className="relative h-full flex flex-col items-center justify-center text-center px-6">
        {logoUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={logoUrl} alt="" className="h-12 w-12 rounded-full object-cover mb-8" />
        )}
        <h1 className="font-df-display text-6xl sm:text-8xl text-heading tracking-tighter leading-none">{name}</h1>
        {location && <p className="text-accent text-xs tracking-[0.4em] mt-6">{location}</p>}
        {description && <p className="text-muted text-sm mt-6 max-w-sm">{description}</p>}
      </div>
    </section>
  );
}
