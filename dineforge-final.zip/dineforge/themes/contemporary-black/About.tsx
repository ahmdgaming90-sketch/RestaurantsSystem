import type { AboutProps } from "@/themes/types";
const WEEKDAYS = [{ key: "sun", label: "الأحد" }, { key: "mon", label: "الإثنين" }, { key: "tue", label: "الثلاثاء" }, { key: "wed", label: "الأربعاء" }, { key: "thu", label: "الخميس" }, { key: "fri", label: "الجمعة" }, { key: "sat", label: "السبت" }];
export function ContemporaryBlackAbout({ workingHours }: AboutProps) {
  const hours = workingHours ?? {};
  if (!Object.values(hours).some((v) => v?.trim())) return null;
  return (
    <section className="text-center py-20 px-6">
      <div className="flex flex-wrap justify-center gap-x-10 gap-y-3 text-sm text-muted">
        {WEEKDAYS.map((d) => (
          <span key={d.key}>{d.label} <span dir="ltr" className="text-heading">{hours[d.key]?.trim() || "مغلق"}</span></span>
        ))}
      </div>
    </section>
  );
}
