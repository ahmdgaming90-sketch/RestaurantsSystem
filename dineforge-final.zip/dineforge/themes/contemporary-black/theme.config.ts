import type { ColorTokens, ThemeDefinition } from "@/themes/types";
import { ContemporaryBlackHero } from "./Hero";
import { ContemporaryBlackAbout } from "./About";
import { ContemporaryBlackMenu } from "./MenuGrid";
import { ContemporaryBlackGallery } from "./Gallery";
import { ContemporaryBlackContact } from "./Contact";
import { ContemporaryBlackFooter } from "./Footer";

export const contemporaryBlackPalette: ColorTokens = {
  primary: "#F5F3EE", secondary: "#9D9A93", accent: "#D0A96D",
  background: "#0D0D0D", surface: "#151515", text: "#F5F3EE",
  border: "#292929", button: "#F5F3EE", buttonText: "#0D0D0D",
  heading: "#F5F3EE", muted: "#9D9A93",
};

export const contemporaryBlackDefinition: ThemeDefinition = {
  key: "contemporary-black",
  isBuilt: true,
  Hero: ContemporaryBlackHero, About: ContemporaryBlackAbout, Menu: ContemporaryBlackMenu,
  Gallery: ContemporaryBlackGallery, Contact: ContemporaryBlackContact, Footer: ContemporaryBlackFooter,
  typography: { displayFont: "Georgia, 'Times New Roman', serif", bodyFont: "ui-sans-serif, system-ui, sans-serif", personality: "فاخر جريء سينمائي" },
  cardStyle: "dotted-price-list",
  imageDisplayStyle: "full-bleed",
  layoutVariant: "full-bleed-sections",
  animationDefaults: { hero: "cinematic", sections: "cinematic" },
  defaultPalette: contemporaryBlackPalette,
};
