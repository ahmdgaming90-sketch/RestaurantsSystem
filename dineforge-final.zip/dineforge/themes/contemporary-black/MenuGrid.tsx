"use client";
import { useState } from "react";
import { AddToCartButton } from "@/components/cart/AddToCartButton";
import type { MenuProps } from "@/themes/types";

// cardStyle: dotted-price-list (نسخة داكنة سينمائية) — طباعة ضخمة، مساحة بيضاء واسعة داكنة
export function ContemporaryBlackMenu({ categories, products }: MenuProps) {
  const [active, setActive] = useState<string | "all">("all");
  if (products.length === 0) return null;
  const cats = categories.filter((c) => products.some((p) => p.category_id === c.id));
  const list = active === "all" ? cats : cats.filter((c) => c.id === active);

  return (
    <section id="menu" className="max-w-3xl mx-auto px-6 py-20">
      <h2 className="font-df-display text-5xl text-heading tracking-tight mb-12">القائمة</h2>
      {cats.length > 1 && (
        <div className="flex gap-6 mb-12 flex-wrap">
          <button onClick={() => setActive("all")} className={active === "all" ? "text-heading text-sm" : "text-muted text-sm"}>الكل</button>
          {cats.map((c) => (
            <button key={c.id} onClick={() => setActive(c.id)} className={active === c.id ? "text-heading text-sm" : "text-muted text-sm"}>{c.name}</button>
          ))}
        </div>
      )}
      <div className="space-y-10">
        {list.map((cat) => {
          const items = products.filter((p) => p.category_id === cat.id);
          if (items.length === 0) return null;
          return (
            <div key={cat.id}>
              <p className="text-accent text-xs tracking-[0.3em] mb-4">{cat.name}</p>
              <ul className="space-y-5">
                {items.map((p) => (
                  <li key={p.id} className="flex items-baseline gap-3 border-b border-border pb-4">
                    <span className="font-df-display text-2xl text-heading">{p.name}</span>
                    <span className="flex-1 border-b border-dotted border-border translate-y-[-4px]" />
                    <span className="text-accent" dir="ltr">{p.price.toFixed(2)}</span>
                    <AddToCartButton productId={p.id} name={p.name} price={p.price} />
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>
    </section>
  );
}
