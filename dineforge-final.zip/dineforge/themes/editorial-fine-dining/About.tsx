import type { AboutProps } from "@/themes/types";
const WEEKDAYS = [{ key: "sun", label: "الأحد" }, { key: "mon", label: "الإثنين" }, { key: "tue", label: "الثلاثاء" }, { key: "wed", label: "الأربعاء" }, { key: "thu", label: "الخميس" }, { key: "fri", label: "الجمعة" }, { key: "sat", label: "السبت" }];

// قسم "Chef / Story" — عمودان: نص طويل من جهة، ساعات العمل من جهة
export function EditorialFineDiningAbout({ workingHours }: AboutProps) {
  const hours = workingHours ?? {};
  const hasHours = Object.values(hours).some((v) => v?.trim());
  return (
    <section className="grid sm:grid-cols-2 gap-10 px-8 sm:px-14 py-20 border-t border-border">
      <div>
        <p className="text-xs tracking-[0.3em] text-accent mb-4">القصة</p>
        <p className="text-heading text-lg leading-relaxed max-w-md">
          كل طبق يُصمَّم ليروي جزءًا من تجربة المكان — تفاصيل مدروسة، ومكوّنات مختارة بعناية.
        </p>
      </div>
      {hasHours && (
        <div>
          <p className="text-xs tracking-[0.3em] text-accent mb-4">أوقات العمل</p>
          <div className="space-y-1 text-sm">
            {WEEKDAYS.map((d) => (
              <div key={d.key} className="flex justify-between max-w-xs text-muted">
                <span>{d.label}</span><span dir="ltr">{hours[d.key]?.trim() || "مغلق"}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
