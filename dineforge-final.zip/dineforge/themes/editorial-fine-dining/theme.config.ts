import type { ColorTokens, ThemeDefinition } from "@/themes/types";
import { EditorialFineDiningHero } from "./Hero";
import { EditorialFineDiningAbout } from "./About";
import { EditorialFineDiningMenu } from "./MenuGrid";
import { EditorialFineDiningGallery } from "./Gallery";
import { EditorialFineDiningContact } from "./Contact";
import { EditorialFineDiningFooter } from "./Footer";

export const editorialFineDiningPalette: ColorTokens = {
  primary: "#222222", secondary: "#77736B", accent: "#8B6A45",
  background: "#F3F1EC", surface: "#FFFFFF", text: "#222222",
  border: "#DCD9D2", button: "#222222", buttonText: "#FFFFFF",
  heading: "#222222", muted: "#77736B",
};

export const editorialFineDiningDefinition: ThemeDefinition = {
  key: "editorial-fine-dining",
  isBuilt: true,
  Hero: EditorialFineDiningHero, About: EditorialFineDiningAbout, Menu: EditorialFineDiningMenu,
  Gallery: EditorialFineDiningGallery, Contact: EditorialFineDiningContact, Footer: EditorialFineDiningFooter,
  typography: { displayFont: "Georgia, 'Times New Roman', serif", bodyFont: "ui-sans-serif, system-ui, sans-serif", personality: "تحريري راقٍ" },
  cardStyle: "editorial-split",
  imageDisplayStyle: "framed",
  layoutVariant: "asymmetric-grid",
  animationDefaults: { hero: "cinematic", sections: "stagger" },
  defaultPalette: editorialFineDiningPalette,
};
