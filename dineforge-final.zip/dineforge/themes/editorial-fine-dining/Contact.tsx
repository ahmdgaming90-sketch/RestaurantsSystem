import type { ContactProps } from "@/themes/types";
export function EditorialFineDiningContact({ whatsappNumber, location }: ContactProps) {
  return (
    <section className="px-8 sm:px-14 py-20 border-t border-border grid sm:grid-cols-2 gap-6">
      <p className="text-xs tracking-[0.3em] text-accent">تواصل معنا</p>
      <div>
        <a href={`https://wa.me/${whatsappNumber.replace(/[^0-9]/g, "")}`} className="text-heading font-df-display text-2xl" dir="ltr">{whatsappNumber}</a>
        {location && <p className="text-muted text-sm mt-2">{location}</p>}
      </div>
    </section>
  );
}
