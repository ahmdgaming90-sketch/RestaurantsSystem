import type { HeroProps } from "@/themes/types";

// Layout غير تقليدي: تقسيم الشاشة، الاسم يشغل نصف العرض بخط ضخم، والصورة النصف الآخر
export function EditorialFineDiningHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  return (
    <section className="grid sm:grid-cols-2 min-h-[80vh]">
      <div className="flex flex-col justify-center px-8 sm:px-14 py-16 order-2 sm:order-1">
        {logoUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={logoUrl} alt="" className="h-10 w-10 object-cover mb-8" />
        )}
        <h1 className="font-df-display text-5xl sm:text-7xl text-heading leading-[0.95]">{name}</h1>
        {location && <p className="text-xs tracking-[0.3em] text-accent mt-6">{location}</p>}
        {description && <p className="text-muted text-sm mt-6 leading-loose max-w-xs">{description}</p>}
      </div>
      <div className="relative h-[40vh] sm:h-auto order-1 sm:order-2">
        {coverUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={coverUrl} alt={name} className="absolute inset-0 h-full w-full object-cover" />
        ) : <div className="absolute inset-0 bg-surface" />}
      </div>
    </section>
  );
}
