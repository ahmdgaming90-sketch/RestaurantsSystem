import type { GalleryProps } from "@/themes/types";

// imageDisplayStyle: masonry — أحجام صور مختلفة، أكثر الثيمات اختلافًا في العرض
export function EditorialFineDiningGallery({ imageUrls }: GalleryProps) {
  if (imageUrls.length < 3) return null;
  const sizes = ["row-span-2", "", "", "row-span-2", "", ""];
  return (
    <section className="px-8 sm:px-14 py-20 border-t border-border">
      <p className="text-xs tracking-[0.3em] text-accent mb-10">المعرض</p>
      <div className="grid grid-cols-2 sm:grid-cols-3 auto-rows-[140px] gap-3">
        {imageUrls.slice(0, 6).map((url, i) => (
          // eslint-disable-next-line @next/next/no-img-element
          <img key={i} src={url} alt="" className={`w-full h-full object-cover ${sizes[i] ?? ""}`} / loading="lazy" decoding="async" />
        ))}
      </div>
    </section>
  );
}
