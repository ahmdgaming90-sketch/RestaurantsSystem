import { getFooterCopy } from "@/components/site-sections/footerContent";
import type { FooterProps } from "@/themes/types";

// طابع "نهاية مجلة" — سطر رفيع بأعلى الصفحة، محاذاة نصية غير مركزية
export function EditorialFineDiningFooter({ restaurantName, settings }: FooterProps) {
  const copy = getFooterCopy(restaurantName, settings);
  return (
    <footer className="border-t border-border px-8 sm:px-14 py-8 flex flex-col sm:flex-row sm:justify-between gap-2 text-xs text-muted">
      <p>{copy.copyrightLine}</p>
      {copy.showCredit && <p>{copy.creditText} <a href={copy.creditLink} target="_blank" rel="noopener noreferrer" className="text-accent">←</a></p>}
    </footer>
  );
}
