"use client";
import { useState } from "react";
import { AddToCartButton } from "@/components/cart/AddToCartButton";
import { StaggerGroup } from "@/components/site-sections/RevealOnScroll";
import type { MenuProps } from "@/themes/types";

// cardStyle: editorial-split — أسعار صغيرة أنيقة، تخطيط مجلة، لا صور كبيرة لكل صنف
export function EditorialFineDiningMenu({ categories, products }: MenuProps) {
  const [active, setActive] = useState<string | "all">("all");
  if (products.length === 0) return null;
  const cats = categories.filter((c) => products.some((p) => p.category_id === c.id));
  const items = active === "all" ? products : products.filter((p) => p.category_id === active);

  return (
    <section id="menu" className="px-8 sm:px-14 py-20 border-t border-border">
      <p className="text-xs tracking-[0.3em] text-accent mb-10">القائمة</p>
      {cats.length > 1 && (
        <div className="flex gap-6 mb-10 flex-wrap">
          <button onClick={() => setActive("all")} className={active === "all" ? "text-heading" : "text-muted"}>الكل</button>
          {cats.map((c) => (
            <button key={c.id} onClick={() => setActive(c.id)} className={active === c.id ? "text-heading" : "text-muted"}>{c.name}</button>
          ))}
        </div>
      )}
      <div className="grid sm:grid-cols-2 gap-x-16 gap-y-6 max-w-4xl">
        <StaggerGroup
          items={items}
          render={(p: any) => (
            <div className="flex items-baseline gap-3 border-b border-border pb-3">
              <span className="text-heading font-df-display">{p.name}</span>
              <span className="flex-1 border-b border-dotted border-border translate-y-[-3px]" />
              <span className="text-xs text-accent" dir="ltr">{p.price.toFixed(2)}</span>
              <AddToCartButton productId={p.id} name={p.name} price={p.price} />
            </div>
          )}
        />
      </div>
    </section>
  );
}
