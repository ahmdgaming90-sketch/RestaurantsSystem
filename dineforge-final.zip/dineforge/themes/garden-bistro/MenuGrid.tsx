"use client";
import { useState } from "react";
import { AddToCartButton } from "@/components/cart/AddToCartButton";
import type { MenuProps } from "@/themes/types";

// cardStyle: boxed-card عضوية الشكل — حواف مستديرة جدًا، هدوء بصري
export function GardenBistroMenu({ categories, products }: MenuProps) {
  const [active, setActive] = useState<string | "all">("all");
  if (products.length === 0) return null;
  const cats = categories.filter((c) => products.some((p) => p.category_id === c.id));
  const items = active === "all" ? products : products.filter((p) => p.category_id === active);

  return (
    <section id="menu" className="max-w-4xl mx-auto px-6 py-14">
      <h2 className="font-df-display text-2xl text-heading text-center mb-8">قائمتنا</h2>
      {cats.length > 1 && (
        <div className="flex justify-center gap-2 flex-wrap mb-8">
          <button onClick={() => setActive("all")} className={`px-4 py-1.5 rounded-full text-sm ${active === "all" ? "bg-button text-button-ink" : "border border-border text-muted"}`}>الكل</button>
          {cats.map((c) => (
            <button key={c.id} onClick={() => setActive(c.id)} className={`px-4 py-1.5 rounded-full text-sm ${active === c.id ? "bg-button text-button-ink" : "border border-border text-muted"}`}>{c.name}</button>
          ))}
        </div>
      )}
      <div className="grid sm:grid-cols-2 gap-6">
        {items.map((p) => (
          <div key={p.id} className="flex gap-4 items-center bg-surface rounded-[2.5rem] p-4 border border-border">
            {p.image_url ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={p.image_url} alt={p.name} className="h-24 w-24 rounded-full object-cover shrink-0" / loading="lazy" decoding="async" />
            ) : <div className="h-24 w-24 rounded-full bg-background shrink-0" />}
            <div className="flex-1 min-w-0 pe-2">
              <p className="font-df-display text-heading">{p.name}</p>
              {p.description && <p className="text-xs text-muted mt-1">{p.description}</p>}
              <div className="flex items-center justify-between mt-2">
                <span className="text-accent text-sm" dir="ltr">{p.price.toFixed(2)}</span>
                <AddToCartButton productId={p.id} name={p.name} price={p.price} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
