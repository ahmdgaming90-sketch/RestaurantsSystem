import type { HeroProps } from "@/themes/types";
export function GardenBistroHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  return (
    <section className="relative h-[54vh] min-h-[340px] w-full overflow-hidden rounded-b-[4rem]">
      {coverUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={coverUrl} alt={name} className="h-full w-full object-cover" />
      ) : <div className="h-full w-full bg-surface" />}
      <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent flex flex-col items-center justify-end pb-10 text-center px-6">
        {logoUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={logoUrl} alt="" className="h-16 w-16 rounded-full object-cover mb-3 border-4 border-background" />
        )}
        <h1 className="font-df-display text-3xl text-heading">{name}</h1>
        {location && <p className="text-sm text-muted mt-1">{location}</p>}
        {description && <p className="text-sm text-muted mt-2 max-w-sm">{description}</p>}
      </div>
    </section>
  );
}
