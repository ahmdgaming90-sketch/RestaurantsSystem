import type { ColorTokens, ThemeDefinition } from "@/themes/types";
import { GardenBistroHero } from "./Hero";
import { GardenBistroAbout } from "./About";
import { GardenBistroMenu } from "./MenuGrid";
import { GardenBistroGallery } from "./Gallery";
import { GardenBistroContact } from "./Contact";
import { GardenBistroFooter } from "./Footer";

export const gardenBistroPalette: ColorTokens = {
  primary: "#344536", secondary: "#72786B", accent: "#A47750",
  background: "#F1F0E7", surface: "#FAFAF5", text: "#252B24",
  border: "#D9DACE", button: "#344536", buttonText: "#FAFAF5",
  heading: "#252B24", muted: "#72786B",
};

export const gardenBistroDefinition: ThemeDefinition = {
  key: "garden-bistro",
  isBuilt: true,
  Hero: GardenBistroHero, About: GardenBistroAbout, Menu: GardenBistroMenu,
  Gallery: GardenBistroGallery, Contact: GardenBistroContact, Footer: GardenBistroFooter,
  typography: { displayFont: "Georgia, serif", bodyFont: "ui-sans-serif, system-ui, sans-serif", personality: "هادئ عضوي ناعم" },
  cardStyle: "boxed-card",
  imageDisplayStyle: "circular",
  layoutVariant: "centered-column",
  animationDefaults: { hero: "reveal", sections: "reveal" },
  defaultPalette: gardenBistroPalette,
};
