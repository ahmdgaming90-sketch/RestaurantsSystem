import type { ContactProps } from "@/themes/types";
export function GardenBistroContact({ whatsappNumber, location }: ContactProps) {
  return (
    <section className="max-w-md mx-auto px-6 py-14 text-center">
      <p className="font-df-display text-xl text-heading mb-3">تواصل معنا</p>
      <a href={`https://wa.me/${whatsappNumber.replace(/[^0-9]/g, "")}`} className="text-primary" dir="ltr">{whatsappNumber}</a>
      {location && <p className="text-muted text-sm mt-2">{location}</p>}
    </section>
  );
}
