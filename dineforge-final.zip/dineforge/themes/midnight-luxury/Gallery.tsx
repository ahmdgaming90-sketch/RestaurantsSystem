import type { GalleryProps } from "@/themes/types";

// imageDisplayStyle: full-bleed — صور كبيرة متتابعة بعرض الشاشة الكامل
export function MidnightLuxuryGallery({ imageUrls }: GalleryProps) {
  if (imageUrls.length < 3) return null;
  return (
    <section className="py-4">
      <div className="grid grid-cols-1 sm:grid-cols-3">
        {imageUrls.slice(0, 6).map((url, i) => (
          // eslint-disable-next-line @next/next/no-img-element
          <img key={i} src={url} alt="" className="w-full h-72 object-cover" / loading="lazy" decoding="async" />
        ))}
      </div>
    </section>
  );
}
