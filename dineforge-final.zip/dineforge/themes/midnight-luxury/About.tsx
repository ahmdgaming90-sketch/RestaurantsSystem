import type { AboutProps } from "@/themes/types";

const WEEKDAYS = [
  { key: "sun", label: "الأحد" }, { key: "mon", label: "الإثنين" }, { key: "tue", label: "الثلاثاء" },
  { key: "wed", label: "الأربعاء" }, { key: "thu", label: "الخميس" }, { key: "fri", label: "الجمعة" }, { key: "sat", label: "السبت" },
];

export function MidnightLuxuryAbout({ workingHours }: AboutProps) {
  const hours = workingHours ?? {};
  if (!Object.values(hours).some((v) => v?.trim())) return null;
  return (
    <section className="mx-auto max-w-2xl px-6 py-24 text-center">
      <p className="text-accent text-xs tracking-[0.35em] mb-6">أوقات العمل</p>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-y-4 gap-x-6 text-sm">
        {WEEKDAYS.map((d) => (
          <div key={d.key} className="border-t border-border pt-3">
            <p className="text-heading">{d.label}</p>
            <p className="text-muted mt-1" dir="ltr">{hours[d.key]?.trim() || "مغلق"}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
