"use client";
import { useState } from "react";
import { AddToCartButton } from "@/components/cart/AddToCartButton";
import type { MenuProps } from "@/themes/types";

// cardStyle: framed-photo — صورة الصنف بإطار رفيع ذهبي كعنصر رئيسي، طباعة سيريف للاسم
export function MidnightLuxuryMenu({ categories, products }: MenuProps) {
  const [active, setActive] = useState<string | "all">("all");
  if (products.length === 0) return null;
  const cats = categories.filter((c) => products.some((p) => p.category_id === c.id));
  const list = active === "all" ? cats : cats.filter((c) => c.id === active);

  return (
    <section id="menu" className="mx-auto max-w-4xl px-6 py-24">
      <p className="text-accent text-xs tracking-[0.35em] text-center mb-10">القائمة</p>

      {cats.length > 1 && (
        <div className="flex justify-center gap-6 mb-14 flex-wrap">
          <button onClick={() => setActive("all")} className={`text-xs tracking-widest pb-1 border-b ${active === "all" ? "border-accent text-heading" : "border-transparent text-muted"}`}>الكل</button>
          {cats.map((c) => (
            <button key={c.id} onClick={() => setActive(c.id)} className={`text-xs tracking-widest pb-1 border-b ${active === c.id ? "border-accent text-heading" : "border-transparent text-muted"}`}>{c.name}</button>
          ))}
        </div>
      )}

      <div className="space-y-16">
        {list.map((cat) => {
          const items = products.filter((p) => p.category_id === cat.id);
          if (items.length === 0) return null;
          return (
            <div key={cat.id}>
              <h3 className="font-df-display text-lg text-heading mb-6 text-center">{cat.name}</h3>
              <div className="grid sm:grid-cols-2 gap-8">
                {items.map((p) => (
                  <div key={p.id} className="flex gap-4 border border-border p-3">
                    {p.image_url && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={p.image_url} alt={p.name} className="h-20 w-20 object-cover border border-accent/40 shrink-0" / loading="lazy" decoding="async" />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-baseline justify-between gap-2">
                        <span className="font-df-display text-heading">{p.name}</span>
                        <span className="text-accent shrink-0" dir="ltr">{p.price.toFixed(2)}</span>
                      </div>
                      {p.description && <p className="text-xs text-muted mt-1 leading-relaxed">{p.description}</p>}
                      <div className="mt-2"><AddToCartButton productId={p.id} name={p.name} price={p.price} /></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
