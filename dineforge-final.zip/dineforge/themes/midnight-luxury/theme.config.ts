import type { ColorTokens, ThemeDefinition } from "@/themes/types";
import { MidnightLuxuryHero } from "./Hero";
import { MidnightLuxuryAbout } from "./About";
import { MidnightLuxuryMenu } from "./MenuGrid";
import { MidnightLuxuryGallery } from "./Gallery";
import { MidnightLuxuryContact } from "./Contact";
import { MidnightLuxuryFooter } from "./Footer";

export const midnightLuxuryPalette: ColorTokens = {
  primary: "#F2EEE6", secondary: "#AAA399", accent: "#B8945B",
  background: "#101010", surface: "#181818", text: "#F2EEE6",
  border: "#302E2A", button: "#B8945B", buttonText: "#101010",
  heading: "#F2EEE6", muted: "#AAA399",
};

export const midnightLuxuryDefinition: ThemeDefinition = {
  key: "midnight-luxury",
  isBuilt: true,
  Hero: MidnightLuxuryHero, About: MidnightLuxuryAbout, Menu: MidnightLuxuryMenu,
  Gallery: MidnightLuxuryGallery, Contact: MidnightLuxuryContact, Footer: MidnightLuxuryFooter,
  typography: { displayFont: "Georgia, 'Times New Roman', serif", bodyFont: "ui-sans-serif, system-ui, sans-serif", personality: "فاخر هادئ داكن" },
  cardStyle: "framed-photo",
  imageDisplayStyle: "full-bleed",
  layoutVariant: "full-bleed-sections",
  animationDefaults: { hero: "cinematic", sections: "reveal" },
  defaultPalette: midnightLuxuryPalette,
};
