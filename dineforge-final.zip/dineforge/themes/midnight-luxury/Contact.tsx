import type { ContactProps } from "@/themes/types";

export function MidnightLuxuryContact({ whatsappNumber, location }: ContactProps) {
  return (
    <section className="px-6 py-24 text-center">
      <p className="text-accent text-xs tracking-[0.35em] mb-6">تواصل معنا</p>
      <a href={`https://wa.me/${whatsappNumber.replace(/[^0-9]/g, "")}`} className="text-heading text-lg font-df-display" dir="ltr">
        {whatsappNumber}
      </a>
      {location && <p className="text-muted text-sm mt-3">{location}</p>}
    </section>
  );
}
