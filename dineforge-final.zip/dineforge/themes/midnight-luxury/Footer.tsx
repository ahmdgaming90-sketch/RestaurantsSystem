import { getFooterCopy } from "@/components/site-sections/footerContent";
import type { FooterProps } from "@/themes/types";

export function MidnightLuxuryFooter({ restaurantName, settings }: FooterProps) {
  const copy = getFooterCopy(restaurantName, settings);
  return (
    <footer className="border-t border-border py-10 text-center text-xs text-muted tracking-wide">
      <p>{copy.copyrightLine}</p>
      {copy.showCredit && (
        <p className="mt-2">
          {copy.creditText}{" "}
          <a href={copy.creditLink} target="_blank" rel="noopener noreferrer" className="text-accent">←</a>
        </p>
      )}
    </footer>
  );
}
