import type { HeroProps } from "@/themes/types";

export function MidnightLuxuryHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  return (
    <section className="relative h-[92vh] min-h-[520px] w-full overflow-hidden bg-background">
      {coverUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={coverUrl} alt={name} className="absolute inset-0 h-full w-full object-cover opacity-70" />
      ) : (
        <div className="absolute inset-0 bg-surface" />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />

      <div className="relative h-full flex flex-col items-center justify-end text-center px-6 pb-16">
        {logoUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={logoUrl} alt="" className="h-14 w-14 rounded-full object-cover mb-6 border border-border" />
        )}
        <p className="text-accent text-xs tracking-[0.35em] mb-4">{location}</p>
        <h1 className="font-df-display text-5xl sm:text-6xl text-heading tracking-tight">{name}</h1>
        {description && (
          <p className="mt-5 max-w-md text-muted leading-relaxed text-sm">{description}</p>
        )}
      </div>
    </section>
  );
}
