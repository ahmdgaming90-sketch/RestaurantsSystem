import type { HeroProps } from "@/themes/types";

export function MinimalHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  return (
    <section className="relative">
      <div className="relative h-[52vh] min-h-[320px] w-full overflow-hidden bg-surface">
        {coverUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={coverUrl} alt={name} className="h-full w-full object-cover" />
        ) : (
          <div className="h-full w-full bg-gradient-to-b from-border to-surface" />
        )}
        {/* تظليل خفيف أسفل الصورة فقط لضمان وضوح النص، وليس فوق الصورة كاملة — الحد الأدنى اللازم */}
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-black/60 to-transparent" />

        <div className="absolute inset-x-0 bottom-0 px-6 pb-8 sm:px-10 sm:pb-10">
          <div className="mx-auto max-w-3xl flex items-end gap-4">
            {logoUrl && (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={logoUrl}
                alt=""
                className="h-16 w-16 rounded-full border-2 border-surface object-cover shrink-0"
              />
            )}
            <div className="min-w-0">
              <h1 className="text-3xl sm:text-4xl font-df-display font-medium tracking-tight text-white">{name}</h1>
              {location && <p className="text-sm text-white/80 mt-1">{location}</p>}
            </div>
          </div>
        </div>
      </div>

      {description && (
        <div className="mx-auto max-w-3xl px-6 sm:px-10 pt-6">
          <p className="text-muted leading-relaxed">{description}</p>
        </div>
      )}
    </section>
  );
}
