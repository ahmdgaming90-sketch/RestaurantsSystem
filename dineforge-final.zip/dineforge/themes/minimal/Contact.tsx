import { SectionLabel } from "@/components/site-sections/SectionLabel";
import type { ContactProps } from "@/themes/types";

export function MinimalContact({ whatsappNumber, location }: ContactProps) {
  return (
    <section className="mx-auto max-w-3xl px-6 sm:px-10 py-16">
      <SectionLabel>تواصل معنا</SectionLabel>
      <div className="space-y-2 text-sm">
        <p>
          <span className="text-muted">واتساب: </span>
          <a href={`https://wa.me/${whatsappNumber.replace(/[^0-9]/g, "")}`} className="text-primary" dir="ltr">
            {whatsappNumber}
          </a>
        </p>
        {location && (
          <p>
            <span className="text-muted">الموقع: </span>
            {location}
          </p>
        )}
      </div>
    </section>
  );
}
