"use client";

import { useState } from "react";
import { SectionLabel } from "@/components/site-sections/SectionLabel";
import { AddToCartButton } from "@/components/cart/AddToCartButton";
import type { MenuProps } from "@/themes/types";

export function MinimalMenu({ categories, products }: MenuProps) {
  const [activeCategory, setActiveCategory] = useState<string | "all">("all");

  if (products.length === 0) return null;

  const visibleCategories = categories.filter((cat) =>
    products.some((p) => p.category_id === cat.id)
  );

  const filteredProducts =
    activeCategory === "all" ? products : products.filter((p) => p.category_id === activeCategory);

  return (
    <section id="menu" className="mx-auto max-w-3xl px-6 sm:px-10 py-16">
      <SectionLabel>القائمة</SectionLabel>

      {visibleCategories.length > 1 && (
        <div className="flex gap-2 overflow-x-auto pb-4 mb-4 -mx-1 px-1">
          <button
            onClick={() => setActiveCategory("all")}
            className={`shrink-0 rounded-full px-4 py-1.5 text-sm transition-colors ${
              activeCategory === "all" ? "bg-button text-button-ink" : "border border-border text-muted"
            }`}
          >
            الكل
          </button>
          {visibleCategories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`shrink-0 rounded-full px-4 py-1.5 text-sm transition-colors ${
                activeCategory === cat.id ? "bg-button text-button-ink" : "border border-border text-muted"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      )}

      <div className="space-y-8">
        {(activeCategory === "all" ? visibleCategories : visibleCategories.filter((c) => c.id === activeCategory)).map(
          (cat) => {
            const items = filteredProducts.filter((p) => p.category_id === cat.id);
            if (items.length === 0) return null;
            return (
              <div key={cat.id}>
                <h3 className="text-sm tracking-wide text-muted mb-3">{cat.name}</h3>
                <ul className="space-y-4">
                  {items.map((product) => (
                    <li key={product.id} className="flex gap-4">
                      {product.image_url && (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={product.image_url}
                          alt={product.name}
                          className="h-16 w-16 rounded object-cover shrink-0"
                        / loading="lazy" decoding="async" />
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline gap-2">
                          <span className="font-df-display font-medium text-heading">{product.name}</span>
                          {/* الخط النقطي الكلاسيكي بين الاسم والسعر — العنصر المميز لهذا الثيم */}
                          <span className="flex-1 border-b border-dotted border-border translate-y-[-3px]" />
                          <span className="text-accent font-medium shrink-0" dir="ltr">
                            {product.price.toFixed(2)}
                          </span>
                        </div>
                        {product.description && (
                          <p className="text-sm text-muted mt-1">{product.description}</p>
                        )}
                        <div className="mt-2">
                          <AddToCartButton
                            productId={product.id}
                            name={product.name}
                            price={product.price}
                          />
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            );
          }
        )}
      </div>
    </section>
  );
}
