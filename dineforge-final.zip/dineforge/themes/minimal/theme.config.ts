import type { ColorTokens, ThemeDefinition } from "@/themes/types";
import { MinimalHero } from "./Hero";
import { MinimalAbout } from "./About";
import { MinimalMenu } from "./MenuGrid";
import { MinimalGallery } from "./Gallery";
import { MinimalContact } from "./Contact";
import { MinimalFooter } from "./Footer";

export const minimalPalette: ColorTokens = {
  primary: "#1C1C1C",
  secondary: "#6F6B63",
  accent: "#B18A52",
  background: "#F8F7F3",
  surface: "#FFFFFF",
  text: "#171717",
  border: "#E7E3DB",
  button: "#1C1C1C",
  buttonText: "#FFFFFF",
  heading: "#171717",
  muted: "#6F6B63",
};

export const minimalDefinition: ThemeDefinition = {
  key: "minimal",
  isBuilt: true,
  Hero: MinimalHero,
  About: MinimalAbout,
  Menu: MinimalMenu,
  Gallery: MinimalGallery,
  Contact: MinimalContact,
  Footer: MinimalFooter,
  typography: {
    displayFont: "Georgia, 'Times New Roman', serif",
    bodyFont: "'Segoe UI', ui-sans-serif, system-ui, -apple-system, sans-serif",
    personality: "نظيف هادئ راقٍ",
  },
  cardStyle: "dotted-price-list",
  imageDisplayStyle: "grid",
  layoutVariant: "centered-column",
  animationDefaults: { hero: "fade", sections: "reveal" },
  defaultPalette: minimalPalette,
};
