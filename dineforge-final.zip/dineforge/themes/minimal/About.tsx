import { SectionLabel } from "@/components/site-sections/SectionLabel";
import type { AboutProps } from "@/themes/types";

const WEEKDAYS: { key: string; label: string }[] = [
  { key: "sun", label: "الأحد" },
  { key: "mon", label: "الإثنين" },
  { key: "tue", label: "الثلاثاء" },
  { key: "wed", label: "الأربعاء" },
  { key: "thu", label: "الخميس" },
  { key: "fri", label: "الجمعة" },
  { key: "sat", label: "السبت" },
];

function getTodayKey(): string {
  const keys = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  return keys[new Date().getDay()];
}

export function MinimalAbout({ workingHours }: AboutProps) {
  const hours = workingHours ?? {};
  const hasAnyHours = Object.values(hours).some((v) => v && v.trim());
  if (!hasAnyHours) return null;

  const todayKey = getTodayKey();

  return (
    <section className="mx-auto max-w-3xl px-6 sm:px-10 py-16">
      <SectionLabel>أوقات العمل</SectionLabel>
      <dl className="divide-y divide-border text-sm">
        {WEEKDAYS.map((day) => (
          <div key={day.key} className="flex items-center justify-between py-2">
            <dt className={day.key === todayKey ? "font-medium" : "text-muted"}>{day.label}</dt>
            <dd className={day.key === todayKey ? "font-medium" : "text-muted"} dir="ltr">
              {hours[day.key]?.trim() || "مغلق"}
            </dd>
          </div>
        ))}
      </dl>
    </section>
  );
}
