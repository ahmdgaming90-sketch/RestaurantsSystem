import { SectionLabel } from "@/components/site-sections/SectionLabel";
import type { GalleryProps } from "@/themes/types";

export function MinimalGallery({ imageUrls }: GalleryProps) {
  // ملاحظة نطاق: لا يوجد جدول "معرض صور" مستقل في Architecture v2 حاليًا،
  // لذلك يُبنى المعرض من صور الأصناف المتوفرة كحل عملي لهذه المرحلة.
  // يُخفى القسم تلقائيًا إن لم تتوفر صور كافية (بدل عرض مربعات فارغة).
  if (imageUrls.length < 3) return null;

  return (
    <section className="mx-auto max-w-3xl px-6 sm:px-10 py-16">
      <SectionLabel>من المطعم</SectionLabel>
      <div className="grid grid-cols-3 gap-2">
        {imageUrls.slice(0, 9).map((url, i) => (
          // eslint-disable-next-line @next/next/no-img-element
          <img key={i} src={url} alt="" className="aspect-square w-full rounded object-cover" / loading="lazy" decoding="async" />
        ))}
      </div>
    </section>
  );
}
