// قالب — انسخ إلى themes/<theme-key>/Gallery.tsx
// اختر imageDisplayStyle مناسبًا (grid/carousel/framed/circular/full-bleed) بما يخدم هوية الثيم.
import type { GalleryProps } from "@/themes/types";

export function TemplateGallery({ imageUrls }: GalleryProps) {
  // TODO
  return null;
}
