// قالب — انسخ إلى themes/<theme-key>/About.tsx
import type { AboutProps } from "@/themes/types";

export function TemplateAbout({ workingHours }: AboutProps) {
  // TODO: نفّذ عرض أوقات العمل/نبذة إضافية بأسلوب هذا الثيم.
  return null;
}
