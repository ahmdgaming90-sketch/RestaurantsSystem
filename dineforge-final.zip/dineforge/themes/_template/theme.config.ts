// قالب — انسخ إلى themes/<theme-key>/theme.config.ts
// اربط هنا أي إعدادات تنفيذية إضافية خاصة بهذا الثيم (خط احتياطي، تفاصيل لا تُدار من لوحة التحكم).
export const templateThemeConfig = {
  key: "template" as const,
  defaultFontStack: "ui-sans-serif, system-ui, sans-serif", // TODO: استبدل بخط العرض الفعلي من الإحاطة
};
