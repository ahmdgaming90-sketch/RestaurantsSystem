// قالب — انسخ إلى themes/<theme-key>/Footer.tsx (اختياري: إن لم يوفَّر، استخدم SharedFooter)
// مهم: المحتوى الإلزامي (حقوق النشر + سطر "تم الإنشاء بواسطة مؤيد الحزمي" + رابط واتساب)
// ثابت ولا يتغير بين الثيمات — فقط الشكل البصري (الخط/التخطيط/الألوان) هو ما يتغير.
// استخدم نفس منطق components/site-sections/Footer.tsx للمحتوى، وغيّر العرض البصري فقط.
import type { FooterProps } from "@/themes/types";

export function TemplateFooter({ restaurantName, settings }: FooterProps) {
  // TODO: أعد استخدام منطق المحتوى من components/site-sections/Footer.tsx
  // مع تصميم بصري مختلف يعكس هوية هذا الثيم.
  return null;
}
