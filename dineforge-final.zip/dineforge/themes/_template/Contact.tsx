// قالب — انسخ إلى themes/<theme-key>/Contact.tsx
import type { ContactProps } from "@/themes/types";

export function TemplateContact({ whatsappNumber, location }: ContactProps) {
  // TODO
  return null;
}
