// قالب — انسخ إلى themes/<theme-key>/MenuGrid.tsx
// هذا هو أهم ملف في أي ثيم: صمّم cardStyle مستقلاً فعليًا (قارن مع أمثلة متعددة في themes/*/MenuGrid.tsx)
// (مثال: framed-photo تختلف بنيويًا عن dotted-price-list، وليست نفس القائمة بشكل مختلف).
import type { MenuProps } from "@/themes/types";
import { AddToCartButton } from "@/components/cart/AddToCartButton";

export function TemplateMenu({ categories, products }: MenuProps) {
  // TODO: نفّذ عرض القائمة حسب cardStyle الخاص بهذا الثيم.
  return null;
}
