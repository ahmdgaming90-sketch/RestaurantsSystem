// قالب — انسخ هذا الملف إلى themes/<theme-key>/Hero.tsx وابدأ التنفيذ الفعلي.
// كل الثيمات الـ15 الحالية مبنية فعليًا في themes/<key>/ — استخدم هذا القالب فقط عند إضافة ثيم 16+ مستقبلاً.

import type { HeroProps } from "@/themes/types";

export function TemplateHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  // TODO: نفّذ هوية Hero الخاصة بهذا الثيم فعليًا حسب signatureIdea في الإحاطة —
  // ليس مجرد نسخ Hero ثيم Minimal مع تغيير الألوان.
  return (
    <section>
      <h1>{name}</h1>
      {description && <p>{description}</p>}
    </section>
  );
}
