import type { ColorTokens, ThemeDefinition } from "@/themes/types";
import { SpecialtyCoffeeHero } from "./Hero";
import { SpecialtyCoffeeAbout } from "./About";
import { SpecialtyCoffeeMenu } from "./MenuGrid";
import { SpecialtyCoffeeGallery } from "./Gallery";
import { SpecialtyCoffeeContact } from "./Contact";
import { SpecialtyCoffeeFooter } from "./Footer";

export const specialtyCoffeePalette: ColorTokens = {
  primary: "#34251D", secondary: "#78685B", accent: "#9A6947",
  background: "#EFE9DF", surface: "#FAF7F1", text: "#34251D",
  border: "#D8CDBF", button: "#34251D", buttonText: "#FAF7F1",
  heading: "#34251D", muted: "#78685B",
};

export const specialtyCoffeeDefinition: ThemeDefinition = {
  key: "specialty-coffee",
  isBuilt: true,
  Hero: SpecialtyCoffeeHero, About: SpecialtyCoffeeAbout, Menu: SpecialtyCoffeeMenu,
  Gallery: SpecialtyCoffeeGallery, Contact: SpecialtyCoffeeContact, Footer: SpecialtyCoffeeFooter,
  typography: { displayFont: "Georgia, serif", bodyFont: "ui-sans-serif, system-ui, sans-serif", personality: "دافئ ودود" },
  cardStyle: "circular-thumb-row",
  imageDisplayStyle: "circular",
  layoutVariant: "centered-column",
  animationDefaults: { hero: "fade", sections: "fade" },
  defaultPalette: specialtyCoffeePalette,
};
