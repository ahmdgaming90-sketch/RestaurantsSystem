import type { GalleryProps } from "@/themes/types";
export function SpecialtyCoffeeGallery({ imageUrls }: GalleryProps) {
  if (imageUrls.length < 3) return null;
  return (
    <section className="max-w-xl mx-auto px-6 py-10 flex gap-3 overflow-x-auto">
      {imageUrls.slice(0, 8).map((url, i) => (
        // eslint-disable-next-line @next/next/no-img-element
        <img key={i} src={url} alt="" className="h-24 w-24 rounded-full object-cover shrink-0" / loading="lazy" decoding="async" />
      ))}
    </section>
  );
}
