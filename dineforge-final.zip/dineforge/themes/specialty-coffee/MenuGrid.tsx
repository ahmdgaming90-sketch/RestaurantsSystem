"use client";
import { useState } from "react";
import { AddToCartButton } from "@/components/cart/AddToCartButton";
import type { MenuProps } from "@/themes/types";

// cardStyle: circular-thumb-row — صور دائرية صغيرة أنيقة، طابع قائمة مقهى حقيقية
export function SpecialtyCoffeeMenu({ categories, products }: MenuProps) {
  const [active, setActive] = useState<string | "all">("all");
  if (products.length === 0) return null;
  const cats = categories.filter((c) => products.some((p) => p.category_id === c.id));
  const list = active === "all" ? cats : cats.filter((c) => c.id === active);

  return (
    <section id="menu" className="max-w-xl mx-auto px-6 py-14">
      <p className="font-df-display text-lg text-heading text-center mb-6">قائمتنا</p>
      {cats.length > 1 && (
        <div className="flex justify-center gap-4 flex-wrap mb-8 text-sm">
          <button onClick={() => setActive("all")} className={active === "all" ? "text-heading underline underline-offset-4" : "text-muted"}>الكل</button>
          {cats.map((c) => (
            <button key={c.id} onClick={() => setActive(c.id)} className={active === c.id ? "text-heading underline underline-offset-4" : "text-muted"}>{c.name}</button>
          ))}
        </div>
      )}
      <div className="space-y-10">
        {list.map((cat) => {
          const items = products.filter((p) => p.category_id === cat.id);
          if (items.length === 0) return null;
          return (
            <div key={cat.id}>
              <p className="text-xs tracking-widest text-accent mb-3">{cat.name}</p>
              <div className="space-y-3">
                {items.map((p) => (
                  <div key={p.id} className="flex items-center gap-3">
                    {p.image_url ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={p.image_url} alt={p.name} className="h-11 w-11 rounded-full object-cover shrink-0" / loading="lazy" decoding="async" />
                    ) : (
                      <div className="h-11 w-11 rounded-full bg-surface shrink-0" />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-heading text-sm">{p.name}</p>
                    </div>
                    <span className="text-muted text-sm" dir="ltr">{p.price.toFixed(2)}</span>
                    <AddToCartButton productId={p.id} name={p.name} price={p.price} />
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
