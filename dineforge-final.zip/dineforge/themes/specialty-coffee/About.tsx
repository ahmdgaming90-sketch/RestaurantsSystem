import type { AboutProps } from "@/themes/types";
const WEEKDAYS = [{ key: "sun", label: "الأحد" }, { key: "mon", label: "الإثنين" }, { key: "tue", label: "الثلاثاء" }, { key: "wed", label: "الأربعاء" }, { key: "thu", label: "الخميس" }, { key: "fri", label: "الجمعة" }, { key: "sat", label: "السبت" }];
export function SpecialtyCoffeeAbout({ workingHours }: AboutProps) {
  const hours = workingHours ?? {};
  if (!Object.values(hours).some((v) => v?.trim())) return null;
  return (
    <section className="max-w-xl mx-auto px-6 py-10 border-y border-border">
      <p className="font-df-display text-lg text-heading text-center mb-4">ساعات العمل</p>
      <ul className="text-sm space-y-1 max-w-xs mx-auto">
        {WEEKDAYS.map((d) => (
          <li key={d.key} className="flex justify-between text-muted">
            <span>{d.label}</span><span dir="ltr">{hours[d.key]?.trim() || "مغلق"}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}
