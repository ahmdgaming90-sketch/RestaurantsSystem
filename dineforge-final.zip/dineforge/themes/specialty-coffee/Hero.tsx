import type { HeroProps } from "@/themes/types";
export function SpecialtyCoffeeHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  return (
    <section className="max-w-xl mx-auto px-6 pt-16 pb-10 text-center">
      {logoUrl && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={logoUrl} alt="" className="h-20 w-20 rounded-full object-cover mx-auto mb-5 border border-border" />
      )}
      <h1 className="font-df-display text-3xl text-heading">{name}</h1>
      {location && <p className="text-sm text-muted mt-1">{location}</p>}
      {description && <p className="text-sm text-muted mt-4 leading-relaxed">{description}</p>}
      {coverUrl && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={coverUrl} alt={name} className="w-full h-56 object-cover rounded-2xl mt-8" />
      )}
    </section>
  );
}
