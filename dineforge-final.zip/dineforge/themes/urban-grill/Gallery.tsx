import type { GalleryProps } from "@/themes/types";
export function UrbanGrillGallery({ imageUrls }: GalleryProps) {
  if (imageUrls.length < 3) return null;
  return (
    <section className="grid grid-cols-2 sm:grid-cols-4">
      {imageUrls.slice(0, 8).map((url, i) => (
        // eslint-disable-next-line @next/next/no-img-element
        <img key={i} src={url} alt="" className="aspect-square w-full object-cover" / loading="lazy" decoding="async" />
      ))}
    </section>
  );
}
