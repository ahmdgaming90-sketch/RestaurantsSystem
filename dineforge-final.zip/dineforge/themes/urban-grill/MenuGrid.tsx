"use client";
import { useState } from "react";
import { AddToCartButton } from "@/components/cart/AddToCartButton";
import type { MenuProps } from "@/themes/types";

// cardStyle: horizontal-strip — شريط أفقي كبير، السعر ضخم وواضح
export function UrbanGrillMenu({ categories, products }: MenuProps) {
  const [active, setActive] = useState<string | "all">("all");
  if (products.length === 0) return null;
  const cats = categories.filter((c) => products.some((p) => p.category_id === c.id));
  const items = active === "all" ? products : products.filter((p) => p.category_id === active);

  return (
    <section id="menu" className="max-w-3xl mx-auto px-6 py-16">
      <h2 className="font-df-display text-3xl font-black uppercase text-heading mb-6">القائمة</h2>
      {cats.length > 1 && (
        <div className="flex gap-2 flex-wrap mb-6">
          <button onClick={() => setActive("all")} className={`px-4 py-2 text-xs font-bold uppercase ${active === "all" ? "bg-accent text-white" : "bg-surface text-muted"}`}>الكل</button>
          {cats.map((c) => (
            <button key={c.id} onClick={() => setActive(c.id)} className={`px-4 py-2 text-xs font-bold uppercase ${active === c.id ? "bg-accent text-white" : "bg-surface text-muted"}`}>{c.name}</button>
          ))}
        </div>
      )}
      <div className="divide-y-4 divide-background">
        {items.map((p) => (
          <div key={p.id} className="flex items-center gap-4 bg-surface p-4">
            {p.image_url && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={p.image_url} alt={p.name} className="h-24 w-24 object-cover shrink-0" / loading="lazy" decoding="async" />
            )}
            <div className="flex-1 min-w-0">
              <p className="font-df-display font-bold text-heading uppercase">{p.name}</p>
              {p.description && <p className="text-xs text-muted mt-1">{p.description}</p>}
              <div className="mt-2"><AddToCartButton productId={p.id} name={p.name} price={p.price} /></div>
            </div>
            <span className="text-2xl font-black text-accent shrink-0" dir="ltr">{p.price.toFixed(0)}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
