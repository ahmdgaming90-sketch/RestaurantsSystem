import type { ColorTokens, ThemeDefinition } from "@/themes/types";
import { UrbanGrillHero } from "./Hero";
import { UrbanGrillAbout } from "./About";
import { UrbanGrillMenu } from "./MenuGrid";
import { UrbanGrillGallery } from "./Gallery";
import { UrbanGrillContact } from "./Contact";
import { UrbanGrillFooter } from "./Footer";

export const urbanGrillPalette: ColorTokens = {
  primary: "#171717", secondary: "#57534E", accent: "#B64B32",
  background: "#F1EEE8", surface: "#FFFFFF", text: "#171717",
  border: "#24211F", button: "#B64B32", buttonText: "#FFFFFF",
  heading: "#171717", muted: "#57534E",
};

export const urbanGrillDefinition: ThemeDefinition = {
  key: "urban-grill",
  isBuilt: true,
  Hero: UrbanGrillHero, About: UrbanGrillAbout, Menu: UrbanGrillMenu,
  Gallery: UrbanGrillGallery, Contact: UrbanGrillContact, Footer: UrbanGrillFooter,
  typography: { displayFont: "'Arial Black', Impact, sans-serif", bodyFont: "ui-sans-serif, system-ui, sans-serif", personality: "قوي جريء" },
  cardStyle: "horizontal-strip",
  imageDisplayStyle: "grid",
  layoutVariant: "asymmetric-grid",
  animationDefaults: { hero: "quick-scale", sections: "quick-scale" },
  defaultPalette: urbanGrillPalette,
};
