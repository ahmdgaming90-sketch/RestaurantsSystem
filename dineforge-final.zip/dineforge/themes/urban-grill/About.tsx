import type { AboutProps } from "@/themes/types";
const WEEKDAYS = [{ key: "sun", label: "الأحد" }, { key: "mon", label: "الإثنين" }, { key: "tue", label: "الثلاثاء" }, { key: "wed", label: "الأربعاء" }, { key: "thu", label: "الخميس" }, { key: "fri", label: "الجمعة" }, { key: "sat", label: "السبت" }];

export function UrbanGrillAbout({ workingHours }: AboutProps) {
  const hours = workingHours ?? {};
  if (!Object.values(hours).some((v) => v?.trim())) return null;
  return (
    <section className="bg-primary text-white px-6 py-10">
      <div className="max-w-3xl mx-auto flex flex-wrap gap-x-8 gap-y-2 justify-center text-sm uppercase tracking-wide">
        {WEEKDAYS.map((d) => (
          <span key={d.key}>{d.label}: <span dir="ltr" className="text-accent">{hours[d.key]?.trim() || "مغلق"}</span></span>
        ))}
      </div>
    </section>
  );
}
