import type { HeroProps } from "@/themes/types";

export function UrbanGrillHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  return (
    <section className="relative h-[60vh] min-h-[380px] w-full overflow-hidden bg-primary">
      {coverUrl && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={coverUrl} alt={name} className="absolute inset-0 h-full w-full object-cover opacity-80" />
      )}
      <div className="absolute inset-0 bg-primary/40" />
      <div className="relative h-full flex flex-col justify-end px-6 sm:px-10 pb-10">
        <div className="max-w-3xl mx-auto w-full flex items-end gap-4">
          {logoUrl && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={logoUrl} alt="" className="h-16 w-16 object-cover shrink-0 border-2 border-white" />
          )}
          <div>
            <h1 className="font-df-display text-4xl sm:text-6xl font-black uppercase tracking-tight text-white leading-none">{name}</h1>
            {location && <p className="text-white/80 text-sm mt-2">{location}</p>}
          </div>
        </div>
      </div>
    </section>
  );
}
