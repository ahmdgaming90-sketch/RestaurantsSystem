import { getFooterCopy } from "@/components/site-sections/footerContent";
import type { FooterProps } from "@/themes/types";
export function UrbanGrillFooter({ restaurantName, settings }: FooterProps) {
  const copy = getFooterCopy(restaurantName, settings);
  return (
    <footer className="bg-primary text-white/70 py-6 text-center text-xs uppercase tracking-wide">
      <p>{copy.copyrightLine}</p>
      {copy.showCredit && (
        <p className="mt-1">{copy.creditText} <a href={copy.creditLink} target="_blank" rel="noopener noreferrer" className="text-accent">←</a></p>
      )}
    </footer>
  );
}
