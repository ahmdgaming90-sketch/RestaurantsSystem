"use client";
import { useState } from "react";
import { AddToCartButton } from "@/components/cart/AddToCartButton";
import type { MenuProps } from "@/themes/types";

// cardStyle: editorial-split — تخطيط متماثل رسمي، عنوان قسم بفاصل زخرفي بسيط
export function ArabicHeritageMenu({ categories, products }: MenuProps) {
  const [active, setActive] = useState<string | "all">("all");
  if (products.length === 0) return null;
  const cats = categories.filter((c) => products.some((p) => p.category_id === c.id));
  const list = active === "all" ? cats : cats.filter((c) => c.id === active);

  return (
    <section id="menu" className="max-w-2xl mx-auto px-6 py-16">
      <p className="font-df-display text-xl text-heading text-center mb-1">قائمة الطعام</p>
      <div className="mx-auto mb-10 h-px w-12 bg-accent" />
      {cats.length > 1 && (
        <div className="flex justify-center gap-4 flex-wrap mb-10 text-sm">
          <button onClick={() => setActive("all")} className={active === "all" ? "text-accent" : "text-muted"}>الكل</button>
          {cats.map((c) => (
            <button key={c.id} onClick={() => setActive(c.id)} className={active === c.id ? "text-accent" : "text-muted"}>{c.name}</button>
          ))}
        </div>
      )}
      <div className="space-y-12">
        {list.map((cat) => {
          const items = products.filter((p) => p.category_id === cat.id);
          if (items.length === 0) return null;
          return (
            <div key={cat.id}>
              <p className="text-center text-sm text-accent mb-5">{cat.name}</p>
              <ul className="space-y-5">
                {items.map((p) => (
                  <li key={p.id} className="flex items-center gap-4">
                    {p.image_url && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={p.image_url} alt={p.name} className="h-14 w-14 rounded-full object-cover shrink-0 border border-accent/40" / loading="lazy" decoding="async" />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between gap-2">
                        <span className="font-df-display text-heading">{p.name}</span>
                        <span className="text-accent" dir="ltr">{p.price.toFixed(2)}</span>
                      </div>
                      {p.description && <p className="text-xs text-muted mt-1">{p.description}</p>}
                    </div>
                    <AddToCartButton productId={p.id} name={p.name} price={p.price} />
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>
    </section>
  );
}
