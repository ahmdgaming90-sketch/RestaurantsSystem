import type { HeroProps } from "@/themes/types";
export function ArabicHeritageHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  return (
    <section className="relative">
      <div className="relative h-[50vh] min-h-[320px] w-full overflow-hidden">
        {coverUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={coverUrl} alt={name} className="h-full w-full object-cover" />
        ) : <div className="h-full w-full bg-surface" />}
        <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
      </div>
      <div className="text-center -mt-12 relative px-6">
        {logoUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={logoUrl} alt="" className="h-20 w-20 rounded-full object-cover mx-auto mb-4 border-4 border-background" />
        )}
        <h1 className="font-df-display text-3xl text-heading">{name}</h1>
        <div className="mx-auto mt-3 h-px w-16 bg-accent" />
        {location && <p className="text-sm text-muted mt-3">{location}</p>}
        {description && <p className="text-sm text-muted mt-3 max-w-lg mx-auto leading-relaxed">{description}</p>}
      </div>
    </section>
  );
}
