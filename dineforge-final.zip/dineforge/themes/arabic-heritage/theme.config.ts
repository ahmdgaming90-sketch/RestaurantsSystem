import type { ColorTokens, ThemeDefinition } from "@/themes/types";
import { ArabicHeritageHero } from "./Hero";
import { ArabicHeritageAbout } from "./About";
import { ArabicHeritageMenu } from "./MenuGrid";
import { ArabicHeritageGallery } from "./Gallery";
import { ArabicHeritageContact } from "./Contact";
import { ArabicHeritageFooter } from "./Footer";

export const arabicHeritagePalette: ColorTokens = {
  primary: "#3D3025", secondary: "#776653", accent: "#9A6A35",
  background: "#F1E7D3", surface: "#FBF5E9", text: "#292018",
  border: "#E3D5B8", button: "#3D3025", buttonText: "#FBF5E9",
  heading: "#292018", muted: "#776653",
};

export const arabicHeritageDefinition: ThemeDefinition = {
  key: "arabic-heritage",
  isBuilt: true,
  Hero: ArabicHeritageHero, About: ArabicHeritageAbout, Menu: ArabicHeritageMenu,
  Gallery: ArabicHeritageGallery, Contact: ArabicHeritageContact, Footer: ArabicHeritageFooter,
  typography: { displayFont: "Georgia, serif", bodyFont: "ui-sans-serif, system-ui, sans-serif", personality: "تراثي رسمي فاخر" },
  cardStyle: "editorial-split",
  imageDisplayStyle: "framed",
  layoutVariant: "centered-column",
  animationDefaults: { hero: "fade", sections: "reveal" },
  defaultPalette: arabicHeritagePalette,
};
