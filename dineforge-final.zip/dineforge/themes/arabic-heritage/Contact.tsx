import type { ContactProps } from "@/themes/types";
export function ArabicHeritageContact({ whatsappNumber, location }: ContactProps) {
  return (
    <section className="max-w-md mx-auto px-6 py-16 text-center">
      <p className="font-df-display text-xl text-heading mb-1">تواصل معنا</p>
      <div className="mx-auto mb-6 h-px w-12 bg-accent" />
      <a href={`https://wa.me/${whatsappNumber.replace(/[^0-9]/g, "")}`} className="text-primary" dir="ltr">{whatsappNumber}</a>
      {location && <p className="text-muted text-sm mt-3">{location}</p>}
    </section>
  );
}
