import { getFooterCopy } from "@/components/site-sections/footerContent";
import type { FooterProps } from "@/themes/types";
export function ArabicHeritageFooter({ restaurantName, settings }: FooterProps) {
  const copy = getFooterCopy(restaurantName, settings);
  return (
    <footer className="border-t border-accent/30 py-8 text-center text-xs text-muted">
      <p>{copy.copyrightLine}</p>
      {copy.showCredit && <p className="mt-1">{copy.creditText} <a href={copy.creditLink} target="_blank" rel="noopener noreferrer" className="text-accent">←</a></p>}
    </footer>
  );
}
