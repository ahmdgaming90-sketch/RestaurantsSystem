import type { AboutProps } from "@/themes/types";
const WEEKDAYS = [{ key: "sun", label: "الأحد" }, { key: "mon", label: "الإثنين" }, { key: "tue", label: "الثلاثاء" }, { key: "wed", label: "الأربعاء" }, { key: "thu", label: "الخميس" }, { key: "fri", label: "الجمعة" }, { key: "sat", label: "السبت" }];
export function ArabicHeritageAbout({ workingHours }: AboutProps) {
  const hours = workingHours ?? {};
  if (!Object.values(hours).some((v) => v?.trim())) return null;
  return (
    <section className="max-w-2xl mx-auto px-6 py-16 text-center">
      <p className="font-df-display text-xl text-heading mb-1">أوقات العمل</p>
      <div className="mx-auto mb-8 h-px w-12 bg-accent" />
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 text-sm">
        {WEEKDAYS.map((d) => (
          <div key={d.key}>
            <p className="text-heading">{d.label}</p>
            <p className="text-muted mt-1" dir="ltr">{hours[d.key]?.trim() || "مغلق"}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
