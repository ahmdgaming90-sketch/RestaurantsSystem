import type { ContactProps } from "@/themes/types";
export function RetroDinerContact({ whatsappNumber, location }: ContactProps) {
  return (
    <section className="bg-primary text-white text-center py-14 px-6">
      <a href={`https://wa.me/${whatsappNumber.replace(/[^0-9]/g, "")}`} className="text-2xl font-black text-accent" dir="ltr">{whatsappNumber}</a>
      {location && <p className="text-white/70 text-sm mt-3">{location}</p>}
    </section>
  );
}
