"use client";
import { useState } from "react";
import { AddToCartButton } from "@/components/cart/AddToCartButton";
import type { MenuProps } from "@/themes/types";

// cardStyle: boxed-card مع Badge — بطاقات واضحة بحدود سميكة، شارة "الأكثر طلبًا" على أول عنصر
export function RetroDinerMenu({ categories, products }: MenuProps) {
  const [active, setActive] = useState<string | "all">("all");
  if (products.length === 0) return null;
  const cats = categories.filter((c) => products.some((p) => p.category_id === c.id));
  const items = active === "all" ? products : products.filter((p) => p.category_id === active);

  return (
    <section id="menu" className="max-w-4xl mx-auto px-6 py-14">
      <h2 className="font-df-display text-3xl font-black uppercase text-heading text-center mb-8">القائمة</h2>
      {cats.length > 1 && (
        <div className="flex justify-center gap-2 flex-wrap mb-8">
          <button onClick={() => setActive("all")} className={`px-4 py-1.5 rounded-full text-sm font-bold border-2 border-primary ${active === "all" ? "bg-primary text-white" : "text-primary"}`}>الكل</button>
          {cats.map((c) => (
            <button key={c.id} onClick={() => setActive(c.id)} className={`px-4 py-1.5 rounded-full text-sm font-bold border-2 border-primary ${active === c.id ? "bg-primary text-white" : "text-primary"}`}>{c.name}</button>
          ))}
        </div>
      )}
      <div className="grid sm:grid-cols-2 gap-5">
        {items.map((p, i) => (
          <div key={p.id} className="relative border-2 border-primary rounded-xl overflow-hidden bg-surface">
            {i === 0 && (
              <span className="absolute top-2 right-2 z-10 bg-accent text-white text-[10px] font-bold px-2 py-1 rounded">الأكثر طلبًا</span>
            )}
            {p.image_url && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={p.image_url} alt={p.name} className="h-36 w-full object-cover" / loading="lazy" decoding="async" />
            )}
            <div className="p-4">
              <div className="flex justify-between items-baseline">
                <span className="font-df-display font-bold text-heading">{p.name}</span>
                <span className="text-accent font-black" dir="ltr">{p.price.toFixed(2)}</span>
              </div>
              {p.description && <p className="text-xs text-muted mt-1">{p.description}</p>}
              <div className="mt-2"><AddToCartButton productId={p.id} name={p.name} price={p.price} /></div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
