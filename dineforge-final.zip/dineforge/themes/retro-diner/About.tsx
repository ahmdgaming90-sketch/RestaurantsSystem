import type { AboutProps } from "@/themes/types";
const WEEKDAYS = [{ key: "sun", label: "الأحد" }, { key: "mon", label: "الإثنين" }, { key: "tue", label: "الثلاثاء" }, { key: "wed", label: "الأربعاء" }, { key: "thu", label: "الخميس" }, { key: "fri", label: "الجمعة" }, { key: "sat", label: "السبت" }];
export function RetroDinerAbout({ workingHours }: AboutProps) {
  const hours = workingHours ?? {};
  if (!Object.values(hours).some((v) => v?.trim())) return null;
  return (
    <section className="max-w-3xl mx-auto px-6 py-10">
      <div className="border-4 border-primary rounded-xl p-5 grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm text-center">
        {WEEKDAYS.map((d) => (
          <div key={d.key}>
            <p className="font-bold text-heading">{d.label}</p>
            <p className="text-muted" dir="ltr">{hours[d.key]?.trim() || "مغلق"}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
