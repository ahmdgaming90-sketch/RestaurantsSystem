import type { HeroProps } from "@/themes/types";
export function RetroDinerHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  return (
    <section className="relative h-[48vh] min-h-[320px] w-full overflow-hidden border-b-8 border-accent">
      {coverUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={coverUrl} alt={name} className="h-full w-full object-cover" />
      ) : <div className="h-full w-full bg-surface" />}
      <div className="absolute inset-0 bg-primary/30 flex flex-col items-center justify-center text-center px-6">
        {logoUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={logoUrl} alt="" className="h-16 w-16 rounded-full object-cover mb-3 border-4 border-white" />
        )}
        <h1 className="font-df-display text-5xl font-black uppercase text-white [text-shadow:2px_2px_0_var(--df-color-accent)]">{name}</h1>
        {location && <p className="text-white text-sm mt-2">{location}</p>}
      </div>
    </section>
  );
}
