import type { GalleryProps } from "@/themes/types";
export function RetroDinerGallery({ imageUrls }: GalleryProps) {
  if (imageUrls.length < 3) return null;
  return (
    <section className="max-w-4xl mx-auto px-6 py-14 grid grid-cols-2 sm:grid-cols-4 gap-3">
      {imageUrls.slice(0, 8).map((url, i) => (
        // eslint-disable-next-line @next/next/no-img-element
        <img key={i} src={url} alt="" className="aspect-square w-full object-cover rounded-lg border-2 border-primary" / loading="lazy" decoding="async" />
      ))}
    </section>
  );
}
