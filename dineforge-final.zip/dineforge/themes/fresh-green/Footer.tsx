import { getFooterCopy } from "@/components/site-sections/footerContent";
import type { FooterProps } from "@/themes/types";
export function FreshGreenFooter({ restaurantName, settings }: FooterProps) {
  const copy = getFooterCopy(restaurantName, settings);
  return (
    <footer className="py-8 text-center text-xs text-muted">
      <p>{copy.copyrightLine}</p>
      {copy.showCredit && <p className="mt-1">{copy.creditText} <a href={copy.creditLink} target="_blank" rel="noopener noreferrer" className="text-primary">←</a></p>}
    </footer>
  );
}
