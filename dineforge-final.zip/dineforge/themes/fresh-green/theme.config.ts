import type { ColorTokens, ThemeDefinition } from "@/themes/types";
import { FreshGreenHero } from "./Hero";
import { FreshGreenAbout } from "./About";
import { FreshGreenMenu } from "./MenuGrid";
import { FreshGreenGallery } from "./Gallery";
import { FreshGreenContact } from "./Contact";
import { FreshGreenFooter } from "./Footer";

export const freshGreenPalette: ColorTokens = {
  primary: "#31523B", secondary: "#66705F", accent: "#9A9F55",
  background: "#F3F4EC", surface: "#FFFFFF", text: "#232821",
  border: "#DDE1D4", button: "#31523B", buttonText: "#FFFFFF",
  heading: "#232821", muted: "#66705F",
};

export const freshGreenDefinition: ThemeDefinition = {
  key: "fresh-green",
  isBuilt: true,
  Hero: FreshGreenHero, About: FreshGreenAbout, Menu: FreshGreenMenu,
  Gallery: FreshGreenGallery, Contact: FreshGreenContact, Footer: FreshGreenFooter,
  typography: { displayFont: "ui-sans-serif, system-ui, sans-serif", bodyFont: "ui-sans-serif, system-ui, sans-serif", personality: "طبيعي منعش" },
  cardStyle: "boxed-card",
  imageDisplayStyle: "circular",
  layoutVariant: "centered-column",
  animationDefaults: { hero: "slide", sections: "slide" },
  defaultPalette: freshGreenPalette,
};
