import type { HeroProps } from "@/themes/types";
export function FreshGreenHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  return (
    <section className="max-w-4xl mx-auto px-6 pt-10 grid sm:grid-cols-2 gap-6 items-center">
      <div>
        {logoUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={logoUrl} alt="" className="h-12 w-12 rounded-full object-cover mb-4" />
        )}
        <h1 className="font-df-display text-4xl text-heading leading-tight">{name}</h1>
        {location && <p className="text-sm text-muted mt-2">{location}</p>}
        {description && <p className="text-sm text-muted mt-4 leading-relaxed">{description}</p>}
      </div>
      <div className="h-64 rounded-[2.5rem] overflow-hidden">
        {coverUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={coverUrl} alt={name} className="h-full w-full object-cover" />
        ) : <div className="h-full w-full bg-surface" />}
      </div>
    </section>
  );
}
