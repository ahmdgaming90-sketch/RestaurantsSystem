import type { AboutProps } from "@/themes/types";
const WEEKDAYS = [{ key: "sun", label: "الأحد" }, { key: "mon", label: "الإثنين" }, { key: "tue", label: "الثلاثاء" }, { key: "wed", label: "الأربعاء" }, { key: "thu", label: "الخميس" }, { key: "fri", label: "الجمعة" }, { key: "sat", label: "السبت" }];
export function FreshGreenAbout({ workingHours }: AboutProps) {
  const hours = workingHours ?? {};
  if (!Object.values(hours).some((v) => v?.trim())) return null;
  return (
    <section className="max-w-4xl mx-auto px-6 py-14">
      <div className="bg-surface rounded-[2rem] p-6 grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
        {WEEKDAYS.map((d) => (
          <div key={d.key} className="text-center">
            <p className="text-heading">{d.label}</p>
            <p className="text-muted mt-1" dir="ltr">{hours[d.key]?.trim() || "مغلق"}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
