import type { GalleryProps } from "@/themes/types";
export function CoastalGallery({ imageUrls }: GalleryProps) {
  if (imageUrls.length < 3) return null;
  return (
    <section className="flex gap-3 overflow-x-auto px-6 py-14 max-w-3xl mx-auto">
      {imageUrls.slice(0, 8).map((url, i) => (
        // eslint-disable-next-line @next/next/no-img-element
        <img key={i} src={url} alt="" className="h-40 w-56 object-cover rounded-2xl shrink-0" / loading="lazy" decoding="async" />
      ))}
    </section>
  );
}
