import type { HeroProps } from "@/themes/types";
export function CoastalHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  return (
    <section className="relative h-[58vh] min-h-[360px] w-full overflow-hidden">
      {coverUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={coverUrl} alt={name} className="h-full w-full object-cover" />
      ) : <div className="h-full w-full bg-surface" />}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/20 via-transparent to-background" />
      <div className="absolute inset-x-0 bottom-8 text-center px-6">
        {logoUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={logoUrl} alt="" className="h-14 w-14 rounded-full object-cover mx-auto mb-3 border-2 border-white" />
        )}
        <h1 className="font-df-display text-4xl text-white drop-shadow">{name}</h1>
        {location && <p className="text-white/90 text-sm mt-2">{location}</p>}
      </div>
    </section>
  );
}
