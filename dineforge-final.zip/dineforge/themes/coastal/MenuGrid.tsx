"use client";
import { useState } from "react";
import { AddToCartButton } from "@/components/cart/AddToCartButton";
import type { MenuProps } from "@/themes/types";

// cardStyle: horizontal-strip واسع — منسابة بدون حواف حادة، ألوان بحرية
export function CoastalMenu({ categories, products }: MenuProps) {
  const [active, setActive] = useState<string | "all">("all");
  if (products.length === 0) return null;
  const cats = categories.filter((c) => products.some((p) => p.category_id === c.id));
  const items = active === "all" ? products : products.filter((p) => p.category_id === active);

  return (
    <section id="menu" className="max-w-3xl mx-auto px-6 py-14">
      <h2 className="font-df-display text-2xl text-heading mb-6">قائمة الطعام</h2>
      {cats.length > 1 && (
        <div className="flex gap-2 flex-wrap mb-6">
          <button onClick={() => setActive("all")} className={`px-4 py-1.5 rounded-full text-sm ${active === "all" ? "bg-button text-button-ink" : "bg-surface text-muted"}`}>الكل</button>
          {cats.map((c) => (
            <button key={c.id} onClick={() => setActive(c.id)} className={`px-4 py-1.5 rounded-full text-sm ${active === c.id ? "bg-button text-button-ink" : "bg-surface text-muted"}`}>{c.name}</button>
          ))}
        </div>
      )}
      <div className="space-y-4">
        {items.map((p) => (
          <div key={p.id} className="flex items-center gap-5 bg-surface rounded-2xl p-4">
            {p.image_url && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={p.image_url} alt={p.name} className="h-20 w-28 rounded-xl object-cover shrink-0" / loading="lazy" decoding="async" />
            )}
            <div className="flex-1 min-w-0">
              <p className="text-heading font-medium">{p.name}</p>
              {p.description && <p className="text-xs text-muted mt-1">{p.description}</p>}
            </div>
            <span className="text-primary shrink-0" dir="ltr">{p.price.toFixed(2)}</span>
            <AddToCartButton productId={p.id} name={p.name} price={p.price} />
          </div>
        ))}
      </div>
    </section>
  );
}
