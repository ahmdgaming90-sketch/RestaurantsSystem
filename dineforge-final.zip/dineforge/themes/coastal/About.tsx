import type { AboutProps } from "@/themes/types";
const WEEKDAYS = [{ key: "sun", label: "الأحد" }, { key: "mon", label: "الإثنين" }, { key: "tue", label: "الثلاثاء" }, { key: "wed", label: "الأربعاء" }, { key: "thu", label: "الخميس" }, { key: "fri", label: "الجمعة" }, { key: "sat", label: "السبت" }];
export function CoastalAbout({ workingHours }: AboutProps) {
  const hours = workingHours ?? {};
  if (!Object.values(hours).some((v) => v?.trim())) return null;
  return (
    <section className="max-w-3xl mx-auto px-6 py-14">
      <div className="rounded-2xl bg-surface p-6 grid sm:grid-cols-4 gap-4 text-sm text-center">
        {WEEKDAYS.map((d) => (
          <div key={d.key}>
            <p className="text-heading">{d.label}</p>
            <p className="text-muted mt-1" dir="ltr">{hours[d.key]?.trim() || "مغلق"}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
