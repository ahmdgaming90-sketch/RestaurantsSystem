import type { ColorTokens, ThemeDefinition } from "@/themes/types";
import { CoastalHero } from "./Hero";
import { CoastalAbout } from "./About";
import { CoastalMenu } from "./MenuGrid";
import { CoastalGallery } from "./Gallery";
import { CoastalContact } from "./Contact";
import { CoastalFooter } from "./Footer";

export const coastalPalette: ColorTokens = {
  primary: "#164A57", secondary: "#64777B", accent: "#C88B4A",
  background: "#F1F6F5", surface: "#FFFFFF", text: "#16262A",
  border: "#D7E3E4", button: "#164A57", buttonText: "#FFFFFF",
  heading: "#16262A", muted: "#64777B",
};

export const coastalDefinition: ThemeDefinition = {
  key: "coastal",
  isBuilt: true,
  Hero: CoastalHero, About: CoastalAbout, Menu: CoastalMenu,
  Gallery: CoastalGallery, Contact: CoastalContact, Footer: CoastalFooter,
  typography: { displayFont: "Georgia, serif", bodyFont: "ui-sans-serif, system-ui, sans-serif", personality: "منعش ساحلي هادئ" },
  cardStyle: "horizontal-strip",
  imageDisplayStyle: "full-bleed",
  layoutVariant: "full-bleed-sections",
  animationDefaults: { hero: "slide", sections: "slide" },
  defaultPalette: coastalPalette,
};
