import { getFooterCopy } from "@/components/site-sections/footerContent";
import type { FooterProps } from "@/themes/types";
export function CoastalFooter({ restaurantName, settings }: FooterProps) {
  const copy = getFooterCopy(restaurantName, settings);
  return (
    <footer className="bg-surface py-8 text-center text-xs text-muted mt-8">
      <p>{copy.copyrightLine}</p>
      {copy.showCredit && <p className="mt-1">{copy.creditText} <a href={copy.creditLink} target="_blank" rel="noopener noreferrer" className="text-primary">←</a></p>}
    </footer>
  );
}
