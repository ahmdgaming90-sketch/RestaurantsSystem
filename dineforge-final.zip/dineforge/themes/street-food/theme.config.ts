import type { ColorTokens, ThemeDefinition } from "@/themes/types";
import { StreetFoodHero } from "./Hero";
import { StreetFoodAbout } from "./About";
import { StreetFoodMenu } from "./MenuGrid";
import { StreetFoodGallery } from "./Gallery";
import { StreetFoodContact } from "./Contact";
import { StreetFoodFooter } from "./Footer";

export const streetFoodPalette: ColorTokens = {
  primary: "#181818", secondary: "#66615A", accent: "#D95A32",
  background: "#F4F1EA", surface: "#FFFFFF", text: "#181818",
  border: "#202020", button: "#D95A32", buttonText: "#FFFFFF",
  heading: "#181818", muted: "#66615A",
};

export const streetFoodDefinition: ThemeDefinition = {
  key: "street-food",
  isBuilt: true,
  Hero: StreetFoodHero, About: StreetFoodAbout, Menu: StreetFoodMenu,
  Gallery: StreetFoodGallery, Contact: StreetFoodContact, Footer: StreetFoodFooter,
  typography: { displayFont: "'Arial Black', Impact, sans-serif", bodyFont: "ui-sans-serif, system-ui, sans-serif", personality: "ديناميكي حيوي" },
  cardStyle: "horizontal-strip",
  imageDisplayStyle: "grid",
  layoutVariant: "asymmetric-grid",
  animationDefaults: { hero: "quick-scale", sections: "stagger" },
  defaultPalette: streetFoodPalette,
};
