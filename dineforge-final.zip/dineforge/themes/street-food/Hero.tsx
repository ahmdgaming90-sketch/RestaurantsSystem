import type { HeroProps } from "@/themes/types";
export function StreetFoodHero({ name, description, coverUrl, logoUrl, location }: HeroProps) {
  return (
    <section className="relative px-4 pt-4">
      <div className="relative h-[46vh] min-h-[300px] w-full overflow-hidden rounded-lg -rotate-1">
        {coverUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={coverUrl} alt={name} className="h-full w-full object-cover" />
        ) : <div className="h-full w-full bg-surface" />}
      </div>
      <div className="max-w-2xl mx-auto text-center mt-6 rotate-1">
        {logoUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={logoUrl} alt="" className="h-14 w-14 rounded-full object-cover mx-auto mb-3" />
        )}
        <h1 className="font-df-display text-4xl font-black uppercase text-heading">{name}</h1>
        {location && <p className="text-sm text-muted mt-1">{location}</p>}
        {description && <p className="text-sm text-muted mt-3">{description}</p>}
      </div>
    </section>
  );
}
