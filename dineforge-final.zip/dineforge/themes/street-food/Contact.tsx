import type { ContactProps } from "@/themes/types";
export function StreetFoodContact({ whatsappNumber, location }: ContactProps) {
  return (
    <section className="max-w-md mx-auto px-6 py-14 text-center">
      <a href={`https://wa.me/${whatsappNumber.replace(/[^0-9]/g, "")}`} className="inline-block bg-accent text-white font-bold px-6 py-3 rounded-full" dir="ltr">
        {whatsappNumber}
      </a>
      {location && <p className="text-muted text-sm mt-3">{location}</p>}
    </section>
  );
}
