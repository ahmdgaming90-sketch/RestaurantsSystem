"use client";
import { useState } from "react";
import { AddToCartButton } from "@/components/cart/AddToCartButton";
import { StaggerGroup } from "@/components/site-sections/RevealOnScroll";
import type { MenuProps } from "@/themes/types";

// cardStyle: horizontal-strip كبيرة (صورة+اسم+سعر+وصف)، دخول متتالٍ (stagger)
export function StreetFoodMenu({ categories, products }: MenuProps) {
  const [active, setActive] = useState<string | "all">("all");
  if (products.length === 0) return null;
  const cats = categories.filter((c) => products.some((p) => p.category_id === c.id));
  const items = active === "all" ? products : products.filter((p) => p.category_id === active);

  return (
    <section id="menu" className="max-w-2xl mx-auto px-6 py-14">
      <h2 className="font-df-display text-3xl font-black uppercase text-heading mb-6">القائمة</h2>
      {cats.length > 1 && (
        <div className="flex gap-2 flex-wrap mb-6">
          <button onClick={() => setActive("all")} className={`px-4 py-1.5 rounded text-sm font-bold ${active === "all" ? "bg-accent text-white" : "bg-surface text-muted"}`}>الكل</button>
          {cats.map((c) => (
            <button key={c.id} onClick={() => setActive(c.id)} className={`px-4 py-1.5 rounded text-sm font-bold ${active === c.id ? "bg-accent text-white" : "bg-surface text-muted"}`}>{c.name}</button>
          ))}
        </div>
      )}
      <div className="space-y-4">
        <StaggerGroup
          items={items}
          render={(p: any) => (
            <div className="flex gap-4 bg-surface rounded-xl p-3 items-center">
              {p.image_url && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={p.image_url} alt={p.name} className="h-20 w-20 rounded-lg object-cover shrink-0" / loading="lazy" decoding="async" />
              )}
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-baseline">
                  <span className="font-df-display font-bold text-heading">{p.name}</span>
                  <span className="text-accent font-black" dir="ltr">{p.price.toFixed(2)}</span>
                </div>
                {p.description && <p className="text-xs text-muted mt-1">{p.description}</p>}
                <div className="mt-2"><AddToCartButton productId={p.id} name={p.name} price={p.price} /></div>
              </div>
            </div>
          )}
        />
      </div>
    </section>
  );
}
