import type { AboutProps } from "@/themes/types";
const WEEKDAYS = [{ key: "sun", label: "الأحد" }, { key: "mon", label: "الإثنين" }, { key: "tue", label: "الثلاثاء" }, { key: "wed", label: "الأربعاء" }, { key: "thu", label: "الخميس" }, { key: "fri", label: "الجمعة" }, { key: "sat", label: "السبت" }];
export function StreetFoodAbout({ workingHours }: AboutProps) {
  const hours = workingHours ?? {};
  if (!Object.values(hours).some((v) => v?.trim())) return null;
  return (
    <section className="max-w-2xl mx-auto px-6 py-10 flex flex-wrap justify-center gap-3">
      {WEEKDAYS.map((d) => (
        <span key={d.key} className="bg-accent text-white text-xs font-bold px-3 py-1.5 rounded-full">
          {d.label} <span dir="ltr">{hours[d.key]?.trim() || "مغلق"}</span>
        </span>
      ))}
    </section>
  );
}
