import { type NextRequest, NextResponse } from "next/server";
import { updateSession } from "@/lib/supabase/middleware";
import { isReservedSlug } from "@/lib/reserved-slugs";

export async function middleware(request: NextRequest) {
  const { response, user, profileRole } = await updateSession(request);
  const path = request.nextUrl.pathname;
  const firstSegment = path.split("/").filter(Boolean)[0] ?? "";

  // ---- 1) حماية لوحة Owner ----
  if (path.startsWith("/owner")) {
    if (!user || profileRole !== "owner") {
      const loginUrl = new URL("/login", request.url);
      loginUrl.searchParams.set("redirectTo", path);
      return NextResponse.redirect(loginUrl);
    }
    return response;
  }

  // ---- 2) حماية لوحة Manager ----
  if (path.startsWith("/manager")) {
    if (!user || (profileRole !== "manager" && profileRole !== "owner")) {
      const loginUrl = new URL("/login", request.url);
      loginUrl.searchParams.set("redirectTo", path);
      return NextResponse.redirect(loginUrl);
    }
    // ملاحظة: التحقق من "هل هو مدير هذا المطعم بالتحديد" يتم داخل الصفحة/الـ layout
    // نفسها عبر requireOwnerOrManagerOf، لأن ذلك يحتاج قراءة restaurant_id من الـ route.
    return response;
  }

  // ---- 3) مسارات النظام الأخرى (auth, api, أصول Next) تمر بدون تدخل ----
  if (isReservedSlug(firstSegment) || firstSegment === "") {
    return response;
  }

  // ---- 4) أي مسار آخر من مستوى الجذر يُعامل كـ /[slug] لموقع مطعم عام ----
  // لا حاجة لأي تحقق صلاحيات هنا؛ صفحة [slug] نفسها تتحقق من وجود المطعم ونشاطه.
  return response;
}

export const config = {
  matcher: [
    /*
     * يطبَّق على كل المسارات ما عدا:
     * - ملفات Next الداخلية (_next/static, _next/image)
     * - الأصول الثابتة الشائعة
     */
    "/((?!_next/static|_next/image|favicon.ico).*)",
  ],
};
