import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "DineForge",
  description: "منصة إنشاء وإدارة مواقع المطاعم",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="font-df-body antialiased">{children}</body>
    </html>
  );
}
