"use client";

// خطأ ضمن الصفحات العادية (RootLayout ما زال يعمل ويوفّر <html>/<body>، فلا نكرّرهما هنا).
// للأخطاء الكارثية التي تكسر RootLayout نفسه، انظر app/global-error.tsx (يملك <html>/<body> خاصة به).
export default function RootError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <main className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
      <div className="text-center max-w-sm">
        <p className="text-lg font-medium text-slate-900">حدث خطأ غير متوقع</p>
        <p className="text-sm text-slate-500 mt-2">
          نعتذر عن الإزعاج. حاول إعادة تحميل الصفحة، وإن استمرت المشكلة تواصل مع الدعم.
        </p>
        <button
          onClick={() => reset()}
          className="mt-5 rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
        >
          إعادة المحاولة
        </button>
      </div>
    </main>
  );
}
