export default function ManagerDashboardPage() {
  return (
    <main className="p-6">
      <h1 className="text-xl font-semibold">لوحة المدير — Dashboard</h1>
      <p className="text-sm text-secondary mt-2">
        هذه الصفحة مبدئية ضمن المرحلة الأولى. إدارة المنتجات والأقسام تُبنى في مرحلة "لوحة Manager".
      </p>
    </main>
  );
}
