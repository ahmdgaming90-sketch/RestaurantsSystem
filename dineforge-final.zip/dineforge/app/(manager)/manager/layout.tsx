import { redirect } from "next/navigation";
import { getCurrentActor } from "@/lib/permissions";

export default async function ManagerLayout({ children }: { children: React.ReactNode }) {
  const actor = await getCurrentActor();
  if (!actor) {
    redirect("/login");
  }
  // ملاحظة: هذا يتحقق فقط من "هو owner أو manager عمومًا".
  // التحقق من "هو مدير هذا المطعم بالتحديد" يتم داخل كل صفحة فرعية (products, orders, ...)
  // عبر requireOwnerOrManagerOf(restaurantId) بعد أن يُعرف restaurant_id الخاص بالمدير المسجّل دخوله.
  if (actor.role !== "owner" && actor.role !== "manager") {
    redirect("/login");
  }

  return <div className="min-h-screen">{children}</div>;
}
