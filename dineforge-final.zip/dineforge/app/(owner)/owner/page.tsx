import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

function startOfTodayISO() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
}
function startOfWeekISO() {
  const d = new Date();
  d.setDate(d.getDate() - 7);
  return d.toISOString();
}

export default async function OwnerDashboardPage() {
  const supabase = createClient();

  const [
    { count: totalRestaurants },
    { count: activeRestaurants },
    { count: totalProducts },
    { count: ordersToday },
    { count: ordersThisWeek },
    { count: totalOrders },
    { data: recentRestaurants },
    { data: recentOrders },
  ] = await Promise.all([
    supabase.from("restaurants").select("id", { count: "exact", head: true }),
    supabase.from("restaurants").select("id", { count: "exact", head: true }).eq("is_active", true),
    supabase.from("products").select("id", { count: "exact", head: true }),
    supabase.from("orders").select("id", { count: "exact", head: true }).gte("created_at", startOfTodayISO()),
    supabase.from("orders").select("id", { count: "exact", head: true }).gte("created_at", startOfWeekISO()),
    supabase.from("orders").select("id", { count: "exact", head: true }),
    supabase
      .from("restaurants")
      .select("id, name, slug, is_active, created_at")
      .order("created_at", { ascending: false })
      .limit(5),
    supabase
      .from("orders")
      .select("id, customer_name, total, created_at, restaurant:restaurants(name, slug)")
      .order("created_at", { ascending: false })
      .limit(6),
  ]);

  const stats = [
    { label: "إجمالي المطاعم", value: totalRestaurants ?? 0 },
    { label: "المطاعم النشطة", value: activeRestaurants ?? 0 },
    { label: "إجمالي المنتجات", value: totalProducts ?? 0 },
    { label: "طلبات اليوم", value: ordersToday ?? 0 },
    { label: "طلبات آخر 7 أيام", value: ordersThisWeek ?? 0 },
    { label: "إجمالي الطلبات", value: totalOrders ?? 0 },
  ];

  return (
    <main className="p-8 space-y-10 max-w-6xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">نظرة عامة</h1>
          <p className="text-sm text-slate-500 mt-1">أداء النظام والمطاعم ككل</p>
        </div>
        <Link
          href="/owner/restaurants/new"
          className="rounded-lg bg-slate-900 px-4 py-2.5 text-sm font-medium text-white hover:bg-slate-800"
        >
          + إنشاء مطعم جديد
        </Link>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-slate-200 bg-white p-5">
            <p className="text-sm text-slate-500">{s.label}</p>
            <p className="text-3xl font-semibold text-slate-900 mt-1">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 gap-8">
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-medium text-slate-900">أحدث المطاعم</h2>
            <Link href="/owner/restaurants" className="text-sm text-slate-500 hover:text-slate-900">
              عرض الكل
            </Link>
          </div>
          {recentRestaurants && recentRestaurants.length > 0 ? (
            <ul className="divide-y divide-slate-100 border border-slate-200 rounded-xl bg-white overflow-hidden">
              {recentRestaurants.map((r) => (
                <li key={r.id} className="flex items-center justify-between px-4 py-3">
                  <div>
                    <Link href={`/owner/restaurants/${r.id}`} className="font-medium text-slate-900 hover:underline">
                      {r.name}
                    </Link>
                    <p className="text-xs text-slate-500" dir="ltr">/{r.slug}</p>
                  </div>
                  <span
                    className={`text-xs rounded-full px-2 py-1 ${
                      r.is_active ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"
                    }`}
                  >
                    {r.is_active ? "نشط" : "غير نشط"}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-slate-500">لا توجد مطاعم بعد.</p>
          )}
        </div>

        <div>
          <h2 className="font-medium text-slate-900 mb-3">أحدث الطلبات عبر النظام</h2>
          {recentOrders && recentOrders.length > 0 ? (
            <ul className="divide-y divide-slate-100 border border-slate-200 rounded-xl bg-white overflow-hidden">
              {recentOrders.map((o: any) => (
                <li key={o.id} className="flex items-center justify-between px-4 py-3">
                  <div>
                    <p className="text-sm font-medium text-slate-900">{o.customer_name}</p>
                    <p className="text-xs text-slate-500">{o.restaurant?.name}</p>
                  </div>
                  <span className="text-sm text-slate-700" dir="ltr">{Number(o.total).toFixed(2)}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-slate-500">لا توجد طلبات بعد.</p>
          )}
        </div>
      </div>
    </main>
  );
}
