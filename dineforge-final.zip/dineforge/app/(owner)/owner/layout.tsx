import { redirect } from "next/navigation";
import { getCurrentActor } from "@/lib/permissions";
import { OwnerSidebar } from "@/components/dashboard/OwnerSidebar";

export default async function OwnerLayout({ children }: { children: React.ReactNode }) {
  // middleware.ts يمنع الدخول أصلاً، لكن هذا التحقق الثاني يحمي حتى لو استُدعيت الصفحة
  // بطريقة تتجاوز الـ middleware (مثال: استدعاء مباشر أثناء render مضمّن)، حسب مبدأ Defense in depth.
  const actor = await getCurrentActor();
  if (!actor || actor.role !== "owner") {
    redirect("/login");
  }

  return (
    <div className="min-h-screen flex bg-slate-50">
      <OwnerSidebar />
      <div className="flex-1 min-w-0">{children}</div>
    </div>
  );
}
