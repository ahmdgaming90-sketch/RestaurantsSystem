import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function RestaurantsListPage() {
  const supabase = createClient();

  const { data: restaurants } = await supabase
    .from("restaurants")
    .select("id, name, slug, is_active, created_at, theme_id, themes(name)")
    .order("created_at", { ascending: false });

  return (
    <main className="p-8 space-y-6 max-w-5xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">جميع المطاعم</h1>
          <p className="text-sm text-slate-500 mt-1">{restaurants?.length ?? 0} مطعم مسجّل</p>
        </div>
        <Link
          href="/owner/restaurants/new"
          className="rounded-lg bg-slate-900 px-4 py-2.5 text-sm font-medium text-white hover:bg-slate-800"
        >
          + إنشاء مطعم جديد
        </Link>
      </div>

      {restaurants && restaurants.length > 0 ? (
        <div className="border border-slate-200 rounded-xl bg-white overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 border-b border-slate-200">
              <tr>
                <th className="text-right px-5 py-3 font-medium">الاسم</th>
                <th className="text-right px-5 py-3 font-medium">الرابط</th>
                <th className="text-right px-5 py-3 font-medium">القالب</th>
                <th className="text-right px-5 py-3 font-medium">الحالة</th>
                <th className="text-right px-5 py-3 font-medium"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {restaurants.map((r: any) => (
                <tr key={r.id} className="hover:bg-slate-50">
                  <td className="px-5 py-3 font-medium text-slate-900">{r.name}</td>
                  <td className="px-5 py-3" dir="ltr">
                    <a href={`/${r.slug}`} target="_blank" className="text-slate-600 hover:underline">
                      /{r.slug}
                    </a>
                  </td>
                  <td className="px-5 py-3 text-slate-600">{r.themes?.name ?? "—"}</td>
                  <td className="px-5 py-3">
                    <span
                      className={`text-xs rounded-full px-2 py-1 ${
                        r.is_active ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"
                      }`}
                    >
                      {r.is_active ? "نشط" : "غير نشط"}
                    </span>
                  </td>
                  <td className="px-5 py-3">
                    <Link href={`/owner/restaurants/${r.id}`} className="text-slate-600 hover:text-slate-900 hover:underline">
                      تعديل
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="rounded-xl border border-dashed border-slate-300 bg-white p-10 text-center text-sm text-slate-500">
          لا توجد مطاعم بعد. ابدأ بإنشاء أول مطعم.
        </div>
      )}
    </main>
  );
}
