import { notFound } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { getThemesAction } from "@/lib/actions/restaurants";
import { RestaurantForm } from "@/components/dashboard/RestaurantForm";
import { RestaurantStats } from "@/components/dashboard/RestaurantStats";

export default async function EditRestaurantPage({ params }: { params: { id: string } }) {
  const supabase = createClient();

  const { data: restaurant } = await supabase
    .from("restaurants")
    .select(
      "id, name, slug, description, whatsapp_number, location, theme_id, color_palette, logo_url, cover_url"
    )
    .eq("id", params.id)
    .maybeSingle();

  if (!restaurant) {
    notFound();
  }

  const themesResult = await getThemesAction();
  const themes = themesResult.ok ? themesResult.data : [];

  return (
    <main className="p-8 space-y-8 max-w-5xl">
      <div>
        <Link href="/owner/restaurants" className="text-sm text-slate-500 hover:text-slate-900">
          ← كل المطاعم
        </Link>
        <div className="flex items-center justify-between mt-2">
          <div>
            <h1 className="text-2xl font-semibold text-slate-900">{restaurant.name}</h1>
            <div className="flex items-center gap-3 mt-1">
              <p className="text-sm text-slate-500" dir="ltr">/{restaurant.slug}</p>
              <a
                href={`/${restaurant.slug}`}
                target="_blank"
                className="text-xs text-slate-500 underline hover:text-slate-900"
              >
                عرض الموقع العام ↗
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 rounded-xl border border-slate-200 bg-white p-6">
          <RestaurantForm themes={themes} restaurant={restaurant as any} />
        </div>
        <div>
          <RestaurantStats restaurantId={restaurant.id} />
        </div>
      </div>
    </main>
  );
}
