import Link from "next/link";
import { getThemesAction } from "@/lib/actions/restaurants";
import { RestaurantForm } from "@/components/dashboard/RestaurantForm";

export default async function NewRestaurantPage() {
  const themesResult = await getThemesAction();
  const themes = themesResult.ok ? themesResult.data : [];

  return (
    <main className="p-8 max-w-3xl space-y-6">
      <div>
        <Link href="/owner/restaurants" className="text-sm text-slate-500 hover:text-slate-900">
          ← كل المطاعم
        </Link>
        <h1 className="text-2xl font-semibold text-slate-900 mt-2">إنشاء مطعم جديد</h1>
      </div>
      <div className="rounded-xl border border-slate-200 bg-white p-6">
        <RestaurantForm themes={themes} />
      </div>
    </main>
  );
}
