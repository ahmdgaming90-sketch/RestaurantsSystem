import { createClient } from "@/lib/supabase/server";

function formatDate(iso: string) {
  return new Date(iso).toLocaleString("ar-SA", { dateStyle: "medium", timeStyle: "short" });
}

export default async function SystemHealthPage() {
  const supabase = createClient();

  const [{ data: errors, error: errorsError }, { data: allRestaurants }, { data: settingsRows }] =
    await Promise.all([
      supabase
        .from("error_logs")
        .select("id, scope, message, created_at")
        .order("created_at", { ascending: false })
        .limit(50),
      supabase.from("restaurants").select("id, name"),
      supabase.from("restaurant_settings").select("restaurant_id"),
    ]);

  // فحص سلامة: كل مطعم يجب أن يملك صف restaurant_settings (يُنشأ تلقائيًا عبر trigger).
  // إن ظهر أي مطعم هنا فهذا يشير لمشكلة حقيقية تستحق التحقيق (فشل الـ trigger، أو تلاعب مباشر بالقاعدة).
  const settingsIds = new Set((settingsRows ?? []).map((s) => s.restaurant_id));
  const restaurantsMissingSettings = (allRestaurants ?? []).filter((r) => !settingsIds.has(r.id));

  const checks = [
    {
      label: "مطاعم بدون إعدادات افتراضية (restaurant_settings)",
      ok: restaurantsMissingSettings.length === 0,
      detail:
        restaurantsMissingSettings.length === 0
          ? "كل المطاعم لديها الإعدادات الافتراضية المطلوبة."
          : `${restaurantsMissingSettings.length} مطعم بدون إعدادات: ${restaurantsMissingSettings
              .map((r) => r.name)
              .join("، ")}`,
    },
  ];

  return (
    <main className="p-8 space-y-10 max-w-4xl">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">صحة النظام</h1>
        <p className="text-sm text-slate-500 mt-1">الأخطاء المسجّلة وفحوصات سلامة البيانات الأساسية</p>
      </div>

      <div>
        <h2 className="font-medium text-slate-900 mb-3">فحوصات سلامة البيانات</h2>
        <ul className="space-y-2">
          {checks.map((c) => (
            <li
              key={c.label}
              className={`rounded-lg border px-4 py-3 text-sm ${
                c.ok ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "border-amber-300 bg-amber-50 text-amber-800"
              }`}
            >
              <p className="font-medium">{c.ok ? "✓" : "⚠"} {c.label}</p>
              <p className="text-xs mt-1 opacity-80">{c.detail}</p>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <h2 className="font-medium text-slate-900 mb-3">آخر الأخطاء المسجّلة</h2>

        {errorsError && (
          <p className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            تعذّر تحميل سجل الأخطاء حاليًا.
          </p>
        )}

        {!errorsError && (!errors || errors.length === 0) && (
          <div className="rounded-xl border border-dashed border-slate-300 bg-white p-10 text-center text-sm text-slate-500">
            لا توجد أي أخطاء مسجّلة — النظام يعمل دون مشاكل مكتشفة حتى الآن.
          </div>
        )}

        {errors && errors.length > 0 && (
          <ul className="divide-y divide-slate-100 border border-slate-200 rounded-xl bg-white overflow-hidden">
            {errors.map((e) => (
              <li key={e.id} className="px-5 py-3 text-sm">
                <div className="flex items-center justify-between gap-3">
                  <p className="font-medium text-slate-900 truncate">{e.scope}</p>
                  <span className="text-xs text-slate-400 shrink-0" dir="ltr">{formatDate(e.created_at)}</span>
                </div>
                <p className="text-xs text-slate-500 mt-1">{e.message}</p>
              </li>
            ))}
          </ul>
        )}
      </div>
    </main>
  );
}
