export default function OwnerLoading() {
  return (
    <main className="p-8 space-y-6 max-w-5xl animate-pulse">
      <div className="h-7 w-48 bg-slate-200 rounded" />
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="h-24 rounded-xl bg-slate-200" />
        ))}
      </div>
      <div className="h-40 rounded-xl bg-slate-200" />
    </main>
  );
}
