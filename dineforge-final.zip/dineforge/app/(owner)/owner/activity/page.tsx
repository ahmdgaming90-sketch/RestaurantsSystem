import { createClient } from "@/lib/supabase/server";

const ACTION_LABELS: Record<string, string> = {
  "restaurant.create": "إنشاء مطعم",
  "restaurant.update": "تعديل بيانات مطعم",
  "restaurant.images_update": "تحديث شعار/غلاف مطعم",
};

function formatDate(iso: string) {
  return new Date(iso).toLocaleString("ar-SA", { dateStyle: "medium", timeStyle: "short" });
}

export default async function ActivityLogPage() {
  const supabase = createClient();
  const { data: entries, error } = await supabase
    .from("audit_log")
    .select("id, actor_role, action, target_type, target_id, metadata, created_at")
    .order("created_at", { ascending: false })
    .limit(100);

  return (
    <main className="p-8 space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-semibold text-slate-900">سجل النشاط</h1>
        <p className="text-sm text-slate-500 mt-1">آخر 100 عملية إدارية مهمة في النظام</p>
      </div>

      {error && (
        <p className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          تعذّر تحميل سجل النشاط حاليًا.
        </p>
      )}

      {!error && (!entries || entries.length === 0) && (
        <div className="rounded-xl border border-dashed border-slate-300 bg-white p-10 text-center text-sm text-slate-500">
          لا توجد أي عمليات مسجّلة بعد. ستظهر هنا كل عملية إنشاء أو تعديل مطعم.
        </div>
      )}

      {entries && entries.length > 0 && (
        <ul className="divide-y divide-slate-100 border border-slate-200 rounded-xl bg-white overflow-hidden">
          {entries.map((e) => (
            <li key={e.id} className="flex items-center justify-between px-5 py-3 text-sm">
              <div>
                <p className="text-slate-900 font-medium">{ACTION_LABELS[e.action] ?? e.action}</p>
                <p className="text-xs text-slate-500 mt-0.5">
                  {e.actor_role === "owner" ? "المالك" : e.actor_role === "manager" ? "مدير مطعم" : "—"}
                  {e.target_type ? ` · ${e.target_type}` : ""}
                </p>
              </div>
              <span className="text-xs text-slate-400 shrink-0" dir="ltr">{formatDate(e.created_at)}</span>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
