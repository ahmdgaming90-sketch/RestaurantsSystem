"use client";

export default function OwnerError({ error, reset }: { error: Error; reset: () => void }) {
  return (
    <main className="p-8 max-w-lg">
      <div className="rounded-xl border border-red-200 bg-red-50 p-6 text-center">
        <p className="font-medium text-red-800">تعذّر تحميل هذه الصفحة</p>
        <p className="text-sm text-red-700 mt-2">حدث خطأ أثناء جلب البيانات. حاول مجددًا.</p>
        <button
          onClick={() => reset()}
          className="mt-4 rounded-lg bg-red-700 px-4 py-2 text-sm font-medium text-white hover:bg-red-800"
        >
          إعادة المحاولة
        </button>
      </div>
    </main>
  );
}
