// صفحة تسجيل دخول Owner/Manager — نموذج مبدئي، سيُستكمل بمنطق فعلي (Server Action) في مرحلة لاحقة.
export default function LoginPage() {
  return (
    <main className="flex min-h-screen items-center justify-center p-6">
      <div className="w-full max-w-sm space-y-4">
        <h1 className="text-xl font-semibold">تسجيل الدخول — DineForge</h1>
        <p className="text-sm text-secondary">
          هذه الصفحة مبدئية ضمن المرحلة الأولى (الأساس). نموذج الدخول الفعلي عبر Supabase Auth
          يُضاف ضمن مرحلة "لوحة Owner" التالية.
        </p>
      </div>
    </main>
  );
}
