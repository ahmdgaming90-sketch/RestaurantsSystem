export default function RestaurantLoading() {
  return (
    <main className="animate-pulse">
      <div className="h-[52vh] min-h-[320px] w-full bg-slate-200" />
      <div className="mx-auto max-w-3xl px-6 py-16 space-y-4">
        <div className="h-6 w-40 bg-slate-200 rounded" />
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="h-16 bg-slate-100 rounded" />
        ))}
      </div>
    </main>
  );
}
