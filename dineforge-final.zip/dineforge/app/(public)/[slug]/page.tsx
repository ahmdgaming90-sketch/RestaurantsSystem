import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getThemeComponents } from "@/themes/registry";
import { RevealOnScroll } from "@/components/site-sections/RevealOnScroll";
import { CartWidget } from "@/components/cart/CartWidget";

type SectionRow = {
  section_key: string;
  is_visible: boolean;
  sort_order: number;
  animation: "fade" | "slide" | "zoom" | "reveal";
};

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const supabase = createClient();
  const { data } = await supabase
    .from("restaurants")
    .select("name, description, settings:restaurant_settings(seo_title, seo_description)")
    .eq("slug", params.slug)
    .maybeSingle();

  const r = data as any;
  if (!r) return {};

  return {
    title: r.settings?.seo_title || r.name,
    description: r.settings?.seo_description || r.description || undefined,
  };
}

export default async function RestaurantPage({ params }: { params: { slug: string } }) {
  const supabase = createClient();

  const { data: restaurant } = await supabase
    .from("restaurants")
    .select(
      `id, name, description, logo_url, cover_url, whatsapp_number, location, working_hours,
       theme:themes(key),
       order_settings:restaurant_order_settings(require_phone, pickup_note, thank_you_message),
       settings:restaurant_settings(footer_settings, order_button_settings)`
    )
    .eq("slug", params.slug)
    .maybeSingle();

  if (!restaurant) notFound();
  const r = restaurant as any;

  const [{ data: sections }, { data: categories }, { data: products }] = await Promise.all([
    supabase
      .from("restaurant_sections")
      .select("section_key, is_visible, sort_order, animation")
      .eq("restaurant_id", r.id)
      .eq("is_visible", true)
      .order("sort_order") as unknown as Promise<{ data: SectionRow[] | null }>,
    supabase.from("categories").select("id, name, sort_order").eq("restaurant_id", r.id).order("sort_order"),
    supabase
      .from("products")
      .select("id, name, description, price, image_url, category_id, sort_order")
      .eq("restaurant_id", r.id)
      .eq("is_available", true)
      .order("sort_order"),
  ]);

  const theme = getThemeComponents(r.theme?.key);
  const orderSettings = r.order_settings ?? { require_phone: true, pickup_note: "استلام من المطعم" };
  const galleryImages = Array.from(
    new Set((products ?? []).map((p: any) => p.image_url).filter(Boolean))
  ) as string[];

  const sectionList: SectionRow[] =
    sections && sections.length > 0
      ? sections
      : [
          // احتياطي فقط لو لسبب ما لم توجد صفوف restaurant_sections (لا يُفترض حدوثه بفضل trigger المرحلة 2)
          { section_key: "hero", is_visible: true, sort_order: 0, animation: "fade" },
          { section_key: "menu", is_visible: true, sort_order: 1, animation: "fade" },
          { section_key: "contact", is_visible: true, sort_order: 2, animation: "fade" },
        ];

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Restaurant",
    name: r.name,
    description: r.description || undefined,
    image: r.cover_url || r.logo_url || undefined,
    telephone: r.whatsapp_number,
    address: r.location || undefined,
    servesCuisine: "Restaurant",
  };

  return (
    <main>
      {/* بيانات منظّمة (Schema.org) لكل مطعم — تحسين ظهور فعلي في نتائج البحث، ديناميكي بالكامل */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      {sectionList.map((section) => {
        switch (section.section_key) {
          case "hero":
            return (
              <theme.Hero
                key="hero"
                name={r.name}
                description={r.description}
                coverUrl={r.cover_url}
                logoUrl={r.logo_url}
                location={r.location}
              />
            );
          case "about":
            return (
              <RevealOnScroll key="about" animation={section.animation}>
                <theme.About workingHours={r.working_hours} />
              </RevealOnScroll>
            );
          case "menu":
            return (
              <RevealOnScroll key="menu" animation={section.animation}>
                <theme.Menu categories={categories ?? []} products={(products ?? []) as any} />
              </RevealOnScroll>
            );
          case "gallery":
            return (
              <RevealOnScroll key="gallery" animation={section.animation}>
                <theme.Gallery imageUrls={galleryImages} />
              </RevealOnScroll>
            );
          case "contact":
            return (
              <RevealOnScroll key="contact" animation={section.animation}>
                <theme.Contact whatsappNumber={r.whatsapp_number} location={r.location} />
              </RevealOnScroll>
            );
          default:
            return null;
        }
      })}

      <theme.Footer restaurantName={r.name} settings={r.settings?.footer_settings} />

      <CartWidget
        restaurantId={r.id}
        restaurantName={r.name}
        whatsappNumber={r.whatsapp_number}
        pickupNote={orderSettings.pickup_note}
        thankYouMessage={orderSettings.thank_you_message}
        requirePhone={orderSettings.require_phone}
        buttonLabel={r.settings?.order_button_settings?.label || "إرسال الطلب عبر واتساب"}
        position={r.settings?.order_button_settings?.position || "fixed-bottom"}
      />
    </main>
  );
}
