import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { isReservedSlug } from "@/lib/reserved-slugs";
import { CartProvider } from "@/components/cart/CartProvider";
import { getThemeComponents } from "@/themes/registry";
import { buildPaletteCssVars } from "@/lib/theme-palette";

export default async function RestaurantLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { slug: string };
}) {
  // حارس مزدوج إضافي على مستوى الصفحة (بجانب middleware): يمنع أي slug محجوز
  // من الوصول لهذا الفرع أصلاً حتى لو تغيّر الـ middleware مستقبلاً.
  if (isReservedSlug(params.slug)) {
    notFound();
  }

  const supabase = createClient();
  const { data: restaurant } = await supabase
    .from("restaurants")
    .select("id, is_active, color_palette, font_family, theme:themes(key, default_palette)")
    .eq("slug", params.slug)
    .maybeSingle();

  if (!restaurant || !(restaurant as any).is_active) {
    notFound();
  }

  const r = restaurant as any;
  const themeKey = r.theme?.key as string | undefined;
  const theme = getThemeComponents(themeKey);

  // مصدر الحقيقة لألوان "افتراضي الثيم" هو عمود themes.default_palette في القاعدة —
  // قابل للتعديل مستقبلاً من لوحة تحكم (بدون أي نشر كود جديد)، وليس theme.defaultPalette
  // الثابتة في theme.config.ts إلا كـ fallback أخير لو كان عمود القاعدة فارغًا لأي سبب.
  const themeDefaultPalette = r.theme?.default_palette ?? theme.defaultPalette;

  // دمج ألوان المطعم (إن خصّصها المالك) فوق الألوان الافتراضية لهذا الثيم تحديدًا،
  // ثم حقنها كـ CSS variables — تلتقطها فئات Tailwind الموسّعة (bg-surface/text-heading/...)
  // في كل مكونات الثيم دون أي قيم لون ثابتة داخل JSX.
  const cssVars = {
    ...buildPaletteCssVars(themeDefaultPalette, r.color_palette),
    "--df-font-body":
      r.font_family && r.font_family !== "default" ? r.font_family : theme.typography.bodyFont,
    "--df-font-display":
      r.font_family && r.font_family !== "default" ? r.font_family : theme.typography.displayFont,
  } as React.CSSProperties;

  return (
    <div style={cssVars} className="bg-background min-h-screen font-df-body text-ink">
      <CartProvider restaurantId={r.id}>{children}</CartProvider>
    </div>
  );
}
