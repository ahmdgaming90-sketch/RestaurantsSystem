import Link from "next/link";

export default function RestaurantNotFound() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
      <div className="text-center max-w-sm">
        <p className="text-lg font-medium text-slate-900">هذا المطعم غير متاح</p>
        <p className="text-sm text-slate-500 mt-2">
          الرابط غير صحيح، أو أن هذا المطعم لم يعد نشطًا حاليًا.
        </p>
        <Link href="/" className="mt-5 inline-block text-sm text-slate-600 underline">
          العودة للرئيسية
        </Link>
      </div>
    </main>
  );
}
