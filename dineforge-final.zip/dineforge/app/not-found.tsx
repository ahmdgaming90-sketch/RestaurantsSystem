import Link from "next/link";

export default function GlobalNotFound() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
      <div className="text-center max-w-sm">
        <p className="text-lg font-medium text-slate-900">الصفحة غير موجودة</p>
        <p className="text-sm text-slate-500 mt-2">تحقق من الرابط، أو عد إلى الصفحة الرئيسية.</p>
        <Link
          href="/"
          className="mt-5 inline-block rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
        >
          العودة للرئيسية
        </Link>
      </div>
    </main>
  );
}
