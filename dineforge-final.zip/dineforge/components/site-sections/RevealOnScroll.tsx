"use client";

import { useEffect, useRef, useState } from "react";
import type { ThemeMotion } from "@/themes/types";

const HIDDEN_CLASS: Record<ThemeMotion, string> = {
  fade: "opacity-0",
  slide: "opacity-0 translate-y-6",
  zoom: "opacity-0 scale-95",
  reveal: "opacity-0 translate-y-3",
  cinematic: "opacity-0 scale-105",
  "quick-scale": "opacity-0 scale-90",
  stagger: "opacity-0 translate-y-4",
};

const DURATION_CLASS: Record<ThemeMotion, string> = {
  fade: "duration-700",
  slide: "duration-700",
  zoom: "duration-500",
  reveal: "duration-700",
  cinematic: "duration-[1400ms]",
  "quick-scale": "duration-300",
  stagger: "duration-500",
};

const VISIBLE_CLASS = "opacity-100 translate-y-0 scale-100";

/**
 * يطبّق حركة الدخول الخاصة بهوية كل ثيم عند دخول العنصر منطقة الرؤية، لأول مرة فقط.
 * يحترم prefers-reduced-motion عبر motion-reduce (Tailwind).
 */
export function RevealOnScroll({
  animation = "fade",
  delayMs = 0,
  children,
  className = "",
}: {
  animation?: ThemeMotion;
  delayMs?: number;
  children: React.ReactNode;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.15 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      style={{ transitionDelay: visible ? `${delayMs}ms` : "0ms" }}
      className={`transition-all ease-out motion-reduce:transition-none motion-reduce:opacity-100 motion-reduce:translate-y-0 motion-reduce:scale-100 ${
        DURATION_CLASS[animation]
      } ${visible ? VISIBLE_CLASS : HIDDEN_CLASS[animation]} ${className}`}
    >
      {children}
    </div>
  );
}

/**
 * يكرّر RevealOnScroll على عناصر قائمة بتأخير متتالٍ (تتالي دخول) — تُستخدم في الثيمات
 * التي تحمل "stagger" ضمن animationDefaults (مثال: Street Food, Editorial Fine Dining).
 */
export function StaggerGroup({
  items,
  animation = "stagger",
  stepMs = 80,
  render,
}: {
  items: any[];
  animation?: ThemeMotion;
  stepMs?: number;
  render: (item: any, index: number) => React.ReactNode;
}) {
  return (
    <>
      {items.map((item, i) => (
        <RevealOnScroll key={i} animation={animation} delayMs={i * stepMs}>
          {render(item, i)}
        </RevealOnScroll>
      ))}
    </>
  );
}
