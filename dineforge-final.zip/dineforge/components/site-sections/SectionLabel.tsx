export function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 mb-3">
      <span className="h-px w-6 bg-border" />
      <span className="text-xs tracking-[0.2em] text-muted">{children}</span>
    </div>
  );
}
