"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const NAV_ITEMS = [
  { href: "/owner", label: "نظرة عامة", icon: "◧" },
  { href: "/owner/restaurants", label: "المطاعم", icon: "▤" },
  { href: "/owner/activity", label: "سجل النشاط", icon: "◷" },
  { href: "/owner/system-health", label: "صحة النظام", icon: "◈" },
];

export function OwnerSidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-56 shrink-0 bg-slate-900 text-slate-300 min-h-screen flex flex-col">
      <div className="px-5 py-5 border-b border-slate-800">
        <p className="text-white font-semibold tracking-tight">DineForge</p>
        <p className="text-xs text-slate-500 mt-0.5">لوحة المالك</p>
      </div>
      <nav className="flex-1 py-4 space-y-0.5 px-2">
        {NAV_ITEMS.map((item) => {
          const isActive =
            item.href === "/owner" ? pathname === "/owner" : pathname?.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                isActive ? "bg-slate-800 text-white" : "hover:bg-slate-800/60 hover:text-white"
              }`}
            >
              <span className="text-base leading-none">{item.icon}</span>
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
