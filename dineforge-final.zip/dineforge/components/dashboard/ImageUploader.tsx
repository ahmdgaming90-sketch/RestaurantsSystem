"use client";

import { useRef, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type ImageUploaderProps = {
  label: string;
  restaurantId: string;
  kind: "logo" | "cover";
  currentUrl?: string | null;
  onUploaded: (publicUrl: string) => void;
};

const MAX_SIZE_MB = 5;
const ACCEPTED_TYPES = ["image/png", "image/jpeg", "image/webp"];

/**
 * يرفع من "استديو الجهاز" (input type=file عادي، يفتح معرض الصور/الكاميرا على الجوال تلقائيًا)
 * مباشرة إلى Supabase Storage، ضمن مسار restaurants/{restaurantId}/{kind}-{timestamp}.{ext}
 * الذي تعتمد عليه سياسات RLS في migration 0005.
 */
export function ImageUploader({ label, restaurantId, kind, currentUrl, onUploaded }: ImageUploaderProps) {
  const [preview, setPreview] = useState<string | null>(currentUrl ?? null);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setError(null);

    if (!ACCEPTED_TYPES.includes(file.type)) {
      setError("الصيغ المدعومة: PNG, JPEG, WEBP فقط.");
      return;
    }
    if (file.size > MAX_SIZE_MB * 1024 * 1024) {
      setError(`حجم الصورة يجب ألا يتجاوز ${MAX_SIZE_MB} ميجابايت.`);
      return;
    }

    const localPreview = URL.createObjectURL(file);
    setPreview(localPreview);
    setIsUploading(true);

    try {
      const supabase = createClient();
      const ext = file.name.split(".").pop() || "png";
      const path = `restaurants/${restaurantId}/${kind}-${Date.now()}.${ext}`;

      const { error: uploadError } = await supabase.storage
        .from("restaurant-assets")
        .upload(path, file, { upsert: false, cacheControl: "3600" });

      if (uploadError) {
        setError("فشل رفع الصورة: " + uploadError.message);
        setIsUploading(false);
        return;
      }

      const { data: publicUrlData } = supabase.storage.from("restaurant-assets").getPublicUrl(path);
      onUploaded(publicUrlData.publicUrl);
    } catch {
      setError("حدث خطأ غير متوقع أثناء الرفع.");
    } finally {
      setIsUploading(false);
    }
  }

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium">{label}</label>

      {preview ? (
        <img
          src={preview}
          alt={label}
          className="h-28 w-28 rounded object-cover border border-slate-200"
        />
      ) : (
        <div className="h-28 w-28 rounded border border-dashed border-slate-300 flex items-center justify-center text-xs text-slate-500">
          لا توجد صورة
        </div>
      )}

      <input
        ref={inputRef}
        type="file"
        accept={ACCEPTED_TYPES.join(",")}
        onChange={handleFileChange}
        disabled={isUploading}
        className="block text-sm"
      />

      {isUploading && <p className="text-xs text-slate-500">جاري الرفع...</p>}
      {error && <p className="text-xs text-red-600">{error}</p>}
    </div>
  );
}
