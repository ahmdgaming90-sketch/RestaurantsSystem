import { createClient } from "@/lib/supabase/server";

export async function RestaurantStats({ restaurantId }: { restaurantId: string }) {
  const supabase = createClient();

  const { data: orders } = await supabase
    .from("orders")
    .select("id, total, items, created_at")
    .eq("restaurant_id", restaurantId)
    .order("created_at", { ascending: false })
    .limit(200);

  const totalOrders = orders?.length ?? 0;
  const totalRevenue = (orders ?? []).reduce((sum, o) => sum + Number(o.total || 0), 0);

  // أفضل 3 منتجات بحسب عدد مرات الطلب — محسوبة من أرشيف عناصر الطلبات (items jsonb)
  const productCounts = new Map<string, { name: string; qty: number }>();
  for (const o of orders ?? []) {
    const items = (o.items as { name: string; quantity: number }[]) ?? [];
    for (const it of items) {
      const cur = productCounts.get(it.name) ?? { name: it.name, qty: 0 };
      cur.qty += it.quantity;
      productCounts.set(it.name, cur);
    }
  }
  const topProducts = Array.from(productCounts.values()).sort((a, b) => b.qty - a.qty).slice(0, 3);

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
      <h2 className="font-medium text-slate-900">إحصائيات هذا المطعم</h2>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-xs text-slate-500">عدد الطلبات (آخر 200)</p>
          <p className="text-2xl font-semibold text-slate-900 mt-1">{totalOrders}</p>
        </div>
        <div>
          <p className="text-xs text-slate-500">إجمالي الإيرادات المسجّلة</p>
          <p className="text-2xl font-semibold text-slate-900 mt-1" dir="ltr">
            {totalRevenue.toFixed(2)}
          </p>
        </div>
      </div>

      {topProducts.length > 0 ? (
        <div>
          <p className="text-xs text-slate-500 mb-2">الأكثر طلبًا</p>
          <ul className="space-y-1 text-sm">
            {topProducts.map((p) => (
              <li key={p.name} className="flex justify-between text-slate-700">
                <span>{p.name}</span>
                <span className="text-slate-400">×{p.qty}</span>
              </li>
            ))}
          </ul>
        </div>
      ) : (
        <p className="text-xs text-slate-400">لا توجد طلبات مسجّلة بعد لهذا المطعم.</p>
      )}
    </div>
  );
}
