"use client";

import { useEffect, useState, useTransition } from "react";
import { checkSlugAvailabilityAction } from "@/lib/actions/restaurants";
import { slugify } from "@/lib/slug";

type SlugFieldProps = {
  value: string;
  onChange: (value: string) => void;
  sourceName: string; // اسم المطعم، يُستخدم للتوليد التلقائي طالما المستخدم لم يعدّل الـ slug يدويًا
  excludeRestaurantId?: string; // عند التعديل: يستثني المطعم نفسه من فحص التكرار
};

export function SlugField({ value, onChange, sourceName, excludeRestaurantId }: SlugFieldProps) {
  const [touched, setTouched] = useState(false);
  const [status, setStatus] = useState<"idle" | "checking" | "available" | "unavailable">("idle");
  const [reason, setReason] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  // توليد تلقائي من الاسم طالما المستخدم لم يلمس حقل الـ slug يدويًا بعد
  useEffect(() => {
    if (!touched) {
      onChange(slugify(sourceName));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sourceName, touched]);

  // تحقق فوري (debounced) من التوفر عند كل تغيير في الـ slug
  useEffect(() => {
    if (!value) {
      setStatus("idle");
      return;
    }
    const timeout = setTimeout(() => {
      setStatus("checking");
      startTransition(async () => {
        const result = await checkSlugAvailabilityAction(value, excludeRestaurantId);
        if (!result.ok) {
          setStatus("idle");
          return;
        }
        setStatus(result.data.available ? "available" : "unavailable");
        setReason(result.data.reason ?? "هذا الرابط مستخدم بالفعل.");
      });
    }, 400);
    return () => clearTimeout(timeout);
  }, [value, excludeRestaurantId]);

  return (
    <div className="space-y-1">
      <label className="block text-sm font-medium">رابط المطعم (Slug)</label>
      <div className="flex items-center gap-2" dir="ltr">
        <span className="text-sm text-slate-500">domain.com/</span>
        <input
          type="text"
          value={value}
          onChange={(e) => {
            setTouched(true);
            onChange(e.target.value.toLowerCase());
          }}
          className="flex-1 rounded border border-slate-300 px-2 py-1 text-sm"
          dir="ltr"
        />
      </div>

      {status === "checking" || isPending ? (
        <p className="text-xs text-slate-500">جاري التحقق من التوفر...</p>
      ) : status === "available" ? (
        <p className="text-xs text-green-600">الرابط متاح.</p>
      ) : status === "unavailable" ? (
        <p className="text-xs text-red-600">{reason}</p>
      ) : null}
    </div>
  );
}
