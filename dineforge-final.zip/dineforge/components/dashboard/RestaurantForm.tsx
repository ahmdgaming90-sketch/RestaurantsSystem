"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  createRestaurantAction,
  updateRestaurantAction,
  updateRestaurantImagesAction,
} from "@/lib/actions/restaurants";
import { SlugField } from "@/components/dashboard/SlugField";
import { ImageUploader } from "@/components/dashboard/ImageUploader";

type Theme = { id: string; key: string; name: string; description: string | null };

type ExistingRestaurant = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  whatsapp_number: string;
  location: string | null;
  theme_id: string | null;
  color_palette: { primary?: string; secondary?: string; accent?: string } | null;
  logo_url: string | null;
  cover_url: string | null;
};

type RestaurantFormProps = {
  themes: Theme[];
  restaurant?: ExistingRestaurant; // موجود فقط في وضع التعديل
};

const WEEKDAYS: { key: string; label: string }[] = [
  { key: "sun", label: "الأحد" },
  { key: "mon", label: "الإثنين" },
  { key: "tue", label: "الثلاثاء" },
  { key: "wed", label: "الأربعاء" },
  { key: "thu", label: "الخميس" },
  { key: "fri", label: "الجمعة" },
  { key: "sat", label: "السبت" },
];

export function RestaurantForm({ themes, restaurant }: RestaurantFormProps) {
  const router = useRouter();
  const isEditMode = Boolean(restaurant);

  const [name, setName] = useState(restaurant?.name ?? "");
  const [slug, setSlug] = useState(restaurant?.slug ?? "");
  const [description, setDescription] = useState(restaurant?.description ?? "");
  const [whatsapp, setWhatsapp] = useState(restaurant?.whatsapp_number ?? "");
  const [location, setLocation] = useState(restaurant?.location ?? "");
  const [themeId, setThemeId] = useState(restaurant?.theme_id ?? themes[0]?.id ?? "");
  const [primaryColor, setPrimaryColor] = useState(restaurant?.color_palette?.primary ?? "#111827");
  const [secondaryColor, setSecondaryColor] = useState(restaurant?.color_palette?.secondary ?? "#6b7280");
  const [accentColor, setAccentColor] = useState(restaurant?.color_palette?.accent ?? "#f59e0b");
  const [workingHours, setWorkingHours] = useState<Record<string, string>>({});

  const [logoUrl, setLogoUrl] = useState(restaurant?.logo_url ?? null);
  const [coverUrl, setCoverUrl] = useState(restaurant?.cover_url ?? null);

  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    startTransition(async () => {
      const payload = {
        name,
        slug,
        description,
        whatsapp_number: whatsapp,
        location,
        working_hours: workingHours,
        theme_id: themeId,
        color_palette: { primary: primaryColor, secondary: secondaryColor, accent: accentColor },
      };

      if (isEditMode && restaurant) {
        const result = await updateRestaurantAction({ id: restaurant.id, ...payload });
        if (!result.ok) {
          setError(result.error);
          return;
        }
        router.refresh();
      } else {
        const result = await createRestaurantAction(payload);
        if (!result.ok) {
          setError(result.error);
          return;
        }
        // بعد الإنشاء: التوجيه لصفحة التعديل حيث يمكن رفع الشعار وصورة الغلاف
        // (تحتاج restaurant_id، لذلك ترفع بعد إنشاء الصف مباشرة وليس قبله).
        router.push(`/owner/restaurants/${result.data.id}`);
      }
    });
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-2xl">
      {error && (
        <div className="rounded border border-red-300 bg-red-50 px-3 py-2 text-sm text-red-700">
          {error}
        </div>
      )}

      <div className="space-y-1">
        <label className="block text-sm font-medium">اسم المطعم</label>
        <input
          required
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
        />
      </div>

      <SlugField
        value={slug}
        onChange={setSlug}
        sourceName={name}
        excludeRestaurantId={restaurant?.id}
      />

      <div className="space-y-1">
        <label className="block text-sm font-medium">الوصف</label>
        <textarea
          value={description ?? ""}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
          className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-1">
          <label className="block text-sm font-medium">رقم واتساب الطلبات</label>
          <input
            required
            type="text"
            dir="ltr"
            placeholder="9665xxxxxxxx"
            value={whatsapp}
            onChange={(e) => setWhatsapp(e.target.value)}
            className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
          />
        </div>
        <div className="space-y-1">
          <label className="block text-sm font-medium">الموقع</label>
          <input
            type="text"
            value={location ?? ""}
            onChange={(e) => setLocation(e.target.value)}
            className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
          />
        </div>
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-medium">أوقات العمل</label>
        <div className="grid grid-cols-2 gap-2">
          {WEEKDAYS.map((day) => (
            <div key={day.key} className="flex items-center gap-2 text-sm">
              <span className="w-16 text-slate-500">{day.label}</span>
              <input
                type="text"
                placeholder="10:00-23:00"
                dir="ltr"
                onChange={(e) =>
                  setWorkingHours((prev) => ({ ...prev, [day.key]: e.target.value }))
                }
                className="flex-1 rounded border border-slate-300 px-2 py-1 text-sm"
              />
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-1">
        <label className="block text-sm font-medium">القالب (Theme)</label>
        <select
          value={themeId}
          onChange={(e) => setThemeId(e.target.value)}
          className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
        >
          {themes.map((theme) => (
            <option key={theme.id} value={theme.id}>
              {theme.name}
            </option>
          ))}
        </select>
        <p className="text-xs text-slate-500">
          {themes.find((t) => t.id === themeId)?.description}
        </p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="space-y-1">
          <label className="block text-sm font-medium">اللون الأساسي</label>
          <input
            type="color"
            value={primaryColor}
            onChange={(e) => setPrimaryColor(e.target.value)}
            className="h-9 w-full rounded border border-slate-300"
          />
        </div>
        <div className="space-y-1">
          <label className="block text-sm font-medium">اللون الثانوي</label>
          <input
            type="color"
            value={secondaryColor}
            onChange={(e) => setSecondaryColor(e.target.value)}
            className="h-9 w-full rounded border border-slate-300"
          />
        </div>
        <div className="space-y-1">
          <label className="block text-sm font-medium">لون التمييز</label>
          <input
            type="color"
            value={accentColor}
            onChange={(e) => setAccentColor(e.target.value)}
            className="h-9 w-full rounded border border-slate-300"
          />
        </div>
      </div>

      {isEditMode && restaurant && (
        <div className="grid grid-cols-2 gap-6 border-t border-slate-200 pt-4">
          <ImageUploader
            label="الشعار"
            restaurantId={restaurant.id}
            kind="logo"
            currentUrl={logoUrl}
            onUploaded={(url) => {
              setLogoUrl(url);
              startTransition(async () => {
                await updateRestaurantImagesAction(restaurant.id, { logo_url: url });
              });
            }}
          />
          <ImageUploader
            label="صورة الغلاف"
            restaurantId={restaurant.id}
            kind="cover"
            currentUrl={coverUrl}
            onUploaded={(url) => {
              setCoverUrl(url);
              startTransition(async () => {
                await updateRestaurantImagesAction(restaurant.id, { cover_url: url });
              });
            }}
          />
        </div>
      )}

      {!isEditMode && (
        <p className="text-xs text-slate-500">
          يمكن رفع الشعار وصورة الغلاف بعد إنشاء المطعم مباشرة، من نفس صفحة التعديل التي ستفتح تلقائيًا.
        </p>
      )}

      <button
        type="submit"
        disabled={isPending}
        className="rounded bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800 disabled:opacity-50"
      >
        {isPending ? "جاري الحفظ..." : isEditMode ? "حفظ التعديلات" : "إنشاء المطعم"}
      </button>
    </form>
  );
}
