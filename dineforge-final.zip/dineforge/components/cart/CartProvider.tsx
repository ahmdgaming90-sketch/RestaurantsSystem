"use client";

import { createContext, useContext, useEffect, useMemo, useState } from "react";

export type CartItem = {
  productId: string;
  name: string;
  price: number;
  quantity: number;
};

type CartContextValue = {
  items: CartItem[];
  addItem: (item: Omit<CartItem, "quantity">, quantity?: number) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  removeItem: (productId: string) => void;
  clear: () => void;
  total: number;
  itemCount: number;
};

const CartContext = createContext<CartContextValue | null>(null);

function storageKey(restaurantId: string) {
  // مفتاح معزول لكل مطعم، حتى لو فتح الزائر أكثر من موقع مطعم في تابات مختلفة
  return `df-cart-${restaurantId}`;
}

export function CartProvider({
  restaurantId,
  children,
}: {
  restaurantId: string;
  children: React.ReactNode;
}) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [hydrated, setHydrated] = useState(false);

  // تحميل السلة المحفوظة من localStorage عند أول تحميل للصفحة
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(storageKey(restaurantId));
      if (raw) setItems(JSON.parse(raw));
    } catch {
      // تجاهل: بيانات محلية تالفة لا يجب أن توقف الموقع
    } finally {
      setHydrated(true);
    }
  }, [restaurantId]);

  // حفظ أي تغيير في السلة فور حدوثه
  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem(storageKey(restaurantId), JSON.stringify(items));
  }, [items, restaurantId, hydrated]);

  function addItem(item: Omit<CartItem, "quantity">, quantity = 1) {
    setItems((prev) => {
      const existing = prev.find((line) => line.productId === item.productId);
      if (existing) {
        return prev.map((line) =>
          line.productId === item.productId ? { ...line, quantity: line.quantity + quantity } : line
        );
      }
      return [...prev, { ...item, quantity }];
    });
  }

  function updateQuantity(productId: string, quantity: number) {
    if (quantity <= 0) {
      removeItem(productId);
      return;
    }
    setItems((prev) => prev.map((line) => (line.productId === productId ? { ...line, quantity } : line)));
  }

  function removeItem(productId: string) {
    setItems((prev) => prev.filter((line) => line.productId !== productId));
  }

  function clear() {
    setItems([]);
  }

  const total = useMemo(() => items.reduce((sum, line) => sum + line.price * line.quantity, 0), [items]);
  const itemCount = useMemo(() => items.reduce((sum, line) => sum + line.quantity, 0), [items]);

  return (
    <CartContext.Provider value={{ items, addItem, updateQuantity, removeItem, clear, total, itemCount }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart يجب أن يُستخدم داخل CartProvider");
  return ctx;
}
