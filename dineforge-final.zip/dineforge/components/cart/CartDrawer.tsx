"use client";

import { useCart } from "@/components/cart/CartProvider";

export function CartDrawer({
  onCheckout,
  onClose,
}: {
  onCheckout: () => void;
  onClose: () => void;
}) {
  const { items, updateQuantity, removeItem, total } = useCart();

  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-black/40">
      <div className="h-full w-full max-w-sm bg-surface p-6 flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-medium text-heading">سلتك</h2>
          <button onClick={onClose} className="text-muted text-sm" aria-label="إغلاق">
            إغلاق
          </button>
        </div>

        {items.length === 0 ? (
          <p className="text-sm text-muted flex-1">السلة فارغة حاليًا.</p>
        ) : (
          <>
            <ul className="flex-1 overflow-y-auto divide-y divide-border">
              {items.map((line) => (
                <li key={line.productId} className="py-3 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate text-heading">{line.name}</p>
                    <p className="text-xs text-muted">{line.price.toFixed(2)}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0" dir="ltr">
                    <button
                      onClick={() => updateQuantity(line.productId, line.quantity - 1)}
                      className="h-6 w-6 rounded-full border border-border text-sm flex items-center justify-center"
                      aria-label="إنقاص الكمية"
                    >
                      −
                    </button>
                    <span className="w-4 text-center text-sm">{line.quantity}</span>
                    <button
                      onClick={() => updateQuantity(line.productId, line.quantity + 1)}
                      className="h-6 w-6 rounded-full border border-border text-sm flex items-center justify-center"
                      aria-label="زيادة الكمية"
                    >
                      +
                    </button>
                    <button
                      onClick={() => removeItem(line.productId)}
                      className="text-xs text-red-600 ms-2"
                    >
                      حذف
                    </button>
                  </div>
                </li>
              ))}
            </ul>

            <div className="border-t border-border pt-4 space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted">الإجمالي</span>
                <span className="font-medium text-heading">{total.toFixed(2)}</span>
              </div>
              <button
                onClick={onCheckout}
                className="w-full rounded bg-button text-button-ink py-3 text-sm font-medium"
              >
                متابعة الطلب
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
