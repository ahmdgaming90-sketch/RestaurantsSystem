"use client";

import { useCart } from "@/components/cart/CartProvider";

export function AddToCartButton({
  productId,
  name,
  price,
}: {
  productId: string;
  name: string;
  price: number;
}) {
  const { items, addItem, updateQuantity } = useCart();
  const line = items.find((item) => item.productId === productId);

  if (!line) {
    return (
      <button
        onClick={() => addItem({ productId, name, price })}
        className="text-xs font-medium tracking-wide text-primary border border-border rounded-full px-3 py-1 hover:bg-button hover:text-button-ink hover:border-button transition-colors"
      >
        إضافة
      </button>
    );
  }

  return (
    <div className="flex items-center gap-2" dir="ltr">
      <button
        onClick={() => updateQuantity(productId, line.quantity - 1)}
        className="h-6 w-6 rounded-full border border-border text-sm leading-none flex items-center justify-center hover:bg-surface"
        aria-label="إنقاص الكمية"
      >
        −
      </button>
      <span className="w-4 text-center text-sm">{line.quantity}</span>
      <button
        onClick={() => updateQuantity(productId, line.quantity + 1)}
        className="h-6 w-6 rounded-full border border-border text-sm leading-none flex items-center justify-center hover:bg-surface"
        aria-label="زيادة الكمية"
      >
        +
      </button>
    </div>
  );
}
