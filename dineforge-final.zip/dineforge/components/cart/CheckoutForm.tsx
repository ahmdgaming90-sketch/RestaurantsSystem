"use client";

import { useState, useTransition } from "react";
import { useCart } from "@/components/cart/CartProvider";
import { buildWhatsAppLink, buildWhatsAppMessage } from "@/lib/whatsapp/buildMessage";
import { createOrderAction } from "@/lib/actions/orders";

export function CheckoutForm({
  restaurantId,
  restaurantName,
  whatsappNumber,
  pickupNote,
  thankYouMessage,
  requirePhone,
  onClose,
}: {
  restaurantId: string;
  restaurantName: string;
  whatsappNumber: string;
  pickupNote: string;
  thankYouMessage?: string | null;
  requirePhone: boolean;
  onClose: () => void;
}) {
  const { items, total, clear } = useCart();
  const [customerName, setCustomerName] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!customerName.trim()) {
      setError("الرجاء إدخال الاسم.");
      return;
    }
    if (requirePhone && !phone.trim()) {
      setError("الرجاء إدخال رقم الجوال.");
      return;
    }
    if (items.length === 0) {
      setError("السلة فارغة.");
      return;
    }

    const message = buildWhatsAppMessage({
      restaurantName,
      pickupNote,
      thankYouMessage,
      customer: { name: customerName, phone, notes },
      lines: items,
      total,
    });
    const link = buildWhatsAppLink(whatsappNumber, message);

    // نفتح رابط واتساب فورًا (لا يجوز أن يتأخر أو يفشل بسبب مشكلة في حفظ السجل الداخلي)،
    // وبالتوازي نحفظ الطلب في قاعدة البيانات لأغراض المراقبة والإحصائيات في لوحة Owner/Manager.
    window.open(link, "_blank");

    startTransition(async () => {
      // لا نرسل total من العميل — الخادم يعيد حسابه من أسعار قاعدة البيانات الحقيقية (lib/actions/orders.ts)
      await createOrderAction({
        restaurantId,
        customerName,
        customerPhone: phone,
        notes,
        items,
      });
    });

    clear();
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-md rounded-t-2xl sm:rounded-2xl bg-surface p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-medium text-heading">تأكيد الطلب</h2>
          <button onClick={onClose} className="text-muted text-sm" aria-label="إغلاق">
            إغلاق
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <p className="rounded border border-red-300 bg-red-50 px-3 py-2 text-sm text-red-700">
              {error}
            </p>
          )}

          <div className="space-y-1">
            <label className="block text-sm font-medium text-heading">الاسم</label>
            <input
              required
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="w-full rounded border border-border px-3 py-2 text-sm"
            />
          </div>

          <div className="space-y-1">
            <label className="block text-sm font-medium text-heading">
              رقم الجوال {requirePhone ? "" : "(اختياري)"}
            </label>
            <input
              type="tel"
              dir="ltr"
              required={requirePhone}
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full rounded border border-border px-3 py-2 text-sm"
            />
          </div>

          <div className="space-y-1">
            <label className="block text-sm font-medium text-heading">ملاحظات</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              className="w-full rounded border border-border px-3 py-2 text-sm"
            />
          </div>

          <div className="flex items-center justify-between border-t border-border pt-3 text-sm">
            <span className="text-muted">الإجمالي</span>
            <span className="font-medium text-heading">{total.toFixed(2)}</span>
          </div>

          <button
            type="submit"
            disabled={isPending}
            className="w-full rounded bg-button text-button-ink py-3 text-sm font-medium disabled:opacity-60"
          >
            إرسال الطلب عبر واتساب
          </button>
        </form>
      </div>
    </div>
  );
}
