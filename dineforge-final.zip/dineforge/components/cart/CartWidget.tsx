"use client";

import { useState } from "react";
import { useCart } from "@/components/cart/CartProvider";
import { CartDrawer } from "@/components/cart/CartDrawer";
import { CheckoutForm } from "@/components/cart/CheckoutForm";

export function CartWidget({
  restaurantId,
  restaurantName,
  whatsappNumber,
  pickupNote,
  thankYouMessage,
  requirePhone,
  buttonLabel,
  position,
}: {
  restaurantId: string;
  restaurantName: string;
  whatsappNumber: string;
  pickupNote: string;
  thankYouMessage?: string | null;
  requirePhone: boolean;
  buttonLabel: string;
  position: "fixed-bottom" | string;
}) {
  const { itemCount } = useCart();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  if (itemCount === 0 && !drawerOpen && !checkoutOpen) {
    return null;
  }

  const positionClass =
    position === "fixed-bottom"
      ? "fixed bottom-4 inset-x-4 sm:inset-x-auto sm:left-4"
      : "fixed bottom-4 left-4";

  return (
    <>
      {!drawerOpen && !checkoutOpen && (
        <button
          onClick={() => setDrawerOpen(true)}
          className={`${positionClass} z-30 rounded-full bg-button text-button-ink shadow-lg px-5 py-3 text-sm font-medium flex items-center justify-center gap-2`}
        >
          <span>{buttonLabel}</span>
          <span className="inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-white/20 px-1 text-xs">
            {itemCount}
          </span>
        </button>
      )}

      {drawerOpen && !checkoutOpen && (
        <CartDrawer onClose={() => setDrawerOpen(false)} onCheckout={() => setCheckoutOpen(true)} />
      )}

      {checkoutOpen && (
        <CheckoutForm
          restaurantId={restaurantId}
          restaurantName={restaurantName}
          whatsappNumber={whatsappNumber}
          pickupNote={pickupNote}
          thankYouMessage={thankYouMessage}
          requirePhone={requirePhone}
          onClose={() => {
            setCheckoutOpen(false);
            setDrawerOpen(false);
          }}
        />
      )}
    </>
  );
}
