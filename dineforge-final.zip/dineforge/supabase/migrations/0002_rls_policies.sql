-- ============================================================
-- DineForge — Migration 0002: Row Level Security + Helper Functions
-- ============================================================

-- ============ دوال مساعدة (تُستخدم داخل الـ Policies) ============

-- هل المستخدم الحالي Owner؟
create or replace function is_owner()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from profiles
    where id = auth.uid() and role = 'owner'
  );
$$;

-- هل المستخدم الحالي مدير على مطعم معيّن؟
create or replace function is_manager_of(target_restaurant_id uuid)
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from restaurant_managers
    where restaurant_id = target_restaurant_id
      and profile_id = auth.uid()
  );
$$;

-- ============ تفعيل RLS على كل الجداول ============

alter table profiles enable row level security;
alter table restaurants enable row level security;
alter table restaurant_managers enable row level security;
alter table restaurant_order_settings enable row level security;
alter table restaurant_settings enable row level security;
alter table themes enable row level security;
alter table restaurant_sections enable row level security;
alter table design_versions enable row level security;
alter table restaurant_pwa_settings enable row level security;
alter table categories enable row level security;
alter table products enable row level security;
alter table orders enable row level security;

-- ============ profiles ============

create policy "profiles_select_own_or_owner"
  on profiles for select
  using (id = auth.uid() or is_owner());

create policy "profiles_update_own"
  on profiles for update
  using (id = auth.uid());

-- ============ restaurants ============

create policy "restaurants_select_public_active"
  on restaurants for select
  using (is_active = true);

create policy "restaurants_select_owner_all"
  on restaurants for select
  using (is_owner());

create policy "restaurants_select_manager_own"
  on restaurants for select
  using (is_manager_of(id));

create policy "restaurants_insert_owner_only"
  on restaurants for insert
  with check (is_owner());

create policy "restaurants_update_owner"
  on restaurants for update
  using (is_owner());

create policy "restaurants_update_manager_own"
  on restaurants for update
  using (is_manager_of(id));

create policy "restaurants_delete_owner_only"
  on restaurants for delete
  using (is_owner());

-- ============ restaurant_managers (Owner فقط يدير هذا الربط) ============

create policy "restaurant_managers_select_owner_or_self"
  on restaurant_managers for select
  using (is_owner() or profile_id = auth.uid());

create policy "restaurant_managers_write_owner_only"
  on restaurant_managers for all
  using (is_owner())
  with check (is_owner());

-- ============ restaurant_order_settings ============

create policy "order_settings_select_public"
  on restaurant_order_settings for select
  using (
    exists (select 1 from restaurants r where r.id = restaurant_id and r.is_active = true)
    or is_owner()
    or is_manager_of(restaurant_id)
  );

create policy "order_settings_write_owner_or_manager"
  on restaurant_order_settings for all
  using (is_owner() or is_manager_of(restaurant_id))
  with check (is_owner() or is_manager_of(restaurant_id));

-- ============ restaurant_settings ============

create policy "restaurant_settings_select_public"
  on restaurant_settings for select
  using (
    exists (select 1 from restaurants r where r.id = restaurant_id and r.is_active = true)
    or is_owner()
    or is_manager_of(restaurant_id)
  );

-- إعدادات SEO/الفوتر/زر الطلب: تعديلها محصور بالـ Owner فقط في هذه المرحلة
-- (قرار مرحلي — يمكن فتحه لاحقًا لـ Manager إن رغب المالك بذلك)
create policy "restaurant_settings_write_owner_only"
  on restaurant_settings for all
  using (is_owner())
  with check (is_owner());

-- ============ themes (مرجع للقراءة فقط للجميع، الكتابة Owner) ============

create policy "themes_select_all"
  on themes for select
  using (true);

create policy "themes_write_owner_only"
  on themes for all
  using (is_owner())
  with check (is_owner());

-- ============ restaurant_sections ============

create policy "sections_select_public"
  on restaurant_sections for select
  using (
    exists (select 1 from restaurants r where r.id = restaurant_id and r.is_active = true)
    or is_owner()
    or is_manager_of(restaurant_id)
  );

create policy "sections_write_owner_or_manager"
  on restaurant_sections for all
  using (is_owner() or is_manager_of(restaurant_id))
  with check (is_owner() or is_manager_of(restaurant_id));

-- ============ design_versions (سجل داخلي — لا وصول للعامة إطلاقًا) ============

create policy "design_versions_select_owner_or_manager"
  on design_versions for select
  using (is_owner() or is_manager_of(restaurant_id));

-- الحفظ اليدوي/التلقائي محصور بالـ Owner في هذه المرحلة (نفس منطق restaurant_settings)
create policy "design_versions_write_owner_only"
  on design_versions for insert
  with check (is_owner());

create policy "design_versions_delete_owner_only"
  on design_versions for delete
  using (is_owner());

-- ============ restaurant_pwa_settings ============

create policy "pwa_settings_select_public"
  on restaurant_pwa_settings for select
  using (
    exists (select 1 from restaurants r where r.id = restaurant_id and r.is_active = true)
    or is_owner()
    or is_manager_of(restaurant_id)
  );

create policy "pwa_settings_write_owner_only"
  on restaurant_pwa_settings for all
  using (is_owner())
  with check (is_owner());

-- ============ categories ============

create policy "categories_select_public"
  on categories for select
  using (
    exists (select 1 from restaurants r where r.id = restaurant_id and r.is_active = true)
    or is_owner()
    or is_manager_of(restaurant_id)
  );

create policy "categories_write_owner_or_manager"
  on categories for all
  using (is_owner() or is_manager_of(restaurant_id))
  with check (is_owner() or is_manager_of(restaurant_id));

-- ============ products ============

create policy "products_select_public_available"
  on products for select
  using (
    exists (select 1 from restaurants r where r.id = restaurant_id and r.is_active = true)
    or is_owner()
    or is_manager_of(restaurant_id)
  );

create policy "products_write_owner_or_manager"
  on products for all
  using (is_owner() or is_manager_of(restaurant_id))
  with check (is_owner() or is_manager_of(restaurant_id));

-- ============ orders ============
-- ملاحظة أمنية مهمة: لا نمنح insert مباشر للعامة (anon) هنا.
-- إنشاء الطلب يمر عبر Server Action بصلاحية service role (bypass RLS بشكل متحكَّم به من الخادم فقط)
-- بدل فتح insert للجميع، لمنع أي إساءة استخدام (spam / تلاعب بالأسعار من المتصفح).

create policy "orders_select_owner_or_manager"
  on orders for select
  using (is_owner() or is_manager_of(restaurant_id));

create policy "orders_update_owner_or_manager"
  on orders for update
  using (is_owner() or is_manager_of(restaurant_id));

-- عمداً: لا توجد policy لـ insert على anon/authenticated — الإدراج فقط عبر service role من Server Action.
