-- ============================================================
-- DineForge — Migration 0008: Audit Log + Error Logs
-- ============================================================
-- يدعم متطلبات: سجل العمليات المهمة (Activity/Audit Log)، وصفحة System Health/Errors.

create table audit_log (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references profiles(id),
  actor_role text,
  action text not null,                 -- مثال: 'restaurant.create', 'restaurant.update'
  target_type text,                     -- مثال: 'restaurant'
  target_id uuid,
  metadata jsonb,
  created_at timestamptz not null default now()
);

create index idx_audit_log_created on audit_log(created_at desc);
create index idx_audit_log_target on audit_log(target_type, target_id);

alter table audit_log enable row level security;

-- القراءة محصورة بالـ Owner (سجل على مستوى النظام كامل)
create policy "audit_log_select_owner_only"
  on audit_log for select
  using (is_owner());

-- الإدراج مسموح فقط عندما actor_id = المستخدم نفسه (Owner أو Manager يسجّل عملياته الخاصة)
create policy "audit_log_insert_self"
  on audit_log for insert
  with check (actor_id = auth.uid());

-- ============ error_logs ============
-- تُسجَّل من الخادم فقط (Server Actions) عبر service role، لأن بعض الأخطاء تحدث في مسارات
-- عامة غير مسجّل دخولها (مثال: فشل حفظ طلب عميل زائر) ولا يوجد actor مصادَق عليه حينها.

create table error_logs (
  id uuid primary key default gen_random_uuid(),
  scope text not null,                  -- مثال: 'server_action:createOrderAction'
  message text not null,
  stack text,
  context jsonb,
  created_at timestamptz not null default now()
);

create index idx_error_logs_created on error_logs(created_at desc);

alter table error_logs enable row level security;

-- القراءة محصورة بالـ Owner فقط
create policy "error_logs_select_owner_only"
  on error_logs for select
  using (is_owner());

-- لا policy إدراج للمستخدمين العاديين عمدًا — الإدراج فقط عبر service role من الخادم
-- (نفس نمط جدول orders: الكتابة محكومة بالكامل من كود الخادم، وليس من صلاحيات RLS عامة).
