-- ============================================================
-- DineForge — Migration 0005: Storage bucket + policies لصور المطاعم
-- ============================================================
--
-- اتفاقية المسارات داخل الـ bucket (يجب الالتزام بها من كود التطبيق):
--   restaurants/{restaurant_id}/logo-{timestamp}.{ext}
--   restaurants/{restaurant_id}/cover-{timestamp}.{ext}
--   restaurants/{restaurant_id}/pwa-icon-{timestamp}.{ext}   (يُستخدم في مرحلة PWA القادمة)
--   restaurants/{restaurant_id}/products/{product_id}-{timestamp}.{ext} (مرحلة لوحة Manager القادمة)
--
-- bucket عام (public=true) لأن هذه صور معروضة على مواقع المطاعم العامة أصلاً؛
-- الحماية المطلوبة هنا هي على الكتابة (insert/update/delete) وليس القراءة.

insert into storage.buckets (id, name, public)
values ('restaurant-assets', 'restaurant-assets', true)
on conflict (id) do nothing;

-- القراءة عامة بالكامل (نفس منطق أن صور المطعم النشط تظهر لأي زائر)
create policy "restaurant_assets_public_read"
  on storage.objects for select
  using (bucket_id = 'restaurant-assets');

-- الكتابة (رفع) محصورة بـ Owner أو Manager المطعم الذي يطابق الجزء الثاني من المسار
-- storage.foldername('restaurants/<restaurant_id>/logo-1.png') = {'restaurants', '<restaurant_id>'}
create policy "restaurant_assets_insert_owner_or_manager"
  on storage.objects for insert
  with check (
    bucket_id = 'restaurant-assets'
    and (storage.foldername(name))[1] = 'restaurants'
    and (
      is_owner()
      or is_manager_of(((storage.foldername(name))[2])::uuid)
    )
  );

create policy "restaurant_assets_update_owner_or_manager"
  on storage.objects for update
  using (
    bucket_id = 'restaurant-assets'
    and (storage.foldername(name))[1] = 'restaurants'
    and (
      is_owner()
      or is_manager_of(((storage.foldername(name))[2])::uuid)
    )
  );

create policy "restaurant_assets_delete_owner_or_manager"
  on storage.objects for delete
  using (
    bucket_id = 'restaurant-assets'
    and (storage.foldername(name))[1] = 'restaurants'
    and (
      is_owner()
      or is_manager_of(((storage.foldername(name))[2])::uuid)
    )
  );
