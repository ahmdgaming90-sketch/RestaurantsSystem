-- ============================================================
-- DineForge — Migration 0003: ربط auth.users بجدول profiles تلقائيًا
-- ============================================================

-- عند تسجيل مستخدم جديد في Supabase Auth، يُنشأ له صف تلقائيًا في profiles
-- بدور افتراضي 'manager' (الأكثر أمانًا كافتراضي — لا أحد يصبح Owner تلقائيًا).
-- ترقية أول مستخدم إلى Owner تتم يدويًا (انظر التعليمات أسفل الملف).

create or replace function handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', null),
    'manager'
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_auth_user();

-- ============================================================
-- تعليمات: ترقية أول مستخدم إلى Owner
-- ============================================================
-- بعد تسجيل أول حساب عبر التطبيق (أو من Supabase Dashboard > Authentication)،
-- نفّذ هذا الاستعلام يدويًا من SQL Editor في Supabase (مرة واحدة فقط):
--
--   update public.profiles set role = 'owner' where id = '<USER_UUID_HERE>';
--
-- يمكن الحصول على USER_UUID من Authentication > Users في لوحة Supabase.
