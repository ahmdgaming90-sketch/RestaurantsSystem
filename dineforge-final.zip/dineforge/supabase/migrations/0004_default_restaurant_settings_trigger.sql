-- ============================================================
-- DineForge — Migration 0004: إنشاء الإعدادات الافتراضية تلقائيًا لكل مطعم جديد
-- ============================================================
--
-- القرار المعماري: بدل الاعتماد على أن يُنشئ كود التطبيق أربع صفوف يدويًا
-- (restaurant_settings, restaurant_order_settings, restaurant_pwa_settings, restaurant_sections)
-- في نفس معاملة الإنشاء، نضمن ذلك عبر AFTER INSERT trigger على جدول restaurants.
-- بهذا تُضمن الإعدادات الافتراضية دائمًا — بغض النظر عن المسار الذي أُنشئ به المطعم
-- (لوحة Owner، سكربت استيراد مستقبلي، Supabase Dashboard مباشرة...)، وضمن نفس المعاملة الذرية.

create or replace function handle_new_restaurant_defaults()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  default_sections text[] := array['hero', 'about', 'menu', 'gallery', 'contact'];
  section_key text;
  idx int := 0;
begin
  -- restaurant_settings (تعتمد على الـ defaults المعرّفة على الأعمدة في migration 0001)
  insert into restaurant_settings (restaurant_id)
  values (new.id);

  -- restaurant_order_settings
  insert into restaurant_order_settings (restaurant_id)
  values (new.id);

  -- restaurant_pwa_settings: نُهيّئها من بيانات المطعم نفسه (اسم التطبيق، لون الثيم) كقيم أولية معقولة،
  -- قابلة للتعديل لاحقًا من صفحة إعدادات PWA (مرحلة قادمة)
  insert into restaurant_pwa_settings (restaurant_id, app_name, short_name, theme_color, background_color)
  values (
    new.id,
    new.name,
    left(new.name, 12),
    coalesce(new.color_palette->>'primary', '#111827'),
    '#ffffff'
  );

  -- restaurant_sections: مجموعة أقسام افتراضية مرئية بترتيب منطقي وحركة fade
  foreach section_key in array default_sections loop
    insert into restaurant_sections (restaurant_id, section_key, is_visible, sort_order, animation)
    values (new.id, section_key, true, idx, 'fade');
    idx := idx + 1;
  end loop;

  return new;
end;
$$;

create trigger trg_new_restaurant_defaults
  after insert on restaurants
  for each row execute function handle_new_restaurant_defaults();
