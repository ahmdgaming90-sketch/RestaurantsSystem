-- ============================================================
-- DineForge — Migration 0007: كتالوج الثيمات النهائي (15 ثيمًا مبنيًا فعليًا)
-- ============================================================
-- يستبدل هذا التوسعة المرحلية في migration 0006 (كانت تحتوي أسماء/مفاتيح مؤقتة
-- وثيمات placeholder). الآن كل الـ15 مفتاحًا مبنية فعليًا بمكونات مستقلة في themes/<key>/
-- ومسجّلة في themes/registry.ts — لذلك كلها is_active = true.

-- أي مطعم كان يشير لثيم سيُحذف لعدم مطابقته القائمة الجديدة يُعاد توجيهه إلى 'minimal' أولاً
-- (إجراء وقائي؛ لا يُفترض وجود بيانات كهذه في بيئة تطوير حديثة، لكن نتجنب أي فشل بسبب FK).
update restaurants
set theme_id = (select id from themes where key = 'minimal')
where theme_id in (
  select id from themes
  where key not in (
    'minimal', 'midnight-luxury', 'mediterranean', 'urban-grill', 'specialty-coffee',
    'modern-japanese', 'arabic-heritage', 'fresh-green', 'bakery-atelier', 'coastal',
    'contemporary-black', 'retro-diner', 'street-food', 'garden-bistro', 'editorial-fine-dining'
  )
);

delete from themes
where key not in (
  'minimal', 'midnight-luxury', 'mediterranean', 'urban-grill', 'specialty-coffee',
  'modern-japanese', 'arabic-heritage', 'fresh-green', 'bakery-atelier', 'coastal',
  'contemporary-black', 'retro-diner', 'street-food', 'garden-bistro', 'editorial-fine-dining'
);

-- upsert كامل للـ15: الاسم، الوصف، الألوان الافتراضية (تطابق defaultPalette في كل theme.config.ts
-- حرفيًا — هذه القيم هي ما يراه Owner كنقطة بداية، وتظل قابلة للتعديل لاحقًا من المحرر فوقها)،
-- وكلها is_active = true لأنها مبنية فعليًا وليست placeholders.
insert into themes (key, name, description, default_palette, is_active) values
('minimal', 'Minimal White', 'مطعم عصري نظيف، أبيض، راقٍ، بسيط — قائمة Editorial بخط نقطي',
 '{"primary":"#1C1C1C","secondary":"#6F6B63","accent":"#B18A52","background":"#F8F7F3","surface":"#FFFFFF","text":"#171717","border":"#E7E3DB","button":"#1C1C1C","buttonText":"#FFFFFF","heading":"#171717","muted":"#6F6B63"}', true),

('midnight-luxury', 'Midnight Luxury', 'مطعم فاخر جدًا / Steakhouse / Fine Dining — Dark luxury سينمائي',
 '{"primary":"#F2EEE6","secondary":"#AAA399","accent":"#B8945B","background":"#101010","surface":"#181818","text":"#F2EEE6","border":"#302E2A","button":"#B8945B","buttonText":"#101010","heading":"#F2EEE6","muted":"#AAA399"}', true),

('mediterranean', 'Mediterranean', 'مطعم متوسطي راقٍ، مشمس وطبيعي — بطاقات مستديرة دافئة',
 '{"primary":"#355C4A","secondary":"#756A57","accent":"#C8794B","background":"#F5F0E5","surface":"#FFFDF7","text":"#2B2A25","border":"#DED4C2","button":"#355C4A","buttonText":"#FFFDF7","heading":"#2B2A25","muted":"#756A57"}', true),

('urban-grill', 'Urban Grill', 'برجر، ستيك، مشاوي، مطعم حضري قوي — طباعة جريئة وسعر ضخم',
 '{"primary":"#171717","secondary":"#57534E","accent":"#B64B32","background":"#F1EEE8","surface":"#FFFFFF","text":"#171717","border":"#24211F","button":"#B64B32","buttonText":"#FFFFFF","heading":"#171717","muted":"#57534E"}', true),

('specialty-coffee', 'Specialty Coffee', 'مقهى Specialty Coffee راقٍ — طابع Coffee Journal',
 '{"primary":"#34251D","secondary":"#78685B","accent":"#9A6947","background":"#EFE9DF","surface":"#FAF7F1","text":"#34251D","border":"#D8CDBF","button":"#34251D","buttonText":"#FAF7F1","heading":"#34251D","muted":"#78685B"}', true),

('modern-japanese', 'Modern Japanese', 'مطعم ياباني معاصر — Minimal، مساحات فارغة، شبكة غير تقليدية',
 '{"primary":"#171717","secondary":"#68645D","accent":"#A33D32","background":"#F4F2ED","surface":"#FFFFFF","text":"#171717","border":"#DEDCD6","button":"#171717","buttonText":"#FFFFFF","heading":"#171717","muted":"#68645D"}', true),

('arabic-heritage', 'Arabic Heritage', 'مطعم سعودي/خليجي بطابع تراثي فاخر غير مبالغ فيه',
 '{"primary":"#3D3025","secondary":"#776653","accent":"#9A6A35","background":"#F1E7D3","surface":"#FBF5E9","text":"#292018","border":"#E3D5B8","button":"#3D3025","buttonText":"#FBF5E9","heading":"#292018","muted":"#776653"}', true),

('fresh-green', 'Fresh & Green', 'مطعم صحي / Organic / Salad — بطاقات مستديرة، CTA أخضر هادئ',
 '{"primary":"#31523B","secondary":"#66705F","accent":"#9A9F55","background":"#F3F4EC","surface":"#FFFFFF","text":"#232821","border":"#DDE1D4","button":"#31523B","buttonText":"#FFFFFF","heading":"#232821","muted":"#66705F"}', true),

('bakery-atelier', 'Bakery Atelier', 'مخبز وحلويات فاخر — صور المنتجات هي البطل، طابع Editorial',
 '{"primary":"#49352C","secondary":"#806C60","accent":"#B77A62","background":"#F6EEE7","surface":"#FFF9F4","text":"#3A2B23","border":"#E5D6CC","button":"#49352C","buttonText":"#FFF9F4","heading":"#3A2B23","muted":"#806C60"}', true),

('coastal', 'Coastal', 'مطعم بحري / Beach Restaurant — ألوان بحرية هادئة، خطوط ناعمة',
 '{"primary":"#164A57","secondary":"#64777B","accent":"#C88B4A","background":"#F1F6F5","surface":"#FFFFFF","text":"#16262A","border":"#D7E3E4","button":"#164A57","buttonText":"#FFFFFF","heading":"#16262A","muted":"#64777B"}', true),

('contemporary-black', 'Contemporary Black', 'مطعم Contemporary فاخر جدًا — Black & warm white، Hero سينمائي',
 '{"primary":"#F5F3EE","secondary":"#9D9A93","accent":"#D0A96D","background":"#0D0D0D","surface":"#151515","text":"#F5F3EE","border":"#292929","button":"#F5F3EE","buttonText":"#0D0D0D","heading":"#F5F3EE","muted":"#9D9A93"}', true),

('retro-diner', 'Retro Diner', 'مطعم أمريكي Retro حديث — Badge للأكثر طلبًا، طباعة قوية',
 '{"primary":"#273B43","secondary":"#71675C","accent":"#C84C3A","background":"#F7EEDB","surface":"#FFF9ED","text":"#22282B","border":"#E2B34F","button":"#273B43","buttonText":"#FFF9ED","heading":"#22282B","muted":"#71675C"}', true),

('street-food', 'Street Food', 'مطعم Street Food عصري — ديناميكي، دخول متتالٍ (stagger)',
 '{"primary":"#181818","secondary":"#66615A","accent":"#D95A32","background":"#F4F1EA","surface":"#FFFFFF","text":"#181818","border":"#202020","button":"#D95A32","buttonText":"#FFFFFF","heading":"#181818","muted":"#66615A"}', true),

('garden-bistro', 'Garden Bistro', 'مطعم راقٍ هادئ وسط الطبيعة — أشكال عضوية، تخطيط ناعم',
 '{"primary":"#344536","secondary":"#72786B","accent":"#A47750","background":"#F1F0E7","surface":"#FAFAF5","text":"#252B24","border":"#D9DACE","button":"#344536","buttonText":"#FAFAF5","heading":"#252B24","muted":"#72786B"}', true),

('editorial-fine-dining', 'Editorial Fine Dining', 'Fine Dining بتصميم مجلة فاخرة — Split-screen، Masonry، أكثر الثيمات اختلافًا في التخطيط',
 '{"primary":"#222222","secondary":"#77736B","accent":"#8B6A45","background":"#F3F1EC","surface":"#FFFFFF","text":"#222222","border":"#DCD9D2","button":"#222222","buttonText":"#FFFFFF","heading":"#222222","muted":"#77736B"}', true)

on conflict (key) do update set
  name = excluded.name,
  description = excluded.description,
  default_palette = excluded.default_palette,
  is_active = excluded.is_active;
