-- ============================================================
-- DineForge — Migration 0006: توسعة كتالوج الثيمات (15 ثيمًا)
-- ============================================================
--
-- القرار: نظام الثيمات جزء أساسي من DineForge، والهدف دعم 10-15 ثيمًا احترافيًا
-- مستقلة الهوية البصرية فعليًا (Hero/Menu/Sections/Cards/Typography/Animations/Footer/الصور)،
-- وليس مجرد تغيير لون. حتى لا يظهر في فورم "إنشاء مطعم" أي ثيم لم تُبنَ هويته البصرية بعد
-- (وهذا كان الوضع الفعلي لأربعة من الثيمات الخمسة الأولى)، يُفعَّل is_active فقط للثيمات
-- المبنية فعليًا. باقي الثيمات تبقى في الكتالوج (is_active = false) جاهزة، ويكفي تفعيلها
-- (update ... set is_active = true) بمجرد بناء هويتها البصرية الفعلية في مرحلة قادمة —
-- التفاصيل الكاملة لكل ثيم موثقة في themes/theme-briefs.ts على مستوى الكود.

-- الثيم الوحيد المبني فعليًا بهوية بصرية مستقلة في هذه المرحلة (3) هو Minimal،
-- وتحديث اسمه هنا ليطابق قائمة الـ 15 ثيمًا المعتمدة رسميًا ("Minimal White")
update themes set name = 'Minimal White' where key = 'minimal';

-- تحديث أسماء الأربعة الأخرى لتطابق القائمة المعتمدة حرفيًا، وتعطيلها مؤقتًا
-- (كانت is_active=true منذ migration 0001 رغم عدم بناء هوية بصرية مستقلة لها بعد)
update themes set name = 'Luxury Restaurant', is_active = false where key = 'luxury';
update themes set name = 'Modern Fast Food', is_active = false where key = 'fast_food';
update themes set name = 'Cafe & Coffee', is_active = false where key = 'cafe';
update themes set name = 'Traditional Arabic', is_active = false where key = 'traditional';

-- إضافة الثيمات العشرة المتبقية من القائمة المعتمدة، كلها is_active = false
-- (كتالوج جاهز، بانتظار بناء الهوية البصرية الفعلية لكل واحد في مراحل قادمة)
insert into themes (key, name, description, is_active) values
  ('italian', 'Italian Restaurant', 'ألوان ترابية دافئة، صور أصناف كبيرة بإطار، خط عناوين كلاسيكي', false),
  ('asian', 'Asian Restaurant', 'تخطيط غير متماثل بمساحات فارغة كبيرة، خطوط رفيعة دقيقة', false),
  ('burger_house', 'Burger House', 'بطاقات كبيرة بصور بارزة وطابع طباعي قوي', false),
  ('fine_dining', 'Fine Dining', 'قائمة نصية شبه بلا صور، مساحات بيضاء واسعة جدًا', false),
  ('bakery', 'Bakery', 'شبكة صور دافئة كثيفة، خط عناوين دائري ودود', false),
  ('dessert_shop', 'Dessert Shop', 'صور دائرية ملونة صغيرة، حركة دخول مرحة خفيفة', false),
  ('seafood', 'Seafood Restaurant', 'لوحة ألوان زرقاء رملية، صور بعرض كامل أفقي', false),
  ('dark_premium', 'Dark Premium', 'خلفية داكنة كاملة، تباين عالٍ على الصور', false),
  ('street_food', 'Street Food', 'طابع ملصقات شارع خام، ألوان حادة متضادة', false),
  ('family_restaurant', 'Family Restaurant', 'تخطيط واسع مريح بخط كبير سهل القراءة', false)
on conflict (key) do nothing;

-- ملاحظة: فورم "إنشاء مطعم" في المرحلة 2 يجلب فقط الثيمات is_active=true (getThemesAction)،
-- لذلك هذا التحديث يمنع تلقائيًا اختيار Owner لأي ثيم لم تُبنَ هويته البصرية بعد، بدون أي تعديل
-- إضافي على كود لوحة التحكم.
