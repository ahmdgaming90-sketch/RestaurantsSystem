-- ============================================================
-- DineForge — Migration 0001: Initial Schema
-- يطابق Architecture Document v2
-- ============================================================

create extension if not exists "pgcrypto";

-- ============ المستخدمون والصلاحيات ============

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null check (role in ('owner', 'manager')),
  created_at timestamptz not null default now()
);

comment on table profiles is 'يمتد من auth.users؛ يحدد دور المستخدم owner/manager';

-- ============ المطاعم ============

create table restaurants (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text,
  logo_url text,
  cover_url text,
  whatsapp_number text not null,
  location text,
  working_hours jsonb not null default '{}',
  theme_id uuid, -- FK يُضاف بعد إنشاء جدول themes (انظر أسفل)
  color_palette jsonb not null default '{"primary":"#111827","secondary":"#6b7280","accent":"#f59e0b"}',
  font_family text not null default 'default',
  is_active boolean not null default true,
  created_by uuid references profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- قيد على الـ slug: أحرف/أرقام/شرطات صغيرة فقط، يمنع تعارضه مع مسارات النظام لاحقًا على مستوى التطبيق
alter table restaurants
  add constraint restaurants_slug_format check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$');

create index idx_restaurants_slug on restaurants(slug);
create index idx_restaurants_is_active on restaurants(is_active);

-- ============ ربط مدير المطعم بمطعمه ============

create table restaurant_managers (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references restaurants(id) on delete cascade,
  profile_id uuid not null references profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (restaurant_id, profile_id)
);

create index idx_restaurant_managers_profile on restaurant_managers(profile_id);
create index idx_restaurant_managers_restaurant on restaurant_managers(restaurant_id);

-- ============ إعدادات الطلب لكل مطعم ============

create table restaurant_order_settings (
  restaurant_id uuid primary key references restaurants(id) on delete cascade,
  require_phone boolean not null default true,
  pickup_note text not null default 'استلام من المطعم',
  thank_you_message text,
  updated_at timestamptz not null default now()
);

-- ============ إعدادات الموقع والتصميم العامة ============

create table restaurant_settings (
  restaurant_id uuid primary key references restaurants(id) on delete cascade,
  sections_visibility jsonb not null default '{}',
  footer_settings jsonb not null default '{
    "show_credit": true,
    "credit_text": "تم الإنشاء بواسطة مؤيد الحزمي",
    "credit_link": null,
    "show_social_links": false
  }',
  seo_title text,
  seo_description text,
  seo_keywords text[],
  seo_og_image_url text,
  order_button_settings jsonb not null default '{
    "label": "إرسال الطلب عبر واتساب",
    "position": "fixed-bottom",
    "color": null,
    "require_customer_name": true
  }',
  updated_at timestamptz not null default now()
);

-- ============ نظام القوالب (Themes) ============

create table themes (
  id uuid primary key default gen_random_uuid(),
  key text unique not null,
  name text not null,
  description text,
  default_palette jsonb not null default '{}',
  supports_animations text[] not null default array['fade','slide','zoom','reveal'],
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table restaurants
  add constraint fk_restaurants_theme foreign key (theme_id) references themes(id);

-- بذر الثيمات الخمسة الأساسية المتفق عليها في الـ Architecture
insert into themes (key, name, description) values
  ('luxury', 'Luxury Restaurant', 'تصميم فاخر، صور كبيرة، حركات هادئة'),
  ('fast_food', 'Fast Food', 'تصميم سريع وواضح للطلبات'),
  ('cafe', 'Cafe', 'تصميم هادئ'),
  ('traditional', 'Traditional', 'طابع عربي تقليدي'),
  ('minimal', 'Minimal', 'تصميم نظيف وبسيط');

-- ============ أقسام صفحة المطعم (ترتيب/إظهار/حركة) ============

create table restaurant_sections (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references restaurants(id) on delete cascade,
  section_key text not null,
  is_visible boolean not null default true,
  sort_order int not null default 0,
  animation text not null default 'fade' check (animation in ('fade','slide','zoom','reveal')),
  settings jsonb not null default '{}',
  unique (restaurant_id, section_key)
);

create index idx_restaurant_sections_restaurant on restaurant_sections(restaurant_id, sort_order);

-- ============ نسخ التصميم (Design Versions) ============

create table design_versions (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references restaurants(id) on delete cascade,
  label text,
  snapshot jsonb not null,
  created_by uuid references profiles(id),
  is_autosave boolean not null default false,
  created_at timestamptz not null default now()
);

create index idx_design_versions_restaurant on design_versions(restaurant_id, created_at desc);

-- ============ إعدادات PWA لكل مطعم ============

create table restaurant_pwa_settings (
  restaurant_id uuid primary key references restaurants(id) on delete cascade,
  app_name text,
  short_name text,
  icon_url text,
  theme_color text,
  background_color text,
  is_enabled boolean not null default true,
  updated_at timestamptz not null default now()
);

-- ============ المنتجات ============

create table categories (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references restaurants(id) on delete cascade,
  name text not null,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create index idx_categories_restaurant on categories(restaurant_id, sort_order);

create table products (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references restaurants(id) on delete cascade,
  category_id uuid references categories(id) on delete set null,
  name text not null,
  description text,
  price numeric(10,2) not null check (price >= 0),
  image_url text,
  is_available boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_products_restaurant on products(restaurant_id, sort_order);
create index idx_products_category on products(category_id);
create index idx_products_is_available on products(restaurant_id, is_available);

-- ============ الطلبات ============

create table orders (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references restaurants(id) on delete cascade,
  customer_name text not null,
  customer_phone text,
  notes text,
  items jsonb not null,
  total numeric(10,2) not null check (total >= 0),
  status text not null default 'sent' check (status in ('sent','confirmed','cancelled')),
  created_at timestamptz not null default now()
);

create index idx_orders_restaurant on orders(restaurant_id, created_at desc);

-- ============ trigger عام لتحديث updated_at ============

create or replace function set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger trg_restaurants_updated_at
  before update on restaurants
  for each row execute function set_updated_at();

create trigger trg_products_updated_at
  before update on products
  for each row execute function set_updated_at();

create trigger trg_restaurant_settings_updated_at
  before update on restaurant_settings
  for each row execute function set_updated_at();

create trigger trg_restaurant_order_settings_updated_at
  before update on restaurant_order_settings
  for each row execute function set_updated_at();

create trigger trg_restaurant_pwa_settings_updated_at
  before update on restaurant_pwa_settings
  for each row execute function set_updated_at();
